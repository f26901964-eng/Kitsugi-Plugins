#!/usr/bin/env python3
"""Kitsugi CrossSync raporunu eksiksiz, satır-kanıtlı biçimde ayrıştırır.

Hiçbir bölüm atlanmaz. Her fiziksel satır 08_SATIR_DENETIMI.jsonl.gz içine,
her olayın bütün ayrıntı blokları 09_OLAYLAR_TAM.jsonl.gz içine yazılır.
Yalnızca Python standart kütüphanesini kullanır.
"""
from __future__ import annotations

import argparse
import collections
import csv
import gzip
import hashlib
import json
import re
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Iterable

EVENT_RE = re.compile(
    r"^(\d+)\. \[([^]]+)\] \[(HATA|UYARI|BİLGİ|ERROR|WARNING|INFO)\] \[([^]]*)\] (.*)$"
)
CODE_RE = re.compile(r"^\s+(?:Kod|Code): (KTS-[A-Z]+-\d+)\s*$")
SECTION_RE = re.compile(r"^=== (.+?) ===$")
PLATFORM_RE = re.compile(
    r"^([^:]+): başlangıç=(\d+), eklenen=(\d+), güncellenen=(\d+), atlanan=(\d+), hata=(\d+)$"
)
DELETE_RE = re.compile(r"(?i)\bsilindi\b|\bsilinme\b|\bsilme\b|\bdelete[ds]?\b|\bremove[ds]?\b|\bkaldırıldı\b|\bkaldırma\b")


@dataclass
class Event:
    section: str
    index: int
    line_start: int
    line_end: int
    timestamp: str
    severity: str
    platform: str
    message: str
    error_code: str | None
    operation: str
    reason: str
    title: str | None
    detail_line_count: int
    details_sha256: str
    details: list[str]
    issue_indices: list[int]


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def classify(message: str, details: Iterable[str] = (), severity: str = "BİLGİ") -> tuple[str, str, str | None]:
    # İşlem türü yalnız olay mesajından çıkarılır. Ayrıntı bloklarında başka
    # platformların geçmiş hata metinleri de bulunabilir; bunlar başarılı bir
    # olayı geriye dönük olarak "hata" yapmamalı.
    message_text = message.casefold()
    # Bilgi olaylarının kayıt dökümlerinde sentetik 500… kimlikler ve eski hata
    # açıklamaları bulunabilir. Gerçek istisna ayrıntısını yalnız hata/uyarıda kullan.
    detail_list = list(details) if severity in {"HATA", "UYARI", "ERROR", "WARNING"} else []
    text = " ".join([message, *detail_list]).casefold()

    if "güncellenemedi" in message_text:
        operation = "update_error"
    elif "eklenemedi" in message_text:
        operation = "add_error"
    elif "silinemedi" in message_text:
        operation = "delete_error"
    elif severity in {"HATA", "ERROR"}:
        operation = "write_error"
    elif "güncellendi" in message_text:
        operation = "update_success"
    elif "eklendi" in message_text:
        operation = "add_success"
    elif DELETE_RE.search(message):
        operation = "delete_related"
    elif "atlandı" in message_text or "aktarılmadı" in message_text or "engellendi" in message_text:
        operation = "skipped"
    elif "zaten eşit" in message_text or "değişiklik yok" in message_text:
        operation = "up_to_date"
    elif "birleştirildi" in message_text:
        operation = "match_merge"
    elif "eşleş" in message_text or "kimlik" in message_text or "küme" in message_text:
        operation = "identity"
    elif "tamamlandı" in message_text or "başlat" in message_text or "hazırlan" in message_text:
        operation = "lifecycle"
    else:
        operation = "other_info"

    if "timeout" in text or "zaman aşım" in text:
        reason = "timeout"
    elif "cannot exceed length of media" in text:
        reason = "progress_above_media_length"
    elif "isteği reddetti (400)" in text or "http 400" in text:
        reason = "http_400_rejected"
    elif "şüpheli kimlik" in text or "yerel başlık/yıl ile uyuşmuyor" in text:
        reason = "identity_mismatch_blocked"
    elif "kimlik doğrulaması gerektiği" in text or "doğrulanamadı" in text or "doğrulanamadığı" in text:
        reason = "identity_unverified"
    elif "medya kimliği çözülemedi" in text or "eşleşmesi bulunamadı" in text or "kataloğunda bulunamadı" in text:
        reason = "remote_identity_unresolved"
    elif "doğrulanmış mal id yok" in text:
        reason = "verified_mal_id_missing"
    elif "429" in text or "hız sınırı" in text:
        reason = "rate_limit"
    elif "500" in text or "sunucu hatası" in text:
        reason = "server_500"
    elif "bölüm ilerlemesi aktarılmadı" in text:
        reason = "episode_progress_not_transferred"
    elif "kısmi işlem" in text or "izleme geçmişi" in text:
        reason = "partial_history_or_rating"
    elif "kimlik" in text or "eşleş" in text:
        reason = "identity_or_mapping"
    else:
        reason = "unspecified"

    title: str | None = None
    markers = [
        "Güncellenemedi:", "Eklenemedi:", "Güncellendi:", "Eklendi:",
        "! Hata:", "aktarılmadı:", "engellendi:",
        "Ortak kimlikle birleştirildi (başlık adları farklı):",
    ]
    for marker in markers:
        if marker in message:
            title = message.split(marker, 1)[1].strip()
            break
    if title is None and message.startswith("[") and "] - Atlandı (" in message:
        # Atlama gerekçesinin kendi içinde de parantezleri olabilir:
        # "[AniList] - Atlandı (… (MAL ID veya ARM eşlemesi yok)): Başlık".
        # Greedy ayırıcı son "): " sınırını bulur; başlık artık None kalmaz.
        title = re.sub(r"^\[[^]]+\] - Atlandı \(.*\): ", "", message).strip()
    if title is None and "→ MAL #" in message:
        title = message.split(":", 1)[-1].split("→ MAL #", 1)[0].strip()
    if title:
        # Hata ayrıntısı mesajın içine gömüldüyse başlık alanını ilk platform ayrıntısında kes.
        title = re.split(r" \((?:Hata:|Bangumi |Kitsu |AniList |Simkl |MyAnimeList |Shikimori )", title, maxsplit=1)[0].strip()
        title = title.split("→ MAL #", 1)[0].strip()
        title = title or None
    return operation, reason, title


def message_template(event: Event) -> str:
    msg = event.message
    known = [
        "Ortak kimlikle birleştirildi (başlık adları farklı):",
        "Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı:",
        "Şüpheli kimlik, ekleme engellendi:",
    ]
    for marker in known:
        if msg.startswith(marker):
            return marker + " <başlık>"
    msg = re.sub(r"^(.*?(?:Güncellendi|Güncellenemedi|Eklendi|Eklenemedi|! Hata)):.*$", r"\1: <başlık/ayrıntı>", msg)
    msg = re.sub(r"^(\[[^]]+\] - Atlandı \([^)]*\)):.*$", r"\1: <başlık>", msg)
    msg = re.sub(r"^(İçerik grubu oluşturuldu):.*$", r"\1: <başlık/kaynak>", msg)
    msg = re.sub(r"MAL #\d+", "MAL #<id>", msg)
    msg = re.sub(r"\b\d+\b", "<n>", msg)
    return msg


def parse_sections(lines: list[str]) -> list[dict]:
    sections: list[dict] = []
    for pos, line in enumerate(lines):
        match = SECTION_RE.match(line)
        if match:
            sections.append({"name": match[1], "header_line": pos + 1, "start": pos + 1})
    for idx, section in enumerate(sections):
        section["end"] = sections[idx + 1]["start"] - 1 if idx + 1 < len(sections) else len(lines)
        section["line_end"] = section["end"]
        name = section["name"]
        if name.startswith("SORUNLAR / UYARILAR") or name.startswith("ISSUES / WARNINGS"):
            section["kind"] = "issues"
        elif name.startswith("TÜM İŞLEM VE EŞLEŞTİRME") or name.startswith("ALL SYNC AND MATCHING"):
            section["kind"] = "all"
        elif name.startswith("HATA KODLARI") or name.startswith("ERROR CODES"):
            section["kind"] = "error_codes"
        elif name.startswith("ORTAM BİLGİSİ") or name.startswith("ENVIRONMENT"):
            section["kind"] = "environment"
        elif name.startswith("PLATFORM ÖZETİ") or name.startswith("PLATFORM SUMMARY"):
            section["kind"] = "platform_summary"
        else:
            section["kind"] = "other"
    return sections


def parse_events(lines: list[str], section: dict) -> list[Event]:
    starts: list[tuple[int, re.Match[str]]] = []
    for pos in range(section["start"], section["end"]):
        match = EVENT_RE.match(lines[pos])
        if match:
            starts.append((pos, match))
    events: list[Event] = []
    for idx, (pos, match) in enumerate(starts):
        end = starts[idx + 1][0] - 1 if idx + 1 < len(starts) else section["end"] - 1
        # Bölüm sonundaki girintisiz boş satırlar olay ayrıntısı değil ayraçtır.
        while end > pos and not lines[end].strip():
            end -= 1
        detail_lines = lines[pos + 1:end + 1]
        code = next((m.group(1) for line in detail_lines if (m := CODE_RE.match(line))), None)
        operation, reason, title = classify(match[5], detail_lines, match[3])
        details_text = "\n".join(detail_lines)
        events.append(Event(
            section=section["kind"], index=int(match[1]), line_start=pos + 1,
            line_end=end + 1, timestamp=match[2], severity=match[3], platform=match[4],
            message=match[5], error_code=code, operation=operation, reason=reason, title=title,
            detail_line_count=len(detail_lines), details_sha256=sha256_bytes(details_text.encode("utf-8")),
            details=detail_lines, issue_indices=[]
        ))
    expected = list(range(1, len(events) + 1))
    actual = [event.index for event in events]
    if actual != expected:
        raise ValueError(f"{section['name']}: olay sırası bozuk: {actual[:20]}…")
    return events


def signature(event: Event, include_details: bool = True) -> tuple:
    base = (event.timestamp, event.severity, event.platform, event.message, event.error_code)
    return base + (tuple(event.details),) if include_details else base


def write_gzip_jsonl(path: Path, rows: Iterable[dict]) -> None:
    with gzip.open(path, "wt", encoding="utf-8", newline="\n", compresslevel=9) as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n")


def markdown_escape(value: object) -> str:
    return str(value if value is not None else "—").replace("|", "\\|").replace("\n", " ")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--report", required=True, type=Path)
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--expected-md5", default="635fa5171b70877fdda5f86c426471f6")
    args = parser.parse_args()

    raw = args.report.read_bytes()
    actual_md5 = hashlib.md5(raw).hexdigest()
    if args.expected_md5 and actual_md5 != args.expected_md5:
        raise SystemExit(f"MD5 uyuşmuyor: beklenen={args.expected_md5} gerçek={actual_md5}")
    text = raw.decode("utf-8")
    physical = text.splitlines(keepends=True)
    lines = [line.rstrip("\r\n") for line in physical]
    args.out.mkdir(parents=True, exist_ok=True)

    sections = parse_sections(lines)
    by_kind = {section["kind"]: section for section in sections}
    for required in ("issues", "all", "platform_summary"):
        if required not in by_kind:
            raise SystemExit(f"Zorunlu bölüm yok: {required}")
    issue_events = parse_events(lines, by_kind["issues"])
    all_events = parse_events(lines, by_kind["all"])
    events = issue_events + all_events

    # Sorun bölümündeki her kayıt, tüm olaylar bölümünde birebir bulunmalı.
    signature_map: dict[tuple, list[Event]] = collections.defaultdict(list)
    for event in all_events:
        signature_map[signature(event)].append(event)
    unmatched_issues: list[int] = []
    for issue in issue_events:
        matches = signature_map.get(signature(issue), [])
        if not matches:
            # Kod/açıklama farkına karşı daha dar eşleşmeyi de denetle.
            matches = [event for event in all_events if signature(event, False) == signature(issue, False)]
        if not matches:
            unmatched_issues.append(issue.index)
        for match in matches:
            match.issue_indices.append(issue.index)

    # Satır sahipliği: her olay satırı ve bölüm dışı her satır ayrı ayrı işaretlenir.
    owners: dict[int, tuple[str, Event | None]] = {}
    for pos, line in enumerate(lines, 1):
        section = next((s for s in sections if s["header_line"] <= pos <= s["line_end"]), None)
        if section:
            role = "section_header" if pos == section["header_line"] else f"{section['kind']}_text"
            owners[pos] = (role if line.strip() else "blank", None)
        else:
            owners[pos] = ("preamble" if line.strip() else "blank", None)
    for event in events:
        for pos in range(event.line_start, event.line_end + 1):
            owners[pos] = ("event_header" if pos == event.line_start else "event_detail", event)

    # Olay aralıkları dışında kalan, olay başlığına benzeyen satır varsa hata ver.
    stray_event_headers = []
    event_header_lines = {event.line_start for event in events}
    for pos, line in enumerate(lines, 1):
        if EVENT_RE.match(line) and pos not in event_header_lines:
            stray_event_headers.append(pos)
    if stray_event_headers:
        raise ValueError(f"Sahipsiz olay başlıkları: {stray_event_headers[:20]}")

    unclassified = [pos for pos, line in enumerate(lines, 1) if line.strip() and pos not in owners]
    covered_lines = sum(1 for pos in range(1, len(lines) + 1) if pos in owners)
    if covered_lines != len(lines) or unclassified:
        raise ValueError(f"Satır kapsama hatası: {covered_lines}/{len(lines)}, unclassified={unclassified[:20]}")

    # Platform özetini ayrıştır.
    platform_stats: dict[str, dict[str, int]] = {}
    summary_section = by_kind["platform_summary"]
    for pos in range(summary_section["start"], summary_section["end"]):
        match = PLATFORM_RE.match(lines[pos])
        if match:
            platform_stats[match[1]] = {
                "initial": int(match[2]), "added": int(match[3]), "updated": int(match[4]),
                "skipped": int(match[5]), "errors": int(match[6])
            }

    # Ortam ve rapor başlığındaki sayısal beyanlar.
    environment: dict[str, str] = {}
    if "environment" in by_kind:
        env = by_kind["environment"]
        for pos in range(env["start"], env["end"]):
            if ": " in lines[pos]:
                key, value = lines[pos].split(": ", 1)
                environment[key] = value
    declared: dict[str, int] = {}
    for line in lines[:by_kind["platform_summary"]["header_line"] - 1]:
        for key, label in (("events", "Oluşturulan işlem kaydı:"), ("issues", "Hata/uyarı sayısı:")):
            if line.startswith(label):
                declared[key] = int(line.split(":", 1)[1].strip())

    # Makine okunabilir bütün olaylar.
    write_gzip_jsonl(args.out / "09_OLAYLAR_TAM.jsonl.gz", (asdict(event) for event in events))

    # Her fiziksel satır; metni de korunur, dolayısıyla denetimde içerik kaybı yoktur.
    def line_rows():
        for pos, line in enumerate(lines, 1):
            role, event = owners[pos]
            yield {
                "line": pos, "role": role,
                "section": event.section if event else next((s["kind"] for s in sections if s["header_line"] <= pos <= s["line_end"]), "preamble"),
                "event_index": event.index if event else None,
                "text_sha256": sha256_bytes(line.encode("utf-8")), "text": line,
            }
    write_gzip_jsonl(args.out / "08_SATIR_DENETIMI.jsonl.gz", line_rows())

    # Kompakt 3.011 olay envanteri.
    with (args.out / "05_TUM_OLAYLAR.csv").open("w", encoding="utf-8", newline="") as handle:
        fields = ["event", "issue_indices", "lines", "timestamp", "severity", "platform", "operation", "reason", "error_code", "title", "message", "detail_lines", "details_sha256"]
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for event in all_events:
            writer.writerow({
                "event": event.index, "issue_indices": ";".join(map(str, event.issue_indices)),
                "lines": f"{event.line_start}-{event.line_end}", "timestamp": event.timestamp,
                "severity": event.severity, "platform": event.platform, "operation": event.operation,
                "reason": event.reason, "error_code": event.error_code or "", "title": event.title or "",
                "message": event.message, "detail_lines": event.detail_line_count,
                "details_sha256": event.details_sha256,
            })

    # 155 sorunun tamamı, ayrıntı satırları atlanmadan Markdown'a yazılır.
    with (args.out / "04_SORUNLAR_TAM_LISTE.md").open("w", encoding="utf-8", newline="\n") as handle:
        handle.write("# 155 SORUN / UYARI — TAM VE SATIR KANITLI LİSTE\n\n")
        handle.write("Bu dosya ayrıştırıcı tarafından üretildi. Her bloğun bütün ayrıntı satırları korunur. `Tüm olay no`, aynı kaydın 3.011 olaylık bölümdeki karşılığıdır.\n\n")
        for issue in issue_events:
            matches = [str(event.index) for event in all_events if issue.index in event.issue_indices]
            handle.write(f"## Sorun {issue.index} · {issue.severity} · {issue.platform}\n\n")
            handle.write(f"- Rapor satırları: `{issue.line_start}–{issue.line_end}`\n")
            handle.write(f"- Zaman: `{issue.timestamp}`\n")
            handle.write(f"- Kod: `{issue.error_code or '—'}`\n")
            handle.write(f"- İşlem / neden: `{issue.operation}` / `{issue.reason}`\n")
            handle.write(f"- Tüm olay no: `{', '.join(matches) if matches else 'EŞLEŞMEDİ'}`\n\n")
            handle.write("```text\n" + "\n".join(lines[issue.line_start - 1:issue.line_end]) + "\n```\n\n")

    # Gruplar: tekrarlar özetlenir fakat bütün olay referansları korunur.
    groups: dict[tuple, list[Event]] = collections.defaultdict(list)
    for event in all_events:
        key = (event.platform, event.severity, event.error_code or "", event.operation, event.reason, message_template(event))
        groups[key].append(event)
    with (args.out / "11_OLAY_GRUPLARI.csv").open("w", encoding="utf-8", newline="") as handle:
        fields = ["platform", "severity", "error_code", "operation", "reason", "message_template", "count", "event_indices", "issue_indices"]
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for key, members in sorted(groups.items(), key=lambda item: (-len(item[1]), item[0])):
            writer.writerow({
                "platform": key[0], "severity": key[1], "error_code": key[2], "operation": key[3],
                "reason": key[4], "message_template": key[5], "count": len(members),
                "event_indices": ";".join(str(event.index) for event in members),
                "issue_indices": ";".join(str(issue) for event in members for issue in event.issue_indices),
            })

    # Kaynak bazlı özet ve bütün sorun referansları.
    with (args.out / "10_KAYNAK_BAZLI_OZET.md").open("w", encoding="utf-8", newline="\n") as handle:
        handle.write("# KAYNAK BAZLI TAM SORUN ENVANTERİ\n\n")
        handle.write("Her tablo ilgili kaynağın **bütün** hata/uyarı başlıklarını içerir; olayın tam ayrıntısı `04_SORUNLAR_TAM_LISTE.md` içindedir. Bilgi kayıtlarının tamamı `05_TUM_OLAYLAR.csv` içindedir.\n\n")
        platforms = sorted({event.platform for event in all_events}, key=lambda name: (name == "Eşleştirme", name))
        for platform in platforms:
            source_events = [event for event in all_events if event.platform == platform]
            source_issues = [event for event in issue_events if event.platform == platform]
            handle.write(f"## {platform}\n\n")
            if platform in platform_stats:
                stats = platform_stats[platform]
                handle.write(f"Rapor özeti: başlangıç **{stats['initial']}**, eklenen **{stats['added']}**, güncellenen **{stats['updated']}**, atlanan **{stats['skipped']}**, hata **{stats['errors']}**.\n\n")
            handle.write(f"Olay: **{len(source_events)}**; sorun/uyarı: **{len(source_issues)}**; seviyeler: `{dict(collections.Counter(event.severity for event in source_events))}`.\n\n")
            handle.write("### İşlem ve neden dağılımı (bilgi kayıtları dahil)\n\n")
            for key, count in sorted(collections.Counter((event.operation, event.reason) for event in source_events).items(), key=lambda item: (-item[1], item[0])):
                handle.write(f"- `{key[0]}` / `{key[1]}`: **{count}**\n")
            handle.write("\n### Bütün hata ve uyarılar\n\n")
            if not source_issues:
                handle.write("Bu kaynağa ait hata/uyarı kaydı yok.\n\n")
                continue
            handle.write("| Sorun | Tüm olay | Seviye | Kod | Neden | Mesaj |\n|---:|---:|---|---|---|---|\n")
            for issue in source_issues:
                event_refs = ",".join(str(event.index) for event in all_events if issue.index in event.issue_indices)
                handle.write(f"| {issue.index} | {event_refs or '—'} | {issue.severity} | {markdown_escape(issue.error_code)} | `{issue.reason}` | {markdown_escape(issue.message)} |\n")
            handle.write("\n")

    # Sayısal rapor özeti.
    header_lines = lines[:by_kind["platform_summary"]["header_line"] - 1]
    severity_counts = collections.Counter(event.severity for event in all_events)
    issue_severity_counts = collections.Counter(event.severity for event in issue_events)
    error_platform_counts = collections.Counter(event.platform for event in all_events if event.severity == "HATA")
    deletion_hits = [{"line": pos, "text": line} for pos, line in enumerate(lines, 1) if DELETE_RE.search(line)]
    summary = {
        "report": {
            "name": args.report.name, "bytes": len(raw), "md5": actual_md5, "sha256": sha256_bytes(raw),
            "physical_lines": len(lines), "newline_characters": raw.count(b"\n"), "utf8": True,
        },
        "declared": declared,
        "counts": {
            "issues": len(issue_events), "all_events": len(all_events),
            "issue_severity": dict(issue_severity_counts), "all_event_severity": dict(severity_counts),
            "issue_platform": dict(collections.Counter(event.platform for event in issue_events)),
            "all_event_platform": dict(collections.Counter(event.platform for event in all_events)),
            "error_platform": dict(error_platform_counts),
            "operations": dict(collections.Counter(event.operation for event in all_events)),
            "reasons": dict(collections.Counter(event.reason for event in all_events)),
            "error_codes_all_events": dict(collections.Counter(event.error_code for event in all_events if event.error_code)),
        },
        "platform_summary": platform_stats,
        "environment": environment,
        "sections": [{k: v for k, v in section.items() if k not in ("start", "end")} for section in sections],
        "reconciliation": {
            "declared_issues_match": declared.get("issues") == len(issue_events),
            "declared_events_match": declared.get("events") == len(all_events),
            "issue_events_matched_in_all": len(issue_events) - len(unmatched_issues),
            "unmatched_issue_indices": unmatched_issues,
            "platform_error_total": sum(stats["errors"] for stats in platform_stats.values()),
            "actual_error_total": severity_counts.get("HATA", 0),
            "platform_skipped_total": sum(stats["skipped"] for stats in platform_stats.values()),
            "platform_added_total": sum(stats["added"] for stats in platform_stats.values()),
            "platform_updated_total": sum(stats["updated"] for stats in platform_stats.values()),
            "delete_related_line_count": len(deletion_hits),
            "delete_related_lines": deletion_hits,
        },
        "line_coverage": {
            "covered_lines": covered_lines, "physical_lines": len(lines), "coverage_percent": 100.0,
            "unclassified_nonblank_lines": unclassified, "stray_event_headers": stray_event_headers,
            "line_audit": "08_SATIR_DENETIMI.jsonl.gz",
        },
    }
    (args.out / "07_SATIR_KAPSAMA.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    with (args.out / "03_RAPOR_OZETI.md").open("w", encoding="utf-8", newline="\n") as handle:
        handle.write("# CROSSSYNC RAPORU — DOĞRULANMIŞ TAM ÖZET\n\n")
        handle.write("## Bütünlük\n\n")
        handle.write(f"- Dosya: `{args.report.name}`\n- Boyut: **{len(raw):,} bayt**\n- Fiziksel satır: **{len(lines):,}**\n")
        handle.write(f"- MD5: `{actual_md5}`\n- SHA-256: `{sha256_bytes(raw)}`\n")
        handle.write(f"- Satır kapsama: **{covered_lines}/{len(lines)} (%100)**; sınıflandırılmayan boş olmayan satır: **{len(unclassified)}**\n")
        handle.write(f"- Uygulama: **{environment.get('Uygulama', '—')}**; cihaz: **{environment.get('Cihaz', '—')}**; Android: **{environment.get('Android', '—')}**\n\n")
        handle.write("## Rapor başlığı\n\n```text\n" + "\n".join(header_lines).rstrip() + "\n```\n\n")
        handle.write("## Mutabakat\n\n")
        handle.write(f"- Sorun bölümü: **{len(issue_events)}** = **{issue_severity_counts.get('HATA', 0)} hata + {issue_severity_counts.get('UYARI', 0)} uyarı**.\n")
        handle.write(f"- Tüm olaylar bölümü: **{len(all_events)}** = " + ", ".join(f"**{key}={value}**" for key, value in sorted(severity_counts.items())) + ".\n")
        handle.write(f"- Sorunların tüm olaylar bölümünde bulunan karşılığı: **{len(issue_events) - len(unmatched_issues)}/{len(issue_events)}**.\n")
        handle.write(f"- Platform hata toplamı / gerçek HATA olayı: **{sum(stats['errors'] for stats in platform_stats.values())}/{severity_counts.get('HATA', 0)}**.\n")
        handle.write(f"- Platform atlanan toplamı: **{sum(stats['skipped'] for stats in platform_stats.values())}**.\n")
        handle.write(f"- Silme/delete/remove ilişkili satır: **{len(deletion_hits)}**.\n\n")
        handle.write("## Platformlar\n\n| Platform | Başlangıç | Eklenen | Güncellenen | Atlanan | Hata | Tüm olay | Uyarı |\n|---|---:|---:|---:|---:|---:|---:|---:|\n")
        for platform, stats in platform_stats.items():
            source = [event for event in all_events if event.platform == platform]
            handle.write(f"| {platform} | {stats['initial']} | {stats['added']} | {stats['updated']} | {stats['skipped']} | {stats['errors']} | {len(source)} | {sum(event.severity == 'UYARI' for event in source)} |\n")
        handle.write("\n## Hata kodları (3.011 olay içindeki tekrarlar dahil)\n\n")
        for code, count in sorted(collections.Counter(event.error_code for event in all_events if event.error_code).items()):
            handle.write(f"- `{code}`: **{count}** olay\n")
        handle.write("\n## Bölümler ve satır aralıkları\n\n")
        for section in sections:
            handle.write(f"- `{section['header_line']}–{section['line_end']}`: **{section['name']}**\n")
        handle.write("\n## Tam listeler\n\n- 155 sorun ve bütün ayrıntıları: `04_SORUNLAR_TAM_LISTE.md`\n- 3.011 olay: `05_TUM_OLAYLAR.csv`\n- Kaynak bazlı bütün sorunlar: `10_KAYNAK_BAZLI_OZET.md`\n- Bütün olay grupları ve referansları: `11_OLAY_GRUPLARI.csv`\n- Her fiziksel satır: `08_SATIR_DENETIMI.jsonl.gz`\n")

    print(json.dumps({
        "lines": len(lines), "issues": len(issue_events), "events": len(all_events),
        "issue_severity": dict(issue_severity_counts), "event_severity": dict(severity_counts),
        "unmatched_issues": unmatched_issues, "covered_lines": covered_lines,
        "deletion_lines": len(deletion_hits), "output": str(args.out),
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
