#!/usr/bin/env python3
"""Build and validate the v359 source patch, changed-file mirror, and SHA-256 manifest."""
from __future__ import annotations

import datetime as dt
import filecmp
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parents[2]
BASE = ROOT / "source-v359-pristine"
MODIFIED = ROOT / "source-v359"
OUT = ROOT / "deliverables"
PATCH = OUT / "12_KITSUGI_BETA_V359_FIX.patch"
MIRROR = OUT / "degisen-dosyalar"
MANIFEST = OUT / "13_DEGISEN_DOSYALAR_MANIFEST.json"
BASELINE = "a8d7aaf6a7e450edc6095c5dcd5aaf913f7a4b03"
SKIP_DIRS = {".git", ".gradle", "build", ".idea", ".kotlin"}


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def files_under(root: Path) -> set[str]:
    result: set[str] = set()
    for path in root.rglob("*"):
        if not path.is_file() or any(part in SKIP_DIRS for part in path.relative_to(root).parts):
            continue
        result.add(path.relative_to(root).as_posix())
    return result


def main() -> None:
    base_files = files_under(BASE)
    modified_files = files_under(MODIFIED)
    changed: list[dict[str, object]] = []
    for rel in sorted(base_files | modified_files):
        before = BASE / rel
        after = MODIFIED / rel
        if rel in base_files and rel in modified_files and filecmp.cmp(before, after, shallow=False):
            continue
        kind = "added" if rel not in base_files else "deleted" if rel not in modified_files else "modified"
        row: dict[str, object] = {"path": rel, "change": kind}
        if rel in base_files:
            row["base_sha256"] = digest(before)
            row["base_bytes"] = before.stat().st_size
        if rel in modified_files:
            row["patched_sha256"] = digest(after)
            row["patched_bytes"] = after.stat().st_size
        changed.append(row)

    raw = subprocess.run(
        ["git", "diff", "--no-index", "--src-prefix=a/", "--dst-prefix=b/", BASE.name, MODIFIED.name],
        cwd=ROOT,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=False,
    )
    if raw.returncode not in (0, 1) or raw.stderr:
        raise SystemExit(f"git diff failed ({raw.returncode}): {raw.stderr.decode('utf-8', 'replace')}")
    text = raw.stdout.decode("utf-8")
    for root_name in ("source-v359-pristine", "source-v359"):
        text = text.replace(f"a/{root_name}/", "a/").replace(f"b/{root_name}/", "b/")
    if "source-v359" in "\n".join(line for line in text.splitlines() if line.startswith(("diff --git ", "--- ", "+++ "))):
        raise SystemExit("patch path normalization failed")
    PATCH.write_text(text, encoding="utf-8")
    subprocess.run(["git", "-C", str(BASE), "apply", "--check", str(PATCH)], check=True)

    if MIRROR.exists():
        shutil.rmtree(MIRROR)
    for row in changed:
        rel = str(row["path"])
        if row["change"] == "deleted":
            continue
        destination = MIRROR / rel
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(MODIFIED / rel, destination)

    payload = {
        "schema": 1,
        "generated_at_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
        "repository": "f26901964-eng/Kitsugi-Beta",
        "baseline_commit": BASELINE,
        "baseline_report_version": "2.4.359-beta.29880340",
        "patch_file": PATCH.name,
        "patch_sha256": digest(PATCH),
        "patch_bytes": PATCH.stat().st_size,
        "patch_apply_check": "git -C source-v359-pristine apply --check: PASS",
        "changed_file_count": len(changed),
        "added": sum(row["change"] == "added" for row in changed),
        "modified": sum(row["change"] == "modified" for row in changed),
        "deleted": sum(row["change"] == "deleted" for row in changed),
        "files": changed,
        "verification_note": "This manifest proves file identity and patch applicability only; see testler/ for executed CI results.",
    }
    MANIFEST.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: payload[key] for key in ("changed_file_count", "added", "modified", "deleted", "patch_sha256", "patch_bytes")}, indent=2))


if __name__ == "__main__":
    main()
