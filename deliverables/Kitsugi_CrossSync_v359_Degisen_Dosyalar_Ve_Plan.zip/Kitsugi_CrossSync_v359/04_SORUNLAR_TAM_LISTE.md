# 155 SORUN / UYARI — TAM VE SATIR KANITLI LİSTE

Bu dosya ayrıştırıcı tarafından üretildi. Her bloğun bütün ayrıntı satırları korunur. `Tüm olay no`, aynı kaydın 3.011 olaylık bölümdeki karşılığıdır.

## Sorun 1 · UYARI · Eşleştirme

- Rapor satırları: `22–89`
- Zaman: `2026-10-24 15:31:30.405 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `1140`

```text
1. [2026-10-24 15:31:30.405 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Evangelion Shin Movie: Kyuu
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: Evangelion Shin Movie: Kyuu
   İngilizce başlık: Evangelion: 3.0 You Can (Not) Redo
   Japonca başlık: ヱヴァンゲリヲン新劇場版:Q
   Tür/yıl: Anime / 2012
   Kaynak: anilist
   Harici kimlikler: Anime:mal:3785
   Ham kimlik alanları: MAL ID=3785 (MAL), AniList kayıt ID=600424171, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: İzleniyor, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=2026-10-04, bitiş=yok; favori=false
   
   
   Başlık: Evangelion Movie 3: Q
   İngilizce başlık: Evangelion: 3.0 You Can (Not) Redo
   Japonca başlık: ヱヴァンゲリヲン新劇場版:Q
   Tür/yıl: Anime / 2012
   Kaynak: mal
   Harici kimlikler: Anime:mal:3785
   Ham kimlik alanları: MAL ID=3785 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: İzleniyor, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=2026-10-04, bitiş=yok; favori=false
   
   
   Başlık: Evangelion Shin Gekijouban: Q
   Tür/yıl: Anime / 2012
   Kaynak: simkl
   Harici kimlikler: Anime:mal:3785, Anime:simkl:40761, Anime:tmdb:75629
   Ham kimlik alanları: MAL ID=3785 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=40761, TMDB ID=75629
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Evangelion: 3.0 You Can (Not) Redo
   İngilizce başlık: Evangelion: 3.0 You Can (Not) Redo
   Japonca başlık: ヱヴァンゲリヲン新劇場版:Q
   Tür/yıl: Anime / 2012
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:3251
   Ham kimlik alanları: MAL ID=300003251 (dahili Kitsu kimliği, MAL değil: Kitsu #3251), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: İzleniyor, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=2026-10-04, bitiş=yok; favori=false
   
   
   Başlık: Evangelion Movie 3: Q
   Tür/yıl: Anime / 2012
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:3785, Anime:shikimori:3785
   Ham kimlik alanları: MAL ID=3785 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: İzleniyor, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: ヱヴァンゲリヲン新劇場版:Q
   Japonca başlık: ヱヴァンゲリヲン新劇場版:Q
   Tür/yıl: Anime / 2012
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:22505
   Ham kimlik alanları: MAL ID=500022505 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: İzleniyor, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 2 · HATA · AniList

- Rapor satırları: `91–182`
- Zaman: `2026-10-24 15:31:31.913 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `update_error` / `identity_unverified`
- Tüm olay no: `1147`

```text
2. [2026-10-24 15:31:31.913 GMT+03:00] [HATA] [AniList] [AniList] ! Güncellenemedi: CLANNAD 〜AFTER STORY〜
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Hata: java.lang.IllegalStateException: AniList liste kaydının bu medya ile eşleştiği doğrulanamadı: CLANNAD 〜AFTER STORY〜
     at com.kitsugi.animelist.data.auth.AniListSyncManager.updateAniListEntry(?:718)
     at com.kitsugi.animelist.data.auth.AniListSyncManager.updateAniListEntry$default(?:40)
     at c7.r1.invokeSuspend(?:26941)
     at kotlin.coroutines.jvm.internal.BaseContinuationImpl.resumeWith(?:11)
     at kotlinx.coroutines.DispatchedTask.run(?:128)
     at kotlinx.coroutines.internal.LimitedDispatcher$Worker.run(?:3)
   
   Kaynak platform kayıtları (6):
   Kayıt 1:
   Başlık: CLANNAD: After Story
   İngilizce başlık: Clannad: After Story
   Japonca başlık: ＣＬＡＮＮＡＤ ~After Story~ クラナド アフターストーリー
   Tür/yıl: Anime / 2008
   Kaynak: anilist
   Harici kimlikler: Anime:mal:4181
   Ham kimlik alanları: MAL ID=4181 (MAL), AniList kayıt ID=602591379, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: İzleniyor, bölüm=1/24, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 2:
   Başlık: Clannad: After Story
   İngilizce başlık: Clannad: After Story
   Japonca başlık: CLANNAD〜AFTER STORY〜 クラナド アフターストーリー
   Tür/yıl: Anime / 2008
   Kaynak: mal
   Harici kimlikler: Anime:mal:4181
   Ham kimlik alanları: MAL ID=4181 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: İzleniyor, bölüm=1/24, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 3:
   Başlık: Clannad: After Story
   Tür/yıl: Anime / 2008
   Kaynak: simkl
   Harici kimlikler: Anime:mal:4181, Anime:simkl:38483
   Ham kimlik alanları: MAL ID=4181 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=38483, TMDB ID=yok
   Durum/ilerleme: İzleniyor, bölüm=1/22, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 4:
   Başlık: Clannad: After Story
   İngilizce başlık: Clannad ~After Story~
   Japonca başlık: CLANNAD〜AFTER STORY〜 クラナド アフターストーリー
   Tür/yıl: Anime / 2008
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:3505
   Ham kimlik alanları: MAL ID=300003505 (dahili Kitsu kimliği, MAL değil: Kitsu #3505), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: İzleniyor, bölüm=1/24, cilt=0, puan=yok
   Tarihler: başlangıç=2026-10-12, bitiş=yok; favori=false
   
   Kayıt 5:
   Başlık: Clannad: After Story
   Tür/yıl: Anime / 2008
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:4181, Anime:shikimori:4181
   Ham kimlik alanları: MAL ID=4181 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: İzleniyor, bölüm=1/24, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 6:
   Başlık: CLANNAD 〜AFTER STORY〜
   İngilizce başlık: Clannad: After Story
   Japonca başlık: CLANNAD 〜AFTER STORY〜
   Tür/yıl: Anime / 2008
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:876
   Ham kimlik alanları: MAL ID=500000876 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: İzleniyor, bölüm=1/24, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Eşitleme için birleştirilen değerler:
   Başlık: CLANNAD 〜AFTER STORY〜
   İngilizce başlık: Clannad: After Story
   Japonca başlık: ＣＬＡＮＮＡＤ ~After Story~ クラナド アフターストーリー
   Tür/yıl: Anime / 2008
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:4181, Anime:simkl:38483
   Ham kimlik alanları: MAL ID=4181 (MAL), AniList kayıt ID=602591379, MAL liste ID=yok, Simkl ID=38483, TMDB ID=yok
   Durum/ilerleme: İzleniyor, bölüm=1/24, cilt=0, puan=yok
   Tarihler: başlangıç=2026-10-12, bitiş=yok; favori=false
   
   Kimlik güvencesi: Gerek yok (tüm hedef platformlarda kayıt zaten var)
```

## Sorun 3 · UYARI · Eşleştirme

- Rapor satırları: `184–232`
- Zaman: `2026-10-24 15:31:38.191 GMT+03:00`
- Kod: `—`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `1176`

```text
3. [2026-10-24 15:31:38.191 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: WHITE ALBUM 2nd Season
   Başlık: WHITE ALBUM 2nd Season
   Japonca başlık: WHITE ALBUM 第2期
   Tür/yıl: Anime / 2009
   Kaynak: anilist
   Harici kimlikler: Anime:mal:6165
   Ham kimlik alanları: MAL ID=6165 (MAL), AniList kayıt ID=538171901, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/13, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: White Album 2nd Season
   İngilizce başlık: White Album Season 2
   Japonca başlık: WHITE ALBUM 第2期
   Tür/yıl: Anime / 2009
   Kaynak: mal
   Harici kimlikler: Anime:mal:6165
   Ham kimlik alanları: MAL ID=6165 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/13, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: White Album
   Tür/yıl: Anime / 2009
   Kaynak: simkl
   Harici kimlikler: Anime:mal:6165, Anime:simkl:36608
   Ham kimlik alanları: MAL ID=6165 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=36608, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/13, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: White Album 2nd Season
   İngilizce başlık: White Album Season 2
   Japonca başlık: WHITE ALBUM 第2期
   Tür/yıl: Anime / 2009
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:4455
   Ham kimlik alanları: MAL ID=300004455 (dahili Kitsu kimliği, MAL değil: Kitsu #4455), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/13, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: White Album 2nd Season
   Tür/yıl: Anime / 2009
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:6165, Anime:shikimori:6165
   Ham kimlik alanları: MAL ID=6165 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/13, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 4 · HATA · AniList

- Rapor satırları: `234–323`
- Zaman: `2026-10-24 15:31:51.061 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `update_error` / `identity_unverified`
- Tüm olay no: `1232`

```text
4. [2026-10-24 15:31:51.061 GMT+03:00] [HATA] [AniList] [AniList] ! Güncellenemedi: SUPERNATURAL THE ANIMATION
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Hata: java.lang.IllegalStateException: AniList liste kaydının bu medya ile eşleştiği doğrulanamadı: SUPERNATURAL THE ANIMATION
     at com.kitsugi.animelist.data.auth.AniListSyncManager.updateAniListEntry(?:718)
     at com.kitsugi.animelist.data.auth.AniListSyncManager.updateAniListEntry$default(?:40)
     at c7.r1.invokeSuspend(?:26941)
     at kotlin.coroutines.jvm.internal.BaseContinuationImpl.resumeWith(?:11)
     at kotlinx.coroutines.DispatchedTask.run(?:128)
     at kotlinx.coroutines.internal.LimitedDispatcher$Worker.run(?:3)
   
   Kaynak platform kayıtları (6):
   Kayıt 1:
   Başlık: Supernatural The Animation
   İngilizce başlık: Supernatural: The Anime Series
   Japonca başlık: スーパーナチュラル・ザ・アニメーション
   Tür/yıl: Anime / 2011
   Kaynak: anilist
   Harici kimlikler: Anime:mal:8986
   Ham kimlik alanları: MAL ID=8986 (MAL), AniList kayıt ID=600424617, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=11/22, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 2:
   Başlık: Supernatural The Animation
   İngilizce başlık: Supernatural: The Anime Series
   Japonca başlık: スーパーナチュラル・ザ・アニメーション
   Tür/yıl: Anime / 2011
   Kaynak: mal
   Harici kimlikler: Anime:mal:8986
   Ham kimlik alanları: MAL ID=8986 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=11/22, cilt=0, puan=yok
   Tarihler: başlangıç=2011-02-23, bitiş=2011-04-27; favori=false
   
   Kayıt 3:
   Başlık: Supernatural
   Tür/yıl: Anime / 2011
   Kaynak: simkl
   Harici kimlikler: Anime:mal:8986, Anime:simkl:38876, Anime:tmdb:32871
   Ham kimlik alanları: MAL ID=8986 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=38876, TMDB ID=32871
   Durum/ilerleme: Planlandı, bölüm=11/22, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 4:
   Başlık: Supernatural The Animation
   Japonca başlık: スーパーナチュラル・ザ・アニメーション
   Tür/yıl: Anime / 2011
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:5562
   Ham kimlik alanları: MAL ID=300005562 (dahili Kitsu kimliği, MAL değil: Kitsu #5562), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=11/22, cilt=0, puan=yok
   Tarihler: başlangıç=2011-02-23, bitiş=2011-04-27; favori=false
   
   Kayıt 5:
   Başlık: Supernatural The Animation
   Tür/yıl: Anime / 2011
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:8986, Anime:shikimori:8986
   Ham kimlik alanları: MAL ID=8986 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=11/22, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 6:
   Başlık: SUPERNATURAL THE ANIMATION
   Japonca başlık: SUPERNATURAL THE ANIMATION
   Tür/yıl: Anime / 2011
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:10184
   Ham kimlik alanları: MAL ID=500010184 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=11/22, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Eşitleme için birleştirilen değerler:
   Başlık: SUPERNATURAL THE ANIMATION
   İngilizce başlık: Supernatural: The Anime Series
   Japonca başlık: スーパーナチュラル・ザ・アニメーション
   Tür/yıl: Anime / 2011
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:8986, Anime:simkl:38876, Anime:tmdb:32871
   Ham kimlik alanları: MAL ID=8986 (MAL), AniList kayıt ID=600424617, MAL liste ID=yok, Simkl ID=38876, TMDB ID=32871
   Durum/ilerleme: Planlandı, bölüm=11/22, cilt=0, puan=yok
   Tarihler: başlangıç=2011-02-23, bitiş=2011-04-27; favori=false
   
   Kimlik güvencesi: Gerek yok (tüm hedef platformlarda kayıt zaten var)
```

## Sorun 5 · UYARI · Eşleştirme

- Rapor satırları: `325–393`
- Zaman: `2026-10-24 15:31:52.317 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `1246`

```text
5. [2026-10-24 15:31:52.317 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: K-ON! Movie
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: K-ON! Movie
   İngilizce başlık: K-ON!: The Movie
   Japonca başlık: 映画けいおん！
   Tür/yıl: Anime / 2011
   Kaynak: anilist
   Harici kimlikler: Anime:mal:9617
   Ham kimlik alanları: MAL ID=9617 (MAL), AniList kayıt ID=495061004, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: K-On! Movie
   İngilizce başlık: K-ON! The Movie
   Japonca başlık: 映画 けいおん！
   Tür/yıl: Anime / 2011
   Kaynak: mal
   Harici kimlikler: Anime:mal:9617
   Ham kimlik alanları: MAL ID=9617 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Eiga K-On!
   Tür/yıl: Anime / 2011
   Kaynak: simkl
   Harici kimlikler: Anime:mal:9617, Anime:simkl:38629, Anime:tmdb:120811
   Ham kimlik alanları: MAL ID=9617 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=38629, TMDB ID=120811
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: K-On! Movie
   İngilizce başlık: K-ON! The Movie
   Japonca başlık: 映画 けいおん！
   Tür/yıl: Anime / 2011
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:5810
   Ham kimlik alanları: MAL ID=300005810 (dahili Kitsu kimliği, MAL değil: Kitsu #5810), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: K-On! Movie
   Tür/yıl: Anime / 2011
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:9617, Anime:shikimori:9617
   Ham kimlik alanları: MAL ID=9617 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: K-ON! Movie
   İngilizce başlık: K-ON!: The Movie
   Japonca başlık: 映画けいおん！
   Tür/yıl: Anime / 2011
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:12426
   Ham kimlik alanları: MAL ID=500012426 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 6 · UYARI · Eşleştirme

- Rapor satırları: `395–462`
- Zaman: `2026-10-24 15:32:04.634 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `1299`

```text
6. [2026-10-24 15:32:04.634 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Fate/Zero 2nd Season
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: Fate/Zero 2nd Season
   İngilizce başlık: Fate/Zero Season 2
   Japonca başlık: Fate/Zero 2ndシーズン
   Tür/yıl: Anime / 2012
   Kaynak: anilist
   Harici kimlikler: Anime:mal:11741
   Ham kimlik alanları: MAL ID=11741 (MAL), AniList kayıt ID=495060933, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Fate/Zero 2nd Season
   İngilizce başlık: Fate/Zero Season 2
   Japonca başlık: フェイト/ゼロ 2ndシーズン
   Tür/yıl: Anime / 2012
   Kaynak: mal
   Harici kimlikler: Anime:mal:11741
   Ham kimlik alanları: MAL ID=11741 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Fate/Zero
   Tür/yıl: Anime / 2012
   Kaynak: simkl
   Harici kimlikler: Anime:mal:11741, Anime:simkl:39838
   Ham kimlik alanları: MAL ID=11741 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=39838, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Fate/Zero 2nd Season
   İngilizce başlık: Fate/Zero Season 2
   Japonca başlık: フェイト/ゼロ 2ndシーズン
   Tür/yıl: Anime / 2012
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:7658
   Ham kimlik alanları: MAL ID=300007658 (dahili Kitsu kimliği, MAL değil: Kitsu #7658), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Fate/Zero 2nd Season
   Tür/yıl: Anime / 2012
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:11741, Anime:shikimori:11741
   Ham kimlik alanları: MAL ID=11741 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Fate/Zero Remix
   Japonca başlık: Fate/Zero Remix
   Tür/yıl: Anime / 2012
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:36379
   Ham kimlik alanları: MAL ID=500036379 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/2, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 7 · HATA · AniList

- Rapor satırları: `464–543`
- Zaman: `2026-10-24 15:32:04.837 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `update_error` / `identity_unverified`
- Tüm olay no: `1309`

```text
7. [2026-10-24 15:32:04.837 GMT+03:00] [HATA] [AniList] [AniList] ! Güncellenemedi: 真希ちゃんとなう。
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Hata: java.lang.IllegalStateException: AniList liste kaydının bu medya ile eşleştiği doğrulanamadı: 真希ちゃんとなう。
     at com.kitsugi.animelist.data.auth.AniListSyncManager.updateAniListEntry(?:718)
     at com.kitsugi.animelist.data.auth.AniListSyncManager.updateAniListEntry$default(?:40)
     at c7.r1.invokeSuspend(?:26941)
     at kotlin.coroutines.jvm.internal.BaseContinuationImpl.resumeWith(?:11)
     at kotlinx.coroutines.UndispatchedCoroutine.afterResume(?:30)
     at kotlinx.coroutines.AbstractCoroutine.resumeWith(?:13)
   
   Kaynak platform kayıtları (5):
   Kayıt 1:
   Başlık: Maki-chan to Nau.
   İngilizce başlık: With Maki-chan
   Japonca başlık: 真希ちゃんとなう。
   Tür/yıl: Anime / 2012
   Kaynak: anilist
   Harici kimlikler: Anime:mal:12375
   Ham kimlik alanları: MAL ID=12375 (MAL), AniList kayıt ID=495061096, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=4/4, cilt=0, puan=7
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 2:
   Başlık: Maki-chan to Now.
   Japonca başlık: 真希ちゃんとなう。
   Tür/yıl: Anime / 2012
   Kaynak: mal
   Harici kimlikler: Anime:mal:12375
   Ham kimlik alanları: MAL ID=12375 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=4/4, cilt=0, puan=7
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 3:
   Başlık: Maki-chan to Now.
   Japonca başlık: 真希ちゃんとなう。
   Tür/yıl: Anime / 2012
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:6718
   Ham kimlik alanları: MAL ID=300006718 (dahili Kitsu kimliği, MAL değil: Kitsu #6718), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=4/4, cilt=0, puan=7
   Tarihler: başlangıç=2026-10-07, bitiş=2026-10-07; favori=false
   
   Kayıt 4:
   Başlık: Maki-chan to Now.
   Tür/yıl: Anime / 2012
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:12375, Anime:shikimori:12375
   Ham kimlik alanları: MAL ID=12375 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=4/4, cilt=0, puan=7
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 5:
   Başlık: 真希ちゃんとなう。
   Japonca başlık: 真希ちゃんとなう。
   Tür/yıl: Anime / 2012
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:54604
   Ham kimlik alanları: MAL ID=500054604 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=4/4, cilt=0, puan=7
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Eşitleme için birleştirilen değerler:
   Başlık: 真希ちゃんとなう。
   İngilizce başlık: With Maki-chan
   Japonca başlık: 真希ちゃんとなう。
   Tür/yıl: Anime / 2012
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:12375
   Ham kimlik alanları: MAL ID=12375 (MAL), AniList kayıt ID=495061096, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=4/4, cilt=0, puan=7
   Tarihler: başlangıç=2026-10-07, bitiş=2026-10-07; favori=false
   
   Kimlik güvencesi: Güvenilir (MAL/Shikimori kaydının kendi kimliği)
```

## Sorun 8 · HATA · Bangumi

- Rapor satırları: `545–625`
- Zaman: `2026-10-24 15:32:13.286 GMT+03:00`
- Kod: `KTS-BGM-6001`
- İşlem / neden: `update_error` / `http_400_rejected`
- Tüm olay no: `1343`

```text
8. [2026-10-24 15:32:13.286 GMT+03:00] [HATA] [Bangumi] [Bangumi] ! Güncellenemedi: R²[rise R to the second power] (Bangumi bölüm ilerlemesi yazılamadı (R²[rise R to the second power]): Bangumi isteği reddetti (400): Accepted — /subject/324778/update/watched_eps?watched_eps=1— sunucu: Accepted — /subject/324778/update/watched_eps?watched_eps=1)
   Kod: KTS-BGM-6001
   | KTS-BGM-6001 · ERROR · BGM
   | TR — Bangumi parametre hatası (400)
   | Neden: Bangumi API'si `nsfw` filtresinin metin ("include") olarak gönderilmesini kabul etmez; JSON `null`/`true` bekler. Metin gönderilirse arama HTTP 400 ile tamamen boş döner.
   | Çözüm: Uygulama doğru JSON biçimini kullanır; hata sürüyorsa raporu paylaşın.
   | EN — Bangumi parameter error (400)
   | Why: The Bangumi API rejects the `nsfw` filter sent as a string ("include") and expects JSON `null`/`true`. Sending text makes the search return HTTP 400 and an empty result.
   | Fix: The app uses the correct JSON form; share the report if the error persists.
   Kaynak platform kayıtları (6):
   Kayıt 1:
   Başlık: R² [rise R to the second power]
   Japonca başlık: R² [rise R to the second power]
   Tür/yıl: Anime / 2005
   Kaynak: anilist
   Harici kimlikler: Anime:mal:14023
   Ham kimlik alanları: MAL ID=14023 (MAL), AniList kayıt ID=600512934, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=7
   Tarihler: başlangıç=2026-10-04, bitiş=2026-10-04; favori=false
   
   Kayıt 2:
   Başlık: R²: Rise R to the Second Power
   Japonca başlık: R²[rise R to the second power]
   Tür/yıl: Anime / 2005
   Kaynak: mal
   Harici kimlikler: Anime:mal:14023
   Ham kimlik alanları: MAL ID=14023 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=7
   Tarihler: başlangıç=2026-10-04, bitiş=2026-10-04; favori=false
   
   Kayıt 3:
   Başlık: R2: Rise R to the Second Power
   Tür/yıl: Anime / 2005
   Kaynak: simkl
   Harici kimlikler: Anime:mal:14023, Anime:simkl:36453
   Ham kimlik alanları: MAL ID=14023 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=36453, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=7
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 4:
   Başlık: R²: Rise R to the Second Power
   Japonca başlık: R²[rise R to the second power]
   Tür/yıl: Anime / 2005
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:7068
   Ham kimlik alanları: MAL ID=300007068 (dahili Kitsu kimliği, MAL değil: Kitsu #7068), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=7
   Tarihler: başlangıç=2026-10-04, bitiş=2026-10-04; favori=false
   
   Kayıt 5:
   Başlık: R²: Rise R to the Second Power
   Tür/yıl: Anime / 2005
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:14023, Anime:shikimori:14023
   Ham kimlik alanları: MAL ID=14023 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=7
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 6:
   Başlık: R²[rise R to the second power]
   Japonca başlık: R²[rise R to the second power]
   Tür/yıl: Anime / 2005
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:324778
   Ham kimlik alanları: MAL ID=500324778 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=0/?, cilt=0, puan=7
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Eşitleme için birleştirilen değerler:
   Başlık: R²[rise R to the second power]
   Japonca başlık: R² [rise R to the second power]
   Tür/yıl: Anime / 2005
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:14023, Anime:simkl:36453
   Ham kimlik alanları: MAL ID=14023 (MAL), AniList kayıt ID=600512934, MAL liste ID=yok, Simkl ID=36453, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/?, cilt=0, puan=7
   Tarihler: başlangıç=2026-10-04, bitiş=2026-10-04; favori=false
   
   Kimlik güvencesi: Gerek yok (tüm hedef platformlarda kayıt zaten var)
   
   Bangumi bölüm ilerlemesi yazılamadı (R²[rise R to the second power]): Bangumi isteği reddetti (400): Accepted — /subject/324778/update/watched_eps?watched_eps=1— sunucu: Accepted — /subject/324778/update/watched_eps?watched_eps=1
```

## Sorun 9 · UYARI · Eşleştirme

- Rapor satırları: `626–693`
- Zaman: `2026-10-24 15:32:20.702 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `1379`

```text
9. [2026-10-24 15:32:20.702 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Hataraku Maou-sama!
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: Hataraku Maou-sama!
   İngilizce başlık: The Devil is a Part-Timer!
   Japonca başlık: はたらく魔王さま!
   Tür/yıl: Anime / 2013
   Kaynak: anilist
   Harici kimlikler: Anime:mal:15809
   Ham kimlik alanları: MAL ID=15809 (MAL), AniList kayıt ID=509715744, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/13, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Hataraku Maou-sama!
   İngilizce başlık: The Devil is a Part-Timer!
   Japonca başlık: はたらく魔王さま!
   Tür/yıl: Anime / 2013
   Kaynak: mal
   Harici kimlikler: Anime:mal:15809
   Ham kimlik alanları: MAL ID=15809 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/13, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Hataraku Maou-sama!
   Tür/yıl: Anime / 2013
   Kaynak: simkl
   Harici kimlikler: Anime:mal:15809, Anime:simkl:38084, Anime:tmdb:45997
   Ham kimlik alanları: MAL ID=15809 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=38084, TMDB ID=45997
   Durum/ilerleme: Planlandı, bölüm=0/13, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Hataraku Maou-sama!
   İngilizce başlık: The Devil is a Part-Timer!
   Japonca başlık: はたらく魔王さま!
   Tür/yıl: Anime / 2013
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:7314
   Ham kimlik alanları: MAL ID=300007314 (dahili Kitsu kimliği, MAL değil: Kitsu #7314), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/13, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Hataraku Maou-sama!
   Tür/yıl: Anime / 2013
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:15809, Anime:shikimori:15809
   Ham kimlik alanları: MAL ID=15809 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/13, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: DEVIL SURVIVOR 2 the ANIMATION
   Japonca başlık: DEVIL SURVIVOR 2 the ANIMATION
   Tür/yıl: Anime / 2013
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:56094
   Ham kimlik alanları: MAL ID=500056094 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/13, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 10 · UYARI · Eşleştirme

- Rapor satırları: `695–753`
- Zaman: `2026-10-24 15:32:20.709 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `1384`

```text
10. [2026-10-24 15:32:20.709 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Chuunibyou demo Koi ga Shitai!: DEPTH OF FIELD - Ai to Nikushimi Gekijou
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: Chuunibyou demo Koi ga Shitai!: DEPTH OF FIELD - Ai to Nikushimi Gekijou
   İngilizce başlık: Love, Chunibyo & Other Delusions: Depth of Field - Ai to Nikushimi Gekijou
   Japonca başlık: 中二病でも恋がしたい！DEPTH OF FIELD ～ 愛と憎しみ劇場
   Tür/yıl: Anime / 2013
   Kaynak: anilist
   Harici kimlikler: Anime:mal:15879
   Ham kimlik alanları: MAL ID=15879 (MAL), AniList kayıt ID=495060872, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/7, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Chuunibyou demo Koi ga Shitai! Depth of Field: Ai to Nikushimi Gekijou
   İngilizce başlık: Love, Chunibyo & Other Delusions! Depth of Field: Love and Hate Theater
   Japonca başlık: 中二病でも恋がしたい！DEPTH OF FIELD ～ 愛と憎しみ劇場
   Tür/yıl: Anime / 2012
   Kaynak: mal
   Harici kimlikler: Anime:mal:15879
   Ham kimlik alanları: MAL ID=15879 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/7, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Chuunibyou demo Koi ga Shitai!: Depth of Field - Ai to Nikushimi Gekijou
   İngilizce başlık: Love, Chunibyo & Other Delusions! Specials
   Japonca başlık: 中二病でも恋がしたい！DEPTH OF FIELD ～ 愛と憎しみ劇場
   Tür/yıl: Anime / 2012
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:7330
   Ham kimlik alanları: MAL ID=300007330 (dahili Kitsu kimliği, MAL değil: Kitsu #7330), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/7, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Chuunibyou demo Koi ga Shitai! Depth of Field: Ai to Nikushimi Gekijou
   Tür/yıl: Anime / 2012
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:15879, Anime:shikimori:15879
   Ham kimlik alanları: MAL ID=15879 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/7, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: 中二病でも恋がしたい！Lite
   Japonca başlık: 中二病でも恋がしたい！Lite
   Tür/yıl: Anime / 2012
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:50331
   Ham kimlik alanları: MAL ID=500050331 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/6, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 11 · HATA · AniList

- Rapor satırları: `755–845`
- Zaman: `2026-10-24 15:32:24.959 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `update_error` / `identity_unverified`
- Tüm olay no: `1426`

```text
11. [2026-10-24 15:32:24.959 GMT+03:00] [HATA] [AniList] [AniList] ! Güncellenemedi: ゴールデンタイム
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Hata: java.lang.IllegalStateException: AniList liste kaydının bu medya ile eşleştiği doğrulanamadı: ゴールデンタイム
     at com.kitsugi.animelist.data.auth.AniListSyncManager.updateAniListEntry(?:718)
     at com.kitsugi.animelist.data.auth.AniListSyncManager.updateAniListEntry$default(?:40)
     at c7.r1.invokeSuspend(?:26941)
     at kotlin.coroutines.jvm.internal.BaseContinuationImpl.resumeWith(?:11)
     at kotlinx.coroutines.UndispatchedCoroutine.afterResume(?:30)
     at kotlinx.coroutines.AbstractCoroutine.resumeWith(?:13)
   
   Kaynak platform kayıtları (6):
   Kayıt 1:
   Başlık: Golden Time
   İngilizce başlık: Golden Time
   Japonca başlık: ゴールデンタイム
   Tür/yıl: Anime / 2013
   Kaynak: anilist
   Harici kimlikler: Anime:mal:17895
   Ham kimlik alanları: MAL ID=17895 (MAL), AniList kayıt ID=495060951, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=24/24, cilt=0, puan=8
   Tarihler: başlangıç=2023-06-08, bitiş=yok; favori=true
   
   Kayıt 2:
   Başlık: Golden Time
   İngilizce başlık: Golden Time
   Japonca başlık: ゴールデンタイム
   Tür/yıl: Anime / 2013
   Kaynak: mal
   Harici kimlikler: Anime:mal:17895
   Ham kimlik alanları: MAL ID=17895 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=24/24, cilt=0, puan=8
   Tarihler: başlangıç=2023-06-08, bitiş=yok; favori=false
   
   Kayıt 3:
   Başlık: Golden Time
   Tür/yıl: Anime / 2013
   Kaynak: simkl
   Harici kimlikler: Anime:mal:17895, Anime:simkl:43405, Anime:tmdb:67389
   Ham kimlik alanları: MAL ID=17895 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=43405, TMDB ID=67389
   Durum/ilerleme: Tamamlandı, bölüm=24/24, cilt=0, puan=8
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 4:
   Başlık: Golden Time
   İngilizce başlık: Golden Time
   Japonca başlık: ゴールデンタイム
   Tür/yıl: Anime / 2013
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:7708
   Ham kimlik alanları: MAL ID=300007708 (dahili Kitsu kimliği, MAL değil: Kitsu #7708), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=24/24, cilt=0, puan=8
   Tarihler: başlangıç=2023-06-08, bitiş=2025-02-20; favori=false
   
   Kayıt 5:
   Başlık: Golden Time
   Tür/yıl: Anime / 2013
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:17895, Anime:shikimori:17895
   Ham kimlik alanları: MAL ID=17895 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=24/24, cilt=0, puan=8
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 6:
   Başlık: ゴールデンタイム
   Japonca başlık: ゴールデンタイム
   Tür/yıl: Anime / 2013
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:68031
   Ham kimlik alanları: MAL ID=500068031 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=24/24, cilt=0, puan=8
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Eşitleme için birleştirilen değerler:
   Başlık: ゴールデンタイム
   İngilizce başlık: Golden Time
   Japonca başlık: ゴールデンタイム
   Tür/yıl: Anime / 2013
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:17895, Anime:simkl:43405, Anime:tmdb:67389
   Ham kimlik alanları: MAL ID=17895 (MAL), AniList kayıt ID=495060951, MAL liste ID=yok, Simkl ID=43405, TMDB ID=67389
   Durum/ilerleme: Tamamlandı, bölüm=24/24, cilt=0, puan=8
   Tarihler: başlangıç=2023-06-08, bitiş=2025-02-20; favori=true
   
   Kimlik güvencesi: Gerek yok (tüm hedef platformlarda kayıt zaten var)
```

## Sorun 12 · UYARI · Eşleştirme

- Rapor satırları: `847–914`
- Zaman: `2026-10-24 15:32:27.019 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `1436`

```text
12. [2026-10-24 15:32:27.019 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Kakumeiki Valvrave 2
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: Kakumeiki Valvrave 2
   İngilizce başlık: Valvrave the Liberator 2
   Japonca başlık: 革命機ヴァルヴレイヴ 2
   Tür/yıl: Anime / 2013
   Kaynak: anilist
   Harici kimlikler: Anime:mal:18295
   Ham kimlik alanları: MAL ID=18295 (MAL), AniList kayıt ID=503318608, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Kakumeiki Valvrave 2nd Season
   İngilizce başlık: Valvrave the Liberator 2nd Season
   Japonca başlık: 革命機ヴァルヴレイヴ　2ndシーズン
   Tür/yıl: Anime / 2013
   Kaynak: mal
   Harici kimlikler: Anime:mal:18295
   Ham kimlik alanları: MAL ID=18295 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Kakumeiki Valvrave
   Tür/yıl: Anime / 2013
   Kaynak: simkl
   Harici kimlikler: Anime:mal:18295, Anime:simkl:44636
   Ham kimlik alanları: MAL ID=18295 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=44636, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Kakumeiki Valvrave 2nd Season
   İngilizce başlık: Valvrave the Liberator 2nd Season
   Japonca başlık: 革命機ヴァルヴレイヴ　2ndシーズン
   Tür/yıl: Anime / 2013
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:7698
   Ham kimlik alanları: MAL ID=300007698 (dahili Kitsu kimliği, MAL değil: Kitsu #7698), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Kakumeiki Valvrave 2nd Season
   Tür/yıl: Anime / 2013
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:18295, Anime:shikimori:18295
   Ham kimlik alanları: MAL ID=18295 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: 革命機ヴァルヴレイヴ 2ndシーズン
   Japonca başlık: 革命機ヴァルヴレイヴ 2ndシーズン
   Tür/yıl: Anime / 2013
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:70131
   Ham kimlik alanları: MAL ID=500070131 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 13 · UYARI · Eşleştirme

- Rapor satırları: `916–962`
- Zaman: `2026-10-24 15:32:46.900 GMT+03:00`
- Kod: `—`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `1540`

```text
13. [2026-10-24 15:32:46.900 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Date A Live II: Kurumi Star Festival
   Başlık: Date A Live II: Kurumi Star Festival
   Japonca başlık: デート・ア・ライブ II 狂三スターフェスティバル
   Tür/yıl: Anime / 2014
   Kaynak: anilist
   Harici kimlikler: Anime:mal:22961
   Ham kimlik alanları: MAL ID=22961 (MAL), AniList kayıt ID=495060890, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=8
   Tarihler: başlangıç=2026-10-06, bitiş=2026-10-06; favori=false
   
   
   Başlık: Date A Live II: Kurumi Star Festival
   Japonca başlık: デート・ア・ライブII 狂三スターフェスティバル
   Tür/yıl: Anime / 2014
   Kaynak: mal
   Harici kimlikler: Anime:mal:22961
   Ham kimlik alanları: MAL ID=22961 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=8
   Tarihler: başlangıç=2026-10-06, bitiş=2026-10-06; favori=false
   
   
   Başlık: Date a Live II: Kurumi Star Festival
   Tür/yıl: Anime / 2014
   Kaynak: simkl
   Harici kimlikler: Anime:mal:22961, Anime:simkl:49776
   Ham kimlik alanları: MAL ID=22961 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=49776, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=8
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Date A Live: Encore
   Japonca başlık: デート・ア・ライブ　アンコール
   Tür/yıl: Anime / 2014
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:8511
   Ham kimlik alanları: MAL ID=300008511 (dahili Kitsu kimliği, MAL değil: Kitsu #8511), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=8
   Tarihler: başlangıç=2026-10-06, bitiş=2026-10-06; favori=false
   
   
   Başlık: Date A Live II: Kurumi Star Festival
   Tür/yıl: Anime / 2014
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:22961, Anime:shikimori:22961
   Ham kimlik alanları: MAL ID=22961 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=8
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 14 · UYARI · Eşleştirme

- Rapor satırları: `964–1031`
- Zaman: `2026-10-24 15:32:46.906 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `1545`

```text
14. [2026-10-24 15:32:46.906 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Fate/stay night [Heaven's Feel] I. presage flower
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: Fate/stay night [Heaven's Feel] I. presage flower
   İngilizce başlık: Fate/stay night [Heaven's Feel] I. presage flower
   Japonca başlık: Fate/stay night[Heaven's Feel] Ⅰ.presage flower
   Tür/yıl: Anime / 2017
   Kaynak: anilist
   Harici kimlikler: Anime:mal:25537
   Ham kimlik alanları: MAL ID=25537 (MAL), AniList kayıt ID=495060925, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Fate/stay night Movie: Heaven's Feel - I. Presage Flower
   İngilizce başlık: Fate/stay night: Heaven's Feel - I. Presage Flower
   Japonca başlık: 劇場版「Fate/stay night [Heaven's Feel] Ⅰ.presage flower」
   Tür/yıl: Anime / 2017
   Kaynak: mal
   Harici kimlikler: Anime:mal:25537
   Ham kimlik alanları: MAL ID=25537 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Gekijouban Fate/Stay Night: Heaven's Feel
   Tür/yıl: Anime / 2017
   Kaynak: simkl
   Harici kimlikler: Anime:mal:25537, Anime:simkl:52810, Anime:tmdb:283984
   Ham kimlik alanları: MAL ID=25537 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=52810, TMDB ID=283984
   Durum/ilerleme: Planlandı, bölüm=0/3, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Gekijouban Fate/stay night: Heaven's Feel I. Presage Flower
   İngilizce başlık: Fate/stay night: Heaven's Feel I. Presage Flower
   Japonca başlık: 劇場版「Fate/stay night [Heaven's Feel] Ⅰ.presage flower」
   Tür/yıl: Anime / 2017
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:8675
   Ham kimlik alanları: MAL ID=300008675 (dahili Kitsu kimliği, MAL değil: Kitsu #8675), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Fate/stay night Movie: Heaven's Feel - I. Presage Flower
   Tür/yıl: Anime / 2017
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:25537, Anime:shikimori:25537
   Ham kimlik alanları: MAL ID=25537 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: 劇場版 Fate/stay night [Heaven's Feel] I.presage flower
   Japonca başlık: 劇場版 Fate/stay night [Heaven's Feel] I.presage flower
   Tür/yıl: Anime / 2017
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:109375
   Ham kimlik alanları: MAL ID=500109375 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 15 · UYARI · Eşleştirme

- Rapor satırları: `1033–1099`
- Zaman: `2026-10-24 15:32:46.907 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `1546`

```text
15. [2026-10-24 15:32:46.907 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Fate/stay night: Unlimited Blade Works 2nd Season
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: Fate/stay night: Unlimited Blade Works 2nd Season
   İngilizce başlık: Fate/stay night: Unlimited Blade Works 2nd Season
   Japonca başlık: Fate/stay night [Unlimited Blade Works] 2ndシーズン
   Tür/yıl: Anime / 2015
   Kaynak: anilist
   Harici kimlikler: Anime:mal:28701
   Ham kimlik alanları: MAL ID=28701 (MAL), AniList kayıt ID=495060929, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/13, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Fate/stay night: Unlimited Blade Works 2nd Season
   İngilizce başlık: Fate/stay night [Unlimited Blade Works] Season 2
   Japonca başlık: Fate/stay night [Unlimited Blade Works] 2nd シーズン
   Tür/yıl: Anime / 2015
   Kaynak: mal
   Harici kimlikler: Anime:mal:28701
   Ham kimlik alanları: MAL ID=28701 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/13, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Fate/Stay Night: Unlimited Blade Works
   Tür/yıl: Anime / 2015
   Kaynak: simkl
   Harici kimlikler: Anime:mal:28701, Anime:simkl:52914
   Ham kimlik alanları: MAL ID=28701 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=52914, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/13, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Fate/stay night: Unlimited Blade Works 2nd Season
   Japonca başlık: Fate/stay night [Unlimited Blade Works] 2nd シーズン
   Tür/yıl: Anime / 2015
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:10052
   Ham kimlik alanları: MAL ID=300010052 (dahili Kitsu kimliği, MAL değil: Kitsu #10052), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/13, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Fate/stay night: Unlimited Blade Works 2nd Season
   Tür/yıl: Anime / 2015
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:28701, Anime:shikimori:28701
   Ham kimlik alanları: MAL ID=28701 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/13, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Fate/stay night [Unlimited Blade Works] 2ndシーズン
   Japonca başlık: Fate/stay night [Unlimited Blade Works] 2ndシーズン
   Tür/yıl: Anime / 2015
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:109386
   Ham kimlik alanları: MAL ID=500109386 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/13, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 16 · UYARI · Eşleştirme

- Rapor satırları: `1101–1168`
- Zaman: `2026-10-24 15:32:50.522 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `1575`

```text
16. [2026-10-24 15:32:50.522 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Dungeon ni Deai wo Motomeru no wa Machigatteiru Darou ka
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: Dungeon ni Deai wo Motomeru no wa Machigatteiru Darou ka
   İngilizce başlık: Is It Wrong to Try to Pick Up Girls in a Dungeon?
   Japonca başlık: ダンジョンに出会いを求めるのは間違っているだろうか
   Tür/yıl: Anime / 2015
   Kaynak: anilist
   Harici kimlikler: Anime:mal:28121
   Ham kimlik alanları: MAL ID=28121 (MAL), AniList kayıt ID=495060899, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=13/13, cilt=0, puan=7
   Tarihler: başlangıç=2025-05-15, bitiş=2026-10-04; favori=false
   
   
   Başlık: Dungeon ni Deai wo Motomeru no wa Machigatteiru Darou ka
   İngilizce başlık: Is It Wrong to Try to Pick Up Girls in a Dungeon?
   Japonca başlık: ダンジョンに出会いを求めるのは間違っているだろうか
   Tür/yıl: Anime / 2015
   Kaynak: mal
   Harici kimlikler: Anime:mal:28121
   Ham kimlik alanları: MAL ID=28121 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=13/13, cilt=0, puan=7
   Tarihler: başlangıç=2025-05-15, bitiş=2026-10-04; favori=false
   
   
   Başlık: Dungeon ni Deai o Motomeru no wa Machigatte Iru Darouka: Familia Myth
   Tür/yıl: Anime / 2015
   Kaynak: simkl
   Harici kimlikler: Anime:mal:28121, Anime:simkl:428658, Anime:tmdb:62745
   Ham kimlik alanları: MAL ID=28121 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=428658, TMDB ID=62745
   Durum/ilerleme: Tamamlandı, bölüm=13/13, cilt=0, puan=7
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Dungeon ni Deai wo Motomeru no wa Machigatteiru Darou ka
   İngilizce başlık: Is It Wrong to Try to Pick Up Girls in a Dungeon?
   Japonca başlık: ダンジョンに出会いを求めるのは間違っているだろうか
   Tür/yıl: Anime / 2015
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:9962
   Ham kimlik alanları: MAL ID=300009962 (dahili Kitsu kimliği, MAL değil: Kitsu #9962), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=13/13, cilt=0, puan=7
   Tarihler: başlangıç=2024-10-23, bitiş=2025-10-23; favori=false
   
   
   Başlık: Dungeon ni Deai wo Motomeru no wa Machigatteiru Darou ka
   Tür/yıl: Anime / 2015
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:28121, Anime:shikimori:28121
   Ham kimlik alanları: MAL ID=28121 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=13/13, cilt=0, puan=7
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: ダンジョンに出会いを求めるのは間違っているだろうか
   Japonca başlık: ダンジョンに出会いを求めるのは間違っているだろうか
   Tür/yıl: Anime / 2015
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:116287
   Ham kimlik alanları: MAL ID=500116287 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=13/13, cilt=0, puan=7
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 17 · UYARI · Eşleştirme

- Rapor satırları: `1170–1237`
- Zaman: `2026-10-24 15:33:02.427 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `1608`

```text
17. [2026-10-24 15:33:02.427 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Grisaia no Meikyuu
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: Grisaia no Meikyuu
   İngilizce başlık: The Labyrinth of Grisaia
   Japonca başlık: グリザイアの迷宮
   Tür/yıl: Anime / 2015
   Kaynak: anilist
   Harici kimlikler: Anime:mal:29093
   Ham kimlik alanları: MAL ID=29093 (MAL), AniList kayıt ID=495060956, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Grisaia no Meikyuu: Caprice no Mayu 0
   İngilizce başlık: The Labyrinth of Grisaia: The Cocoon of Caprice 0
   Japonca başlık: グリザイアの迷宮 カプリスの繭0
   Tür/yıl: Anime / 2015
   Kaynak: mal
   Harici kimlikler: Anime:mal:29093
   Ham kimlik alanları: MAL ID=29093 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Grisaia no Meikyuu: Caprice no Mayu 0
   Tür/yıl: Anime / 2015
   Kaynak: simkl
   Harici kimlikler: Anime:mal:29093, Anime:simkl:454188
   Ham kimlik alanları: MAL ID=29093 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=454188, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Grisaia no Meikyuu: Caprice no Mayu 0
   İngilizce başlık: The Labyrinth of Grisaia: The Cocoon of Caprice 0
   Japonca başlık: グリザイアの迷宮 カプリスの繭0
   Tür/yıl: Anime / 2015
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:10154
   Ham kimlik alanları: MAL ID=300010154 (dahili Kitsu kimliği, MAL değil: Kitsu #10154), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Grisaia no Meikyuu: Caprice no Mayu 0
   Tür/yıl: Anime / 2015
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:29093, Anime:shikimori:29093
   Ham kimlik alanları: MAL ID=29093 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: グリザイアの迷宮
   Japonca başlık: グリザイアの迷宮
   Tür/yıl: Anime / 2015
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:121187
   Ham kimlik alanları: MAL ID=500121187 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 18 · UYARI · Eşleştirme

- Rapor satırları: `1239–1304`
- Zaman: `2026-10-24 15:33:14.270 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `1664`

```text
18. [2026-10-24 15:33:14.270 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Phantasy Star Online 2: The Animation
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: Phantasy Star Online 2: The Animation
   İngilizce başlık: Phantasy Star Online 2 The Animation
   Japonca başlık: ファンタシースターオンライン２ ジ アニメーション
   Tür/yıl: Anime / 2016
   Kaynak: anilist
   Harici kimlikler: Anime:mal:31223
   Ham kimlik alanları: MAL ID=31223 (MAL), AniList kayıt ID=503318417, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Phantasy Star Online 2 The Animation
   Japonca başlık: ファンタシースターオンライン２ ジ アニメーション
   Tür/yıl: Anime / 2016
   Kaynak: mal
   Harici kimlikler: Anime:mal:31223
   Ham kimlik alanları: MAL ID=31223 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Phantasy Star Online 2 the Animation
   Tür/yıl: Anime / 2016
   Kaynak: simkl
   Harici kimlikler: Anime:mal:31223, Anime:simkl:508994, Anime:tmdb:65209
   Ham kimlik alanları: MAL ID=31223 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=508994, TMDB ID=65209
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Phantasy Star Online 2 The Animation
   Japonca başlık: ファンタシースターオンライン２ ジ アニメーション
   Tür/yıl: Anime / 2016
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:11200
   Ham kimlik alanları: MAL ID=300011200 (dahili Kitsu kimliği, MAL değil: Kitsu #11200), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Phantasy Star Online 2 The Animation
   Tür/yıl: Anime / 2016
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:31223, Anime:shikimori:31223
   Ham kimlik alanları: MAL ID=31223 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: PSO2
   Japonca başlık: ファンタシースターオンライン2 the ANIMATION
   Tür/yıl: Anime / 2016
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:139830
   Ham kimlik alanları: MAL ID=500139830 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 19 · HATA · AniList

- Rapor satırları: `1306–1396`
- Zaman: `2026-10-24 15:33:15.863 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `update_error` / `identity_unverified`
- Tüm olay no: `1675`

```text
19. [2026-10-24 15:33:15.863 GMT+03:00] [HATA] [AniList] [AniList] ! Güncellenemedi: Re:ゼロから始める異世界生活
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Hata: java.lang.IllegalStateException: AniList liste kaydının bu medya ile eşleştiği doğrulanamadı: Re:ゼロから始める異世界生活
     at com.kitsugi.animelist.data.auth.AniListSyncManager.updateAniListEntry(?:718)
     at com.kitsugi.animelist.data.auth.AniListSyncManager.updateAniListEntry$default(?:40)
     at c7.r1.invokeSuspend(?:26941)
     at kotlin.coroutines.jvm.internal.BaseContinuationImpl.resumeWith(?:11)
     at kotlinx.coroutines.UndispatchedCoroutine.afterResume(?:30)
     at kotlinx.coroutines.AbstractCoroutine.resumeWith(?:13)
   
   Kaynak platform kayıtları (6):
   Kayıt 1:
   Başlık: Re:Zero kara Hajimeru Isekai Seikatsu
   İngilizce başlık: Re:ZERO -Starting Life in Another World-
   Japonca başlık: Re:ゼロから始める異世界生活
   Tür/yıl: Anime / 2016
   Kaynak: anilist
   Harici kimlikler: Anime:mal:31240
   Ham kimlik alanları: MAL ID=31240 (MAL), AniList kayıt ID=495061191, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=25/25, cilt=0, puan=8
   Tarihler: başlangıç=2023-01-23, bitiş=2025-02-21; favori=true
   
   Kayıt 2:
   Başlık: Re:Zero kara Hajimeru Isekai Seikatsu
   İngilizce başlık: Re:ZERO -Starting Life in Another World-
   Japonca başlık: Re:ゼロから始める異世界生活
   Tür/yıl: Anime / 2016
   Kaynak: mal
   Harici kimlikler: Anime:mal:31240
   Ham kimlik alanları: MAL ID=31240 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=25/25, cilt=0, puan=8
   Tarihler: başlangıç=2023-01-23, bitiş=2025-02-21; favori=false
   
   Kayıt 3:
   Başlık: Re:Zero kara Hajimeru Isekai Seikatsu
   Tür/yıl: Anime / 2016
   Kaynak: simkl
   Harici kimlikler: Anime:mal:31240, Anime:simkl:509292, Anime:tmdb:65942
   Ham kimlik alanları: MAL ID=31240 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=509292, TMDB ID=65942
   Durum/ilerleme: Tamamlandı, bölüm=25/25, cilt=0, puan=8
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 4:
   Başlık: Re:Zero kara Hajimeru Isekai Seikatsu
   İngilizce başlık: Re:ZERO -Starting Life in Another World-
   Japonca başlık: Re：ゼロから始める異世界生活
   Tür/yıl: Anime / 2016
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:11209
   Ham kimlik alanları: MAL ID=300011209 (dahili Kitsu kimliği, MAL değil: Kitsu #11209), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=25/25, cilt=0, puan=8
   Tarihler: başlangıç=2025-02-21, bitiş=2025-02-21; favori=false
   
   Kayıt 5:
   Başlık: Re:Zero kara Hajimeru Isekai Seikatsu
   Tür/yıl: Anime / 2016
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:31240, Anime:shikimori:31240
   Ham kimlik alanları: MAL ID=31240 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=25/25, cilt=0, puan=8
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 6:
   Başlık: Re:ゼロから始める異世界生活
   Japonca başlık: Re:ゼロから始める異世界生活
   Tür/yıl: Anime / 2016
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:140001
   Ham kimlik alanları: MAL ID=500140001 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=25/25, cilt=0, puan=9
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Eşitleme için birleştirilen değerler:
   Başlık: Re:ゼロから始める異世界生活
   İngilizce başlık: Re:ZERO -Starting Life in Another World-
   Japonca başlık: Re:ゼロから始める異世界生活
   Tür/yıl: Anime / 2016
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:31240, Anime:simkl:509292, Anime:tmdb:65942
   Ham kimlik alanları: MAL ID=31240 (MAL), AniList kayıt ID=495061191, MAL liste ID=yok, Simkl ID=509292, TMDB ID=65942
   Durum/ilerleme: Tamamlandı, bölüm=25/25, cilt=0, puan=9
   Tarihler: başlangıç=2023-01-23, bitiş=2025-02-21; favori=true
   
   Kimlik güvencesi: Gerek yok (tüm hedef platformlarda kayıt zaten var)
```

## Sorun 20 · UYARI · Eşleştirme

- Rapor satırları: `1398–1447`
- Zaman: `2026-10-24 15:33:20.185 GMT+03:00`
- Kod: `—`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `1683`

```text
20. [2026-10-24 15:33:20.185 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Masou Gakuen H×H
   Başlık: Masou Gakuen H×H
   İngilizce başlık: Hybrid x Heart Magias Academy Ataraxia
   Japonca başlık: 魔装学園H×H
   Tür/yıl: Anime / 2016
   Kaynak: anilist
   Harici kimlikler: Anime:mal:31845
   Ham kimlik alanları: MAL ID=31845 (MAL), AniList kayıt ID=495061111, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=6
   Tarihler: başlangıç=2025-02-21, bitiş=2025-02-21; favori=false
   
   
   Başlık: Masou Gakuen HxH
   İngilizce başlık: Hybrid x Heart Magias Academy Ataraxia
   Japonca başlık: 魔装学園H×H
   Tür/yıl: Anime / 2016
   Kaynak: mal
   Harici kimlikler: Anime:mal:31845
   Ham kimlik alanları: MAL ID=31845 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=6
   Tarihler: başlangıç=2025-02-21, bitiş=2025-02-21; favori=false
   
   
   Başlık: Masou Gakuen Hybrid x Heart
   Tür/yıl: Anime / 2016
   Kaynak: simkl
   Harici kimlikler: Anime:mal:31845, Anime:simkl:525622, Anime:tmdb:67011
   Ham kimlik alanları: MAL ID=31845 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=525622, TMDB ID=67011
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=6
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Masou Gakuen HxH
   İngilizce başlık: Hybrid x Heart Magias Academy Ataraxia
   Japonca başlık: 魔装学園H×H
   Tür/yıl: Anime / 2016
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:11529
   Ham kimlik alanları: MAL ID=300011529 (dahili Kitsu kimliği, MAL değil: Kitsu #11529), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=6
   Tarihler: başlangıç=2023-04-04, bitiş=2025-02-21; favori=false
   
   
   Başlık: Masou Gakuen HxH
   Tür/yıl: Anime / 2016
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:31845, Anime:shikimori:31845
   Ham kimlik alanları: MAL ID=31845 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=6
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 21 · UYARI · Eşleştirme

- Rapor satırları: `1449–1516`
- Zaman: `2026-10-24 15:33:20.187 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `1684`

```text
21. [2026-10-24 15:33:20.187 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Gakusen Toshi Asterisk 2
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: Gakusen Toshi Asterisk 2
   İngilizce başlık: The Asterisk War 2
   Japonca başlık: 学戦都市アスタリスク 2
   Tür/yıl: Anime / 2016
   Kaynak: anilist
   Harici kimlikler: Anime:mal:31737
   Ham kimlik alanları: MAL ID=31737 (MAL), AniList kayıt ID=495060943, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=6
   Tarihler: başlangıç=2025-05-09, bitiş=2025-05-09; favori=false
   
   
   Başlık: Gakusen Toshi Asterisk 2nd Season
   İngilizce başlık: The Asterisk War Season 2
   Japonca başlık: 学戦都市アスタリスク
   Tür/yıl: Anime / 2016
   Kaynak: mal
   Harici kimlikler: Anime:mal:31737
   Ham kimlik alanları: MAL ID=31737 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=6
   Tarihler: başlangıç=2025-05-09, bitiş=2025-05-09; favori=false
   
   
   Başlık: Gakusen Toshi Asterisk
   Tür/yıl: Anime / 2016
   Kaynak: simkl
   Harici kimlikler: Anime:mal:31737, Anime:simkl:526668
   Ham kimlik alanları: MAL ID=31737 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=526668, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=6
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Gakusen Toshi Asterisk 2nd Season
   İngilizce başlık: The Asterisk War: The Academy City on the Water
   Japonca başlık: 学戦都市アスタリスク
   Tür/yıl: Anime / 2016
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:11421
   Ham kimlik alanları: MAL ID=300011421 (dahili Kitsu kimliği, MAL değil: Kitsu #11421), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=6
   Tarihler: başlangıç=2023-06-12, bitiş=2025-05-09; favori=false
   
   
   Başlık: Gakusen Toshi Asterisk 2nd Season
   Tür/yıl: Anime / 2016
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:31737, Anime:shikimori:31737
   Ham kimlik alanları: MAL ID=31737 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=6
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: 学戦都市アスタリスク 2nd SEASON
   Japonca başlık: 学戦都市アスタリスク 2nd SEASON
   Tür/yıl: Anime / 2016
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:147613
   Ham kimlik alanları: MAL ID=500147613 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=6
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 22 · UYARI · Eşleştirme

- Rapor satırları: `1518–1584`
- Zaman: `2026-10-24 15:33:21.344 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `1692`

```text
22. [2026-10-24 15:33:21.344 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Kuusen Madoushi Kouhosei no Kyoukan: Lecty no, Ikimonogatari
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: Kuusen Madoushi Kouhosei no Kyoukan: Lecty no, Ikimonogatari
   İngilizce başlık: Sky Wizards Academy OVA
   Japonca başlık: 空戦魔導士候補生の教官 レクティの, いきものがたり
   Tür/yıl: Anime / 2016
   Kaynak: anilist
   Harici kimlikler: Anime:mal:31156
   Ham kimlik alanları: MAL ID=31156 (MAL), AniList kayıt ID=503318507, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Kuusen Madoushi Kouhosei no Kyoukan: Lecty no, Ikimonogatari
   İngilizce başlık: Sky Wizards Academy OVA
   Japonca başlık: 空戦魔導士候補生の教官 レクティの, いきものがたり
   Tür/yıl: Anime / 2016
   Kaynak: mal
   Harici kimlikler: Anime:mal:31156
   Ham kimlik alanları: MAL ID=31156 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Kuusen Madoushi Kouhosei no Kyoukan: Lecty no, Ikimonogatari
   Tür/yıl: Anime / 2016
   Kaynak: simkl
   Harici kimlikler: Anime:mal:31156, Anime:simkl:510052
   Ham kimlik alanları: MAL ID=31156 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=510052, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Kuusen Madoushi Kouhosei no Kyoukan: Lecty no, Ikimonogatari
   Japonca başlık: 空戦魔導士候補生の教官 レクティの, いきものがたり
   Tür/yıl: Anime / 2016
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:11186
   Ham kimlik alanları: MAL ID=300011186 (dahili Kitsu kimliği, MAL değil: Kitsu #11186), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Kuusen Madoushi Kouhosei no Kyoukan: Lecty no, Ikimonogatari
   Tür/yıl: Anime / 2016
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:31156, Anime:shikimori:31156
   Ham kimlik alanları: MAL ID=31156 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: 空戦魔導士候補生の教官 OAD
   Japonca başlık: 空戦魔導士候補生の教官 OAD
   Tür/yıl: Anime / 2016
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:142409
   Ham kimlik alanları: MAL ID=500142409 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 23 · HATA · AniList

- Rapor satırları: `1586–1665`
- Zaman: `2026-10-24 15:33:47.512 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `update_error` / `identity_unverified`
- Tüm olay no: `1702`

```text
23. [2026-10-24 15:33:47.512 GMT+03:00] [HATA] [AniList] [AniList] ! Güncellenemedi: Aサイズ クラスメイト Anime Edition
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Hata: java.lang.IllegalStateException: AniList liste kaydının bu medya ile eşleştiği doğrulanamadı: Aサイズ クラスメイト Anime Edition
     at com.kitsugi.animelist.data.auth.AniListSyncManager.updateAniListEntry(?:718)
     at com.kitsugi.animelist.data.auth.AniListSyncManager.updateAniListEntry$default(?:40)
     at c7.r1.invokeSuspend(?:26941)
     at kotlin.coroutines.jvm.internal.BaseContinuationImpl.resumeWith(?:11)
     at kotlinx.coroutines.UndispatchedCoroutine.afterResume(?:30)
     at kotlinx.coroutines.AbstractCoroutine.resumeWith(?:13)
   
   Kaynak platform kayıtları (5):
   Kayıt 1:
   Başlık: A-Sized Classmate
   İngilizce başlık: A-Sized Classmate
   Japonca başlık: Aサイズ クラスメイト
   Tür/yıl: Anime / 2016
   Kaynak: anilist
   Harici kimlikler: Anime:mal:32484
   Ham kimlik alanları: MAL ID=32484 (MAL), AniList kayıt ID=495060816, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=2/2, cilt=0, puan=7
   Tarihler: başlangıç=2023-07-01, bitiş=yok; favori=false
   
   Kayıt 2:
   Başlık: A-Size Classmate
   Japonca başlık: Aサイズ クラスメイト
   Tür/yıl: Anime / 2016
   Kaynak: mal
   Harici kimlikler: Anime:mal:32484
   Ham kimlik alanları: MAL ID=32484 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=2/2, cilt=0, puan=7
   Tarihler: başlangıç=2023-07-01, bitiş=yok; favori=false
   
   Kayıt 3:
   Başlık: A-Size Classmate
   Japonca başlık: Aサイズ クラスメイト
   Tür/yıl: Anime / 2016
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:11903
   Ham kimlik alanları: MAL ID=300011903 (dahili Kitsu kimliği, MAL değil: Kitsu #11903), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=2/2, cilt=0, puan=7
   Tarihler: başlangıç=2023-07-01, bitiş=2026-10-07; favori=false
   
   Kayıt 4:
   Başlık: A-Size Classmate
   Tür/yıl: Anime / 2016
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:32484, Anime:shikimori:32484
   Ham kimlik alanları: MAL ID=32484 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=2/2, cilt=0, puan=7
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 5:
   Başlık: Aサイズ クラスメイト Anime Edition
   Japonca başlık: Aサイズ クラスメイト Anime Edition
   Tür/yıl: Anime / 2016
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:168641
   Ham kimlik alanları: MAL ID=500168641 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=2/2, cilt=0, puan=7
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Eşitleme için birleştirilen değerler:
   Başlık: Aサイズ クラスメイト Anime Edition
   İngilizce başlık: A-Sized Classmate
   Japonca başlık: Aサイズ クラスメイト
   Tür/yıl: Anime / 2016
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:32484
   Ham kimlik alanları: MAL ID=32484 (MAL), AniList kayıt ID=495060816, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=2/2, cilt=0, puan=7
   Tarihler: başlangıç=2023-07-01, bitiş=2026-10-07; favori=false
   
   Kimlik güvencesi: Güvenilir (MAL/Shikimori kaydının kendi kimliği)
```

## Sorun 24 · UYARI · Eşleştirme

- Rapor satırları: `1667–1734`
- Zaman: `2026-10-24 15:33:48.117 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `1710`

```text
24. [2026-10-24 15:33:48.117 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Dungeon ni Deai wo Motomeru no wa Machigatteiru Darou ka: Dungeon ni Onsen wo Motomeru no wa Machigatteiru Darou ka
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: Dungeon ni Deai wo Motomeru no wa Machigatteiru Darou ka: Dungeon ni Onsen wo Motomeru no wa Machigatteiru Darou ka
   İngilizce başlık: Is It Wrong to Try to Pick Up Girls in a Dungeon?: Is It Wrong to Expect a Hot Spring in a Dungeon?
   Japonca başlık: ダンジョンに出会いを求めるのは間違っているだろうか ダンジョンに温泉を求めるのは 間違っているだろうか
   Tür/yıl: Anime / 2016
   Kaynak: anilist
   Harici kimlikler: Anime:mal:32801
   Ham kimlik alanları: MAL ID=32801 (MAL), AniList kayıt ID=512893871, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Dungeon ni Deai wo Motomeru no wa Machigatteiru Darou ka OVA
   İngilizce başlık: Is It Wrong to Try to Pick Up Girls in a Dungeon?: Is It Wrong to Expect a Hot Spring in a Dungeon?
   Japonca başlık: ダンジョンに出会いを求めるのは間違っているだろうか OVA「ダンジョンに温泉を求めるのは 間違っているだろうか」
   Tür/yıl: Anime / 2016
   Kaynak: mal
   Harici kimlikler: Anime:mal:32801
   Ham kimlik alanları: MAL ID=32801 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Dungeon ni Deai o Motomeru no wa Machigatte Iru Darouka: Familia Myth - Dungeon ni Onsen o Motomeru no wa Machigatte Iru Darouka
   Tür/yıl: Anime / 2016
   Kaynak: simkl
   Harici kimlikler: Anime:mal:32801, Anime:simkl:562260
   Ham kimlik alanları: MAL ID=32801 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=562260, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Dungeon ni Deai wo Motomeru no wa Machigatteiru Darou ka OVA
   İngilizce başlık: Is It Wrong to Try to Pick Up Girls in a Dungeon?: Is It Wrong to Expect a Hot Spring in a Dungeon?
   Japonca başlık: ダンジョンに出会いを求めるのは間違っているだろうか OVA
   Tür/yıl: Anime / 2016
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:11851
   Ham kimlik alanları: MAL ID=300011851 (dahili Kitsu kimliği, MAL değil: Kitsu #11851), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Dungeon ni Deai wo Motomeru no wa Machigatteiru Darou ka OVA
   Tür/yıl: Anime / 2016
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:32801, Anime:shikimori:32801
   Ham kimlik alanları: MAL ID=32801 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: ダンジョンに出会いを求めるのは間違っているだろうか OVA
   Japonca başlık: ダンジョンに出会いを求めるのは間違っているだろうか OVA
   Tür/yıl: Anime / 2016
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:169942
   Ham kimlik alanları: MAL ID=500169942 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 25 · UYARI · Eşleştirme

- Rapor satırları: `1736–1793`
- Zaman: `2026-10-24 15:33:58.147 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `1731`

```text
25. [2026-10-24 15:33:58.147 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Owari no Seraph: Nagoya Kessen-hen - Owaranai Seraph Nagoya Kessen-hen
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: Owari no Seraph: Nagoya Kessen-hen - Owaranai Seraph Nagoya Kessen-hen
   İngilizce başlık: Seraph of the End: Battle in Nagoya - Owaranai Seraph Battle in Nagoya
   Japonca başlık: 終わりのセラフ 名古屋決戦編 「終わらないセラフ名古屋決戦編」
   Tür/yıl: Anime / 2016
   Kaynak: anilist
   Harici kimlikler: Anime:mal:31918
   Ham kimlik alanları: MAL ID=31918 (MAL), AniList kayıt ID=495061178, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/4, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Owaranai Seraph: Nagoya-hen
   İngilizce başlık: Seraph of the Endless: Battle in Nagoya
   Japonca başlık: 終わらないセラフ名古屋編
   Tür/yıl: Anime / 2015
   Kaynak: mal
   Harici kimlikler: Anime:mal:31918
   Ham kimlik alanları: MAL ID=31918 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/4, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Owari no Seraph: Nagoya Kessen-hen - Owaranai Seraph - Nagoya Kessen-hen
   Japonca başlık: 終わりのセラフ 名古屋決戦編 おまけアニメ「終わらないセラフ名古屋決戦編」
   Tür/yıl: Anime / 2015
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:11462
   Ham kimlik alanları: MAL ID=300011462 (dahili Kitsu kimliği, MAL değil: Kitsu #11462), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/4, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Owaranai Seraph: Nagoya-hen
   Tür/yıl: Anime / 2015
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:31918, Anime:shikimori:31918
   Ham kimlik alanları: MAL ID=31918 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/4, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: 終わりのセラフ OAD
   Japonca başlık: 終わりのセラフ OAD
   Tür/yıl: Anime / 2016
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:148096
   Ham kimlik alanları: MAL ID=500148096 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 26 · UYARI · Eşleştirme

- Rapor satırları: `1795–1862`
- Zaman: `2026-10-24 15:33:58.149 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `1732`

```text
26. [2026-10-24 15:33:58.149 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Yahari Ore no Seishun Love Come wa Machigatteiru. Zoku: Kitto, Onnanoko wa Osatou to Spice to Suteki na Nanika de Dekiteiru
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: Yahari Ore no Seishun Love Come wa Machigatteiru. Zoku: Kitto, Onnanoko wa Osatou to Spice to Suteki na Nanika de Dekiteiru
   İngilizce başlık: My Teen Romantic Comedy SNAFU TOO! OVA
   Japonca başlık: やはり俺の青春ラブコメはまちがっている。 続 「きっと、女の子はお砂糖とスパイスと素敵な何かでできている。」
   Tür/yıl: Anime / 2016
   Kaynak: anilist
   Harici kimlikler: Anime:mal:33161
   Ham kimlik alanları: MAL ID=33161 (MAL), AniList kayıt ID=513996937, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=10
   Tarihler: başlangıç=2026-10-04, bitiş=2026-10-04; favori=false
   
   
   Başlık: Yahari Ore no Seishun Love Comedy wa Machigatteiru. Zoku OVA
   İngilizce başlık: My Teen Romantic Comedy SNAFU TOO! OVA
   Japonca başlık: やはり俺の青春ラブコメはまちがっている. 続 きっと, 女の子はお砂糖とスパイスと素敵な何かでできている。
   Tür/yıl: Anime / 2016
   Kaynak: mal
   Harici kimlikler: Anime:mal:33161
   Ham kimlik alanları: MAL ID=33161 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=10
   Tarihler: başlangıç=2026-10-04, bitiş=2026-10-04; favori=false
   
   
   Başlık: Yahari Ore no Seishun Lovecome wa Machigatte Iru. Zoku: Kitto, Onnanoko wa Osatou to Spice to Suteki na Nanika de Dekite Iru.
   Tür/yıl: Anime / 2016
   Kaynak: simkl
   Harici kimlikler: Anime:mal:33161, Anime:simkl:575569
   Ham kimlik alanları: MAL ID=33161 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=575569, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=10
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Yahari Ore no Seishun Love Comedy wa Machigatteiru. Zoku OVA
   İngilizce başlık: My Teen Romantic Comedy SNAFU TOO! OVA
   Japonca başlık: やはり俺の青春ラブコメはまちがっている. 続 きっと, 女の子はお砂糖とスパイスと素敵な何かでできている。
   Tür/yıl: Anime / 2016
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:12045
   Ham kimlik alanları: MAL ID=300012045 (dahili Kitsu kimliği, MAL değil: Kitsu #12045), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=10
   Tarihler: başlangıç=2023-02-12, bitiş=2026-10-04; favori=false
   
   
   Başlık: Yahari Ore no Seishun Love Comedy wa Machigatteiru. Zoku OVA
   Tür/yıl: Anime / 2016
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:33161, Anime:shikimori:33161
   Ham kimlik alanları: MAL ID=33161 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=10
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: やはり俺の青春ラブコメはまちがっている。続 OVA
   Japonca başlık: やはり俺の青春ラブコメはまちがっている。続 OVA
   Tür/yıl: Anime / 2016
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:142678
   Ham kimlik alanları: MAL ID=500142678 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=10
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 27 · UYARI · Eşleştirme

- Rapor satırları: `1864–1919`
- Zaman: `2026-10-24 15:34:08.320 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `1747`

```text
27. [2026-10-24 15:34:08.320 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: To LOVE-Ru Darkness 2nd OVA
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: To LOVE-Ru Darkness 2nd OVA
   Japonca başlık: To LOVEる -とらぶる- ダークネス2nd
   Tür/yıl: Anime / 2016
   Kaynak: anilist
   Harici kimlikler: Anime:mal:31380
   Ham kimlik alanları: MAL ID=31380 (MAL), AniList kayıt ID=495061291, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/3, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: To LOVE-Ru Darkness 2nd OVA
   Japonca başlık: To LOVEる -とらぶる- ダークネス2nd
   Tür/yıl: Anime / 2016
   Kaynak: mal
   Harici kimlikler: Anime:mal:31380
   Ham kimlik alanları: MAL ID=31380 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/3, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: To LOVE-Ru Darkness 2nd OVA
   Japonca başlık: To LOVEる -とらぶる- ダークネス2nd
   Tür/yıl: Anime / 2016
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:11418
   Ham kimlik alanları: MAL ID=300011418 (dahili Kitsu kimliği, MAL değil: Kitsu #11418), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/3, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: To LOVE-Ru Darkness 2nd OVA
   Tür/yıl: Anime / 2016
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:31380, Anime:shikimori:31380
   Ham kimlik alanları: MAL ID=31380 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/3, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Trouble Diary Peach
   Japonca başlık: とらぶるだいあり～・ぴーち ムービー版
   Tür/yıl: Anime / 2016
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:292115
   Ham kimlik alanları: MAL ID=500292115 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 28 · UYARI · Eşleştirme

- Rapor satırları: `1921–1988`
- Zaman: `2026-10-24 15:34:08.327 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `1752`

```text
28. [2026-10-24 15:34:08.327 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Trinity Seven Movie - Yuukyuu Toshokan to Renkinjutsu Shoujo
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: Trinity Seven Movie - Yuukyuu Toshokan to Renkinjutsu Shoujo
   İngilizce başlık: Trinity Seven: Eternal Library & Alchemic Girl
   Japonca başlık: 劇場版 トリニティセブン -悠久図書館と錬金術少女-
   Tür/yıl: Anime / 2017
   Kaynak: anilist
   Harici kimlikler: Anime:mal:33581
   Ham kimlik alanları: MAL ID=33581 (MAL), AniList kayıt ID=513999875, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=8
   Tarihler: başlangıç=2026-10-04, bitiş=2026-10-04; favori=false
   
   
   Başlık: Trinity Seven Movie 1: Eternity Library to Alchemic Girl
   İngilizce başlık: Trinity Seven: Eternity Library & Alchemic Girl
   Japonca başlık: 劇場版 トリニティセブン －悠久図書館〈エターニティライブラリー〉と錬金術少女〈アルケミックガール〉－
   Tür/yıl: Anime / 2017
   Kaynak: mal
   Harici kimlikler: Anime:mal:33581
   Ham kimlik alanları: MAL ID=33581 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=8
   Tarihler: başlangıç=2026-10-04, bitiş=2026-10-04; favori=false
   
   
   Başlık: Gekijouban Trinity Seven: Eternity Library to Alchemic Girl
   Tür/yıl: Anime / 2017
   Kaynak: simkl
   Harici kimlikler: Anime:mal:33581, Anime:simkl:623561, Anime:tmdb:428292
   Ham kimlik alanları: MAL ID=33581 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=623561, TMDB ID=428292
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=8
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Trinity Seven: Yuukyuu Toshokan to Rekinjutsu Shoujo
   İngilizce başlık: Trinity Seven: Eternity Library & Alchemic Girl
   Japonca başlık: 劇場版 トリニティセブン －悠久図書館〈エターニティライブラリー〉と錬金術少女〈アルケミックガール〉－
   Tür/yıl: Anime / 2017
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:12324
   Ham kimlik alanları: MAL ID=300012324 (dahili Kitsu kimliği, MAL değil: Kitsu #12324), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=8
   Tarihler: başlangıç=2023-05-07, bitiş=2025-10-29; favori=false
   
   
   Başlık: Trinity Seven Movie 1: Eternity Library to Alchemic Girl
   Tür/yıl: Anime / 2017
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:33581, Anime:shikimori:33581
   Ham kimlik alanları: MAL ID=33581 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=8
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: 劇場版 トリニティセブン -悠久図書館と錬金術少女-
   Japonca başlık: 劇場版 トリニティセブン -悠久図書館と錬金術少女-
   Tür/yıl: Anime / 2017
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:186570
   Ham kimlik alanları: MAL ID=500186570 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=8
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 29 · HATA · AniList

- Rapor satırları: `1990–2067`
- Zaman: `2026-10-24 15:34:08.590 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `update_error` / `identity_unverified`
- Tüm olay no: `1758`

```text
29. [2026-10-24 15:34:08.590 GMT+03:00] [HATA] [AniList] [AniList] ! Güncellenemedi: 300円のおつきあい Anime Edition
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Hata: java.lang.IllegalStateException: AniList liste kaydının bu medya ile eşleştiği doğrulanamadı: 300円のおつきあい Anime Edition
     at com.kitsugi.animelist.data.auth.AniListSyncManager.updateAniListEntry(?:718)
     at com.kitsugi.animelist.data.auth.AniListSyncManager.updateAniListEntry$default(?:40)
     at c7.r1.invokeSuspend(?:26941)
     at kotlin.coroutines.jvm.internal.BaseContinuationImpl.resumeWith(?:11)
     at kotlinx.coroutines.DispatchedTask.run(?:128)
     at kotlinx.coroutines.internal.LimitedDispatcher$Worker.run(?:3)
   
   Kaynak platform kayıtları (5):
   Kayıt 1:
   Başlık: 300 Yen no Otsukiai
   Japonca başlık: 300円のおつきあい
   Tür/yıl: Anime / 2016
   Kaynak: anilist
   Harici kimlikler: Anime:mal:33993
   Ham kimlik alanları: MAL ID=33993 (MAL), AniList kayıt ID=495060808, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=7
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 2:
   Başlık: 300 En no Otsukiai Anime Edition
   Japonca başlık: 300円のおつきあい Anime Edition
   Tür/yıl: Anime / 2016
   Kaynak: mal
   Harici kimlikler: Anime:mal:33993
   Ham kimlik alanları: MAL ID=33993 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=7
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 3:
   Başlık: 300 En no Otsukiai Anime Edition
   Japonca başlık: 300円のおつきあい Anime Edition
   Tür/yıl: Anime / 2016
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:12588
   Ham kimlik alanları: MAL ID=300012588 (dahili Kitsu kimliği, MAL değil: Kitsu #12588), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=7
   Tarihler: başlangıç=2026-10-07, bitiş=2026-10-07; favori=false
   
   Kayıt 4:
   Başlık: 300 En no Otsukiai Anime Edition
   Tür/yıl: Anime / 2016
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:33993, Anime:shikimori:33993
   Ham kimlik alanları: MAL ID=33993 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=7
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 5:
   Başlık: 300円のおつきあい Anime Edition
   Japonca başlık: 300円のおつきあい Anime Edition
   Tür/yıl: Anime / 2016
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:192029
   Ham kimlik alanları: MAL ID=500192029 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=7
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Eşitleme için birleştirilen değerler:
   Başlık: 300円のおつきあい Anime Edition
   Japonca başlık: 300円のおつきあい
   Tür/yıl: Anime / 2016
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:33993
   Ham kimlik alanları: MAL ID=33993 (MAL), AniList kayıt ID=495060808, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=7
   Tarihler: başlangıç=2026-10-07, bitiş=2026-10-07; favori=false
   
   Kimlik güvencesi: Güvenilir (MAL/Shikimori kaydının kendi kimliği)
```

## Sorun 30 · HATA · AniList

- Rapor satırları: `2069–2159`
- Zaman: `2026-10-24 15:34:16.581 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `update_error` / `identity_unverified`
- Tüm olay no: `1782`

```text
30. [2026-10-24 15:34:16.581 GMT+03:00] [HATA] [AniList] [AniList] ! Güncellenemedi: はじめてのギャル
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Hata: java.lang.IllegalStateException: AniList liste kaydının bu medya ile eşleştiği doğrulanamadı: はじめてのギャル
     at com.kitsugi.animelist.data.auth.AniListSyncManager.updateAniListEntry(?:718)
     at com.kitsugi.animelist.data.auth.AniListSyncManager.updateAniListEntry$default(?:40)
     at c7.r1.invokeSuspend(?:26941)
     at kotlin.coroutines.jvm.internal.BaseContinuationImpl.resumeWith(?:11)
     at kotlinx.coroutines.DispatchedTask.run(?:128)
     at kotlinx.coroutines.internal.LimitedDispatcher$Worker.run(?:3)
   
   Kaynak platform kayıtları (6):
   Kayıt 1:
   Başlık: Hajimete no Gal
   İngilizce başlık: My First Girlfriend is a Gal
   Japonca başlık: はじめてのギャル
   Tür/yıl: Anime / 2017
   Kaynak: anilist
   Harici kimlikler: Anime:mal:34403
   Ham kimlik alanları: MAL ID=34403 (MAL), AniList kayıt ID=564462123, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=10/10, cilt=0, puan=6
   Tarihler: başlangıç=2026-05-24, bitiş=2026-05-24; favori=false
   
   Kayıt 2:
   Başlık: Hajimete no Gal
   İngilizce başlık: My First Girlfriend is a Gal
   Japonca başlık: はじめてのギャル
   Tür/yıl: Anime / 2017
   Kaynak: mal
   Harici kimlikler: Anime:mal:34403
   Ham kimlik alanları: MAL ID=34403 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=10/10, cilt=0, puan=6
   Tarihler: başlangıç=2026-05-24, bitiş=2026-05-24; favori=false
   
   Kayıt 3:
   Başlık: Hajimete no Gal
   Tür/yıl: Anime / 2017
   Kaynak: simkl
   Harici kimlikler: Anime:mal:34403, Anime:simkl:636943, Anime:tmdb:72296
   Ham kimlik alanları: MAL ID=34403 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=636943, TMDB ID=72296
   Durum/ilerleme: Tamamlandı, bölüm=10/10, cilt=0, puan=6
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 4:
   Başlık: Hajimete no Gal
   İngilizce başlık: My First Girlfriend is a Gal
   Japonca başlık: はじめてのギャル
   Tür/yıl: Anime / 2017
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:12761
   Ham kimlik alanları: MAL ID=300012761 (dahili Kitsu kimliği, MAL değil: Kitsu #12761), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=10/10, cilt=0, puan=6
   Tarihler: başlangıç=2026-10-04, bitiş=2026-10-04; favori=false
   
   Kayıt 5:
   Başlık: Hajimete no Gal
   Tür/yıl: Anime / 2017
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:34403, Anime:shikimori:34403
   Ham kimlik alanları: MAL ID=34403 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=10/10, cilt=0, puan=6
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 6:
   Başlık: はじめてのギャル
   Japonca başlık: はじめてのギャル
   Tür/yıl: Anime / 2017
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:198675
   Ham kimlik alanları: MAL ID=500198675 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=10/10, cilt=0, puan=3
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Eşitleme için birleştirilen değerler:
   Başlık: はじめてのギャル
   İngilizce başlık: My First Girlfriend is a Gal
   Japonca başlık: はじめてのギャル
   Tür/yıl: Anime / 2017
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:34403, Anime:simkl:636943, Anime:tmdb:72296
   Ham kimlik alanları: MAL ID=34403 (MAL), AniList kayıt ID=564462123, MAL liste ID=yok, Simkl ID=636943, TMDB ID=72296
   Durum/ilerleme: Tamamlandı, bölüm=10/10, cilt=0, puan=3
   Tarihler: başlangıç=2026-05-24, bitiş=2026-10-04; favori=false
   
   Kimlik güvencesi: Gerek yok (tüm hedef platformlarda kayıt zaten var)
```

## Sorun 31 · HATA · AniList

- Rapor satırları: `2161–2241`
- Zaman: `2026-10-24 15:34:35.328 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `update_error` / `identity_unverified`
- Tüm olay no: `1827`

```text
31. [2026-10-24 15:34:35.328 GMT+03:00] [HATA] [AniList] [AniList] ! Güncellenemedi: マヨヒガのお姉さん THE ANIMATION
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Hata: java.lang.IllegalStateException: AniList liste kaydının bu medya ile eşleştiği doğrulanamadı: マヨヒガのお姉さん THE ANIMATION
     at com.kitsugi.animelist.data.auth.AniListSyncManager.updateAniListEntry(?:718)
     at com.kitsugi.animelist.data.auth.AniListSyncManager.updateAniListEntry$default(?:40)
     at c7.r1.invokeSuspend(?:26941)
     at kotlin.coroutines.jvm.internal.BaseContinuationImpl.resumeWith(?:11)
     at kotlinx.coroutines.DispatchedTask.run(?:128)
     at kotlinx.coroutines.internal.LimitedDispatcher$Worker.run(?:3)
   
   Kaynak platform kayıtları (5):
   Kayıt 1:
   Başlık: Mayohiga no Onee-san THE ANIMATION
   İngilizce başlık: Lusty Ladies of Mayohiga
   Japonca başlık: マヨヒガのお姉さん THE ANIMATION
   Tür/yıl: Anime / 2017
   Kaynak: anilist
   Harici kimlikler: Anime:mal:35727
   Ham kimlik alanları: MAL ID=35727 (MAL), AniList kayıt ID=495061114, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=5
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 2:
   Başlık: Mayoiga no Oneesan The Animation
   İngilizce başlık: Lusty Ladies of Mayohiga
   Japonca başlık: マヨヒガのお姉さん THE ANIMATION
   Tür/yıl: Anime / 2017
   Kaynak: mal
   Harici kimlikler: Anime:mal:35727
   Ham kimlik alanları: MAL ID=35727 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=5
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 3:
   Başlık: Mayoiga no Oneesan The Animation
   Japonca başlık: マヨヒガのお姉さん THE ANIMATION
   Tür/yıl: Anime / 2017
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:13670
   Ham kimlik alanları: MAL ID=300013670 (dahili Kitsu kimliği, MAL değil: Kitsu #13670), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=5
   Tarihler: başlangıç=2026-10-08, bitiş=2026-10-08; favori=false
   
   Kayıt 4:
   Başlık: Mayoiga no Oneesan The Animation
   Tür/yıl: Anime / 2017
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:35727, Anime:shikimori:35727
   Ham kimlik alanları: MAL ID=35727 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=5
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 5:
   Başlık: マヨヒガのお姉さん THE ANIMATION
   Japonca başlık: マヨヒガのお姉さん THE ANIMATION
   Tür/yıl: Anime / 2017
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:219448
   Ham kimlik alanları: MAL ID=500219448 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=5
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Eşitleme için birleştirilen değerler:
   Başlık: マヨヒガのお姉さん THE ANIMATION
   İngilizce başlık: Lusty Ladies of Mayohiga
   Japonca başlık: マヨヒガのお姉さん THE ANIMATION
   Tür/yıl: Anime / 2017
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:35727
   Ham kimlik alanları: MAL ID=35727 (MAL), AniList kayıt ID=495061114, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=5
   Tarihler: başlangıç=2026-10-08, bitiş=2026-10-08; favori=false
   
   Kimlik güvencesi: Güvenilir (MAL/Shikimori kaydının kendi kimliği)
```

## Sorun 32 · HATA · AniList

- Rapor satırları: `2243–2333`
- Zaman: `2026-10-24 15:34:37.416 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `update_error` / `identity_unverified`
- Tüm olay no: `1842`

```text
32. [2026-10-24 15:34:37.416 GMT+03:00] [HATA] [AniList] [AniList] ! Güncellenemedi: 殺戮の天使
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Hata: java.lang.IllegalStateException: AniList liste kaydının bu medya ile eşleştiği doğrulanamadı: 殺戮の天使
     at com.kitsugi.animelist.data.auth.AniListSyncManager.updateAniListEntry(?:718)
     at com.kitsugi.animelist.data.auth.AniListSyncManager.updateAniListEntry$default(?:40)
     at c7.r1.invokeSuspend(?:26941)
     at kotlin.coroutines.jvm.internal.BaseContinuationImpl.resumeWith(?:11)
     at kotlinx.coroutines.DispatchedTask.run(?:128)
     at kotlinx.coroutines.internal.LimitedDispatcher$Worker.run(?:3)
   
   Kaynak platform kayıtları (6):
   Kayıt 1:
   Başlık: Satsuriku no Tenshi
   İngilizce başlık: Angels of Death
   Japonca başlık: 殺戮の天使
   Tür/yıl: Anime / 2018
   Kaynak: anilist
   Harici kimlikler: Anime:mal:35994
   Ham kimlik alanları: MAL ID=35994 (MAL), AniList kayıt ID=495061211, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=3
   Tarihler: başlangıç=2023-05-27, bitiş=2025-02-21; favori=false
   
   Kayıt 2:
   Başlık: Satsuriku no Tenshi
   İngilizce başlık: Angels of Death
   Japonca başlık: 殺戮の天使
   Tür/yıl: Anime / 2018
   Kaynak: mal
   Harici kimlikler: Anime:mal:35994
   Ham kimlik alanları: MAL ID=35994 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=16/16, cilt=0, puan=3
   Tarihler: başlangıç=2023-05-27, bitiş=2025-02-21; favori=false
   
   Kayıt 3:
   Başlık: Satsuriku no Tenshi
   Tür/yıl: Anime / 2018
   Kaynak: simkl
   Harici kimlikler: Anime:mal:35994, Anime:simkl:704661, Anime:tmdb:80477
   Ham kimlik alanları: MAL ID=35994 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=704661, TMDB ID=80477
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=3
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 4:
   Başlık: Satsuriku no Tenshi
   İngilizce başlık: Angels of Death
   Japonca başlık: 殺戮の天使
   Tür/yıl: Anime / 2018
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:13715
   Ham kimlik alanları: MAL ID=300013715 (dahili Kitsu kimliği, MAL değil: Kitsu #13715), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=3
   Tarihler: başlangıç=2023-05-27, bitiş=2025-02-21; favori=false
   
   Kayıt 5:
   Başlık: Satsuriku no Tenshi
   Tür/yıl: Anime / 2018
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:35994, Anime:shikimori:35994
   Ham kimlik alanları: MAL ID=35994 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=16/16, cilt=0, puan=3
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 6:
   Başlık: 殺戮の天使
   Japonca başlık: 殺戮の天使
   Tür/yıl: Anime / 2018
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:220566
   Ham kimlik alanları: MAL ID=500220566 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=16/16, cilt=0, puan=3
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Eşitleme için birleştirilen değerler:
   Başlık: 殺戮の天使
   İngilizce başlık: Angels of Death
   Japonca başlık: 殺戮の天使
   Tür/yıl: Anime / 2018
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:35994, Anime:simkl:704661, Anime:tmdb:80477
   Ham kimlik alanları: MAL ID=35994 (MAL), AniList kayıt ID=495061211, MAL liste ID=yok, Simkl ID=704661, TMDB ID=80477
   Durum/ilerleme: Tamamlandı, bölüm=16/16, cilt=0, puan=3
   Tarihler: başlangıç=2023-05-27, bitiş=2025-02-21; favori=false
   
   Kimlik güvencesi: Gerek yok (tüm hedef platformlarda kayıt zaten var)
```

## Sorun 33 · UYARI · Eşleştirme

- Rapor satırları: `2335–2375`
- Zaman: `2026-10-24 15:34:46.525 GMT+03:00`
- Kod: `—`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `1852`

```text
33. [2026-10-24 15:34:46.525 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Re:Zero kara Hajimeru Isekai Seikatsu OVAs
   Başlık: Re:Zero kara Hajimeru Isekai Seikatsu OVAs
   İngilizce başlık: Re:ZERO -Starting Life in Another World- OVAs
   Japonca başlık: Re:ゼロから始める異世界生活 OVAs
   Tür/yıl: Anime / 2018
   Kaynak: anilist
   Harici kimlikler: Anime:mal:36286
   Ham kimlik alanları: MAL ID=36286 (MAL), AniList kayıt ID=495061192, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/2, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Re:Zero kara Hajimeru Isekai Seikatsu - Memory Snow
   İngilizce başlık: Re:ZERO -Starting Life in Another World- Memory Snow
   Japonca başlık: Re:ゼロから始める異世界生活 Memory Snow
   Tür/yıl: Anime / 2018
   Kaynak: mal
   Harici kimlikler: Anime:mal:36286
   Ham kimlik alanları: MAL ID=36286 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Re:Zero kara Hajimeru Isekai Seikatsu: Memory Snow
   İngilizce başlık: Re:ZERO -Starting Life in Another World- Memory Snow
   Japonca başlık: Re：ゼロから始める異世界生活 OVA
   Tür/yıl: Anime / 2018
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:13882
   Ham kimlik alanları: MAL ID=300013882 (dahili Kitsu kimliği, MAL değil: Kitsu #13882), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Re:Zero kara Hajimeru Isekai Seikatsu - Memory Snow
   Tür/yıl: Anime / 2018
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:36286, Anime:shikimori:36286
   Ham kimlik alanları: MAL ID=36286 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 34 · UYARI · Eşleştirme

- Rapor satırları: `2377–2443`
- Zaman: `2026-10-24 15:34:46.527 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `1853`

```text
34. [2026-10-24 15:34:46.527 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: One Room: Second Season
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: One Room: Second Season
   İngilizce başlık: One Room SECOND SEASON
   Japonca başlık: One Room セカンドシーズン
   Tür/yıl: Anime / 2018
   Kaynak: anilist
   Harici kimlikler: Anime:mal:36431
   Ham kimlik alanları: MAL ID=36431 (MAL), AniList kayıt ID=495061157, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: One Room: Second Season
   Japonca başlık: One Room セカンドシーズン
   Tür/yıl: Anime / 2018
   Kaynak: mal
   Harici kimlikler: Anime:mal:36431
   Ham kimlik alanları: MAL ID=36431 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: One Room: Second Season
   Tür/yıl: Anime / 2018
   Kaynak: simkl
   Harici kimlikler: Anime:mal:36431, Anime:simkl:722069
   Ham kimlik alanları: MAL ID=36431 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=722069, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/13, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: One Room 2
   İngilizce başlık: One Room 2
   Japonca başlık: One Room 2
   Tür/yıl: Anime / 2018
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:13905
   Ham kimlik alanları: MAL ID=300013905 (dahili Kitsu kimliği, MAL değil: Kitsu #13905), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: One Room: Second Season
   Tür/yıl: Anime / 2018
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:36431, Anime:shikimori:36431
   Ham kimlik alanları: MAL ID=36431 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: One Room セカンドシーズン
   Japonca başlık: One Room セカンドシーズン
   Tür/yıl: Anime / 2018
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:226507
   Ham kimlik alanları: MAL ID=500226507 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/14, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 35 · UYARI · Eşleştirme

- Rapor satırları: `2445–2511`
- Zaman: `2026-10-24 15:34:52.147 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `1880`

```text
35. [2026-10-24 15:34:52.147 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Aishen Qiaokeli-ING... II
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: Aishen Qiaokeli-ING... II
   Japonca başlık: 爱神巧克力ING... II
   Tür/yıl: Anime / 2017
   Kaynak: anilist
   Harici kimlikler: Anime:mal:36848
   Ham kimlik alanları: MAL ID=36848 (MAL), AniList kayıt ID=495060823, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/15, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Aishen Qiaokeli-ing...II
   İngilizce başlık: Cupid’s Chocolates II
   Japonca başlık: 愛神巧克力 2期
   Tür/yıl: Anime / 2017
   Kaynak: mal
   Harici kimlikler: Anime:mal:36848
   Ham kimlik alanları: MAL ID=36848 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/15, cilt=0, puan=yok
   Tarihler: başlangıç=2025-07-06, bitiş=yok; favori=false
   
   
   Başlık: Aishen Qiaokeli-ing... II
   Tür/yıl: Anime / 2017
   Kaynak: simkl
   Harici kimlikler: Anime:mal:36848, Anime:simkl:744355
   Ham kimlik alanları: MAL ID=36848 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=744355, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/15, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Aishen Qiaokeli-ing... 2nd Season
   İngilizce başlık: Cupid's Chocolates 2nd Season
   Japonca başlık: 爱神巧克力ING... 2期
   Tür/yıl: Anime / 2017
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:14147
   Ham kimlik alanları: MAL ID=300014147 (dahili Kitsu kimliği, MAL değil: Kitsu #14147), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/15, cilt=0, puan=yok
   Tarihler: başlangıç=2025-07-06, bitiş=yok; favori=false
   
   
   Başlık: Aishen Qiaokeli-ing...II
   Tür/yıl: Anime / 2017
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:36848, Anime:shikimori:36848
   Ham kimlik alanları: MAL ID=36848 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/15, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: 爱神巧克力ing Ⅱ
   Japonca başlık: 爱神巧克力ing Ⅱ
   Tür/yıl: Anime / 2017
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:174222
   Ham kimlik alanları: MAL ID=500174222 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/15, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 36 · UYARI · Eşleştirme

- Rapor satırları: `2513–2568`
- Zaman: `2026-10-24 15:34:53.523 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `1886`

```text
36. [2026-10-24 15:34:53.523 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Muttsuri Dosukebe Russia Gibo Shimai no Honshitsu Minuite Sex Zanmai
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: Muttsuri Dosukebe Russia Gibo Shimai no Honshitsu Minuite Sex Zanmai
   Japonca başlık: むっつりドスケベロシア義母姉妹の本質見抜いてセックス三昧
   Tür/yıl: Anime / 2018
   Kaynak: anilist
   Harici kimlikler: Anime:mal:37233
   Ham kimlik alanları: MAL ID=37233 (MAL), AniList kayıt ID=495061133, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=2/2, cilt=0, puan=7
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Muttsuri Dosukebe Tsuyu Gibo Shimai no Honshitsu Minuite Sex Sanmai
   Japonca başlık: むっつりドスケベ露義母姉妹の本質見抜いてセックス三昧
   Tür/yıl: Anime / 2018
   Kaynak: mal
   Harici kimlikler: Anime:mal:37233
   Ham kimlik alanları: MAL ID=37233 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=2/2, cilt=0, puan=7
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Muttsuri Dosukebe Tsuyu Gibo Shimai no Honshitsu Minuite Sex Sanmai
   Japonca başlık: むっつりドスケベ露義母姉妹の本質見抜いてセックス三昧
   Tür/yıl: Anime / 2018
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:41453
   Ham kimlik alanları: MAL ID=300041453 (dahili Kitsu kimliği, MAL değil: Kitsu #41453), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=2/2, cilt=0, puan=7
   Tarihler: başlangıç=2026-10-07, bitiş=2026-10-07; favori=false
   
   
   Başlık: Muttsuri Dosukebe Tsuyu Gibo Shimai no Honshitsu Minuite Sex Sanmai
   Tür/yıl: Anime / 2018
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:37233, Anime:shikimori:37233
   Ham kimlik alanları: MAL ID=37233 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=2/2, cilt=0, puan=7
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: むっつりドスケベ露義母姉妹の本質見抜いてセックス三昧
   Japonca başlık: むっつりドスケベ露義母姉妹の本質見抜いてセックス三昧
   Tür/yıl: Anime / 2018
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:237107
   Ham kimlik alanları: MAL ID=500237107 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=2/2, cilt=0, puan=7
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 37 · UYARI · Eşleştirme

- Rapor satırları: `2570–2619`
- Zaman: `2026-10-24 15:34:53.527 GMT+03:00`
- Kod: `—`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `1887`

```text
37. [2026-10-24 15:34:53.527 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Dungeon ni Deai wo Motomeru no wa Machigatteiru Darou ka: Orion no Ya
   Başlık: Dungeon ni Deai wo Motomeru no wa Machigatteiru Darou ka: Orion no Ya
   İngilizce başlık: Is It Wrong to Try to Pick Up Girls in a Dungeon?: Arrow of the Orion
   Japonca başlık: ダンジョンに出会いを求めるのは間違っているだろうか ─ オリオンの矢 ─
   Tür/yıl: Anime / 2019
   Kaynak: anilist
   Harici kimlikler: Anime:mal:37348
   Ham kimlik alanları: MAL ID=37348 (MAL), AniList kayıt ID=513801997, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Dungeon ni Deai wo Motomeru no wa Machigatteiru Darou ka Movie: Orion no Ya
   İngilizce başlık: Is It Wrong to Try to Pick Up Girls in a Dungeon?: Arrow of the Orion
   Japonca başlık: 劇場版 ダンジョンに出会いを求めるのは間違っているだろうか -オリオンの矢-
   Tür/yıl: Anime / 2019
   Kaynak: mal
   Harici kimlikler: Anime:mal:37348
   Ham kimlik alanları: MAL ID=37348 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Gekijouban Dungeon ni Deai o Motomeru no wa Machigatte Iru Darouka: Orion no Ya
   Tür/yıl: Anime / 2019
   Kaynak: simkl
   Harici kimlikler: Anime:mal:37348, Anime:simkl:767899, Anime:tmdb:553835
   Ham kimlik alanları: MAL ID=37348 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=767899, TMDB ID=553835
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Dungeon ni Deai wo Motomeru no wa Machigatteiru Darou ka Movie: Orion no Ya
   İngilizce başlık: Is It Wrong to Try to Pick Up Girls in a Dungeon?: Arrow of the Orion
   Japonca başlık: 劇場版 ダンジョンに出会いを求めるのは間違っているだろうか -オリオンの矢-
   Tür/yıl: Anime / 2019
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:41778
   Ham kimlik alanları: MAL ID=300041778 (dahili Kitsu kimliği, MAL değil: Kitsu #41778), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Dungeon ni Deai wo Motomeru no wa Machigatteiru Darou ka Movie: Orion no Ya
   Tür/yıl: Anime / 2019
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:37348, Anime:shikimori:37348
   Ham kimlik alanları: MAL ID=37348 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 38 · UYARI · Eşleştirme

- Rapor satırları: `2621–2670`
- Zaman: `2026-10-24 15:34:53.529 GMT+03:00`
- Kod: `—`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `1888`

```text
38. [2026-10-24 15:34:53.529 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Dungeon ni Deai wo Motomeru no wa Machigatteiru Darou ka II
   Başlık: Dungeon ni Deai wo Motomeru no wa Machigatteiru Darou ka II
   İngilizce başlık: Is It Wrong to Try to Pick Up Girls in a Dungeon? II
   Japonca başlık: ダンジョンに出会いを求めるのは間違っているだろうかⅡ
   Tür/yıl: Anime / 2019
   Kaynak: anilist
   Harici kimlikler: Anime:mal:37347
   Ham kimlik alanları: MAL ID=37347 (MAL), AniList kayıt ID=495060900, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=8
   Tarihler: başlangıç=2026-10-04, bitiş=2026-10-04; favori=false
   
   
   Başlık: Dungeon ni Deai wo Motomeru no wa Machigatteiru Darou ka II
   İngilizce başlık: Is It Wrong to Try to Pick Up Girls in a Dungeon? II
   Japonca başlık: ダンジョンに出会いを求めるのは間違っているだろうかII
   Tür/yıl: Anime / 2019
   Kaynak: mal
   Harici kimlikler: Anime:mal:37347
   Ham kimlik alanları: MAL ID=37347 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=8
   Tarihler: başlangıç=2026-10-04, bitiş=2026-10-04; favori=false
   
   
   Başlık: Dungeon ni Deai o Motomeru no wa Machigatte Iru Darouka: Familia Myth II
   Tür/yıl: Anime / 2019
   Kaynak: simkl
   Harici kimlikler: Anime:mal:37347, Anime:simkl:767897
   Ham kimlik alanları: MAL ID=37347 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=767897, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=12/12, cilt=0, puan=8
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Dungeon ni Deai wo Motomeru no wa Machigatteiru Darou ka II
   İngilizce başlık: Is It Wrong to Try to Pick Up Girls in a Dungeon? II
   Japonca başlık: ダンジョンに出会いを求めるのは間違っているだろうかII
   Tür/yıl: Anime / 2019
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:40599
   Ham kimlik alanları: MAL ID=300040599 (dahili Kitsu kimliği, MAL değil: Kitsu #40599), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=8
   Tarihler: başlangıç=2025-10-21, bitiş=2025-10-21; favori=false
   
   
   Başlık: Dungeon ni Deai wo Motomeru no wa Machigatteiru Darou ka II
   Tür/yıl: Anime / 2019
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:37347, Anime:shikimori:37347
   Ham kimlik alanları: MAL ID=37347 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=8
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 39 · HATA · AniList

- Rapor satırları: `2672–2751`
- Zaman: `2026-10-24 15:34:54.670 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `update_error` / `identity_unverified`
- Tüm olay no: `1910`

```text
39. [2026-10-24 15:34:54.670 GMT+03:00] [HATA] [AniList] [AniList] ! Güncellenemedi: 大好きな母
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Hata: java.lang.IllegalStateException: AniList liste kaydının bu medya ile eşleştiği doğrulanamadı: 大好きな母
     at com.kitsugi.animelist.data.auth.AniListSyncManager.updateAniListEntry(?:718)
     at com.kitsugi.animelist.data.auth.AniListSyncManager.updateAniListEntry$default(?:40)
     at c7.r1.invokeSuspend(?:26941)
     at kotlin.coroutines.jvm.internal.BaseContinuationImpl.resumeWith(?:11)
     at kotlinx.coroutines.DispatchedTask.run(?:128)
     at kotlinx.coroutines.internal.LimitedDispatcher$Worker.run(?:3)
   
   Kaynak platform kayıtları (5):
   Kayıt 1:
   Başlık: Daisuki na Haha
   Japonca başlık: 大好きな母
   Tür/yıl: Anime / 2018
   Kaynak: anilist
   Harici kimlikler: Anime:mal:37699
   Ham kimlik alanları: MAL ID=37699 (MAL), AniList kayıt ID=495060880, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=2/2, cilt=0, puan=7
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 2:
   Başlık: Daisuki na Mama
   İngilizce başlık: Beloved Mother
   Japonca başlık: 大好きな母
   Tür/yıl: Anime / 2018
   Kaynak: mal
   Harici kimlikler: Anime:mal:37699
   Ham kimlik alanları: MAL ID=37699 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=2/2, cilt=0, puan=7
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 3:
   Başlık: Daisuki na Haha
   Japonca başlık: 大好きな母
   Tür/yıl: Anime / 2018
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:41427
   Ham kimlik alanları: MAL ID=300041427 (dahili Kitsu kimliği, MAL değil: Kitsu #41427), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=2/2, cilt=0, puan=7
   Tarihler: başlangıç=2026-10-07, bitiş=2026-10-07; favori=false
   
   Kayıt 4:
   Başlık: Daisuki na Mama
   Tür/yıl: Anime / 2018
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:37699, Anime:shikimori:37699
   Ham kimlik alanları: MAL ID=37699 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=2/2, cilt=0, puan=7
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 5:
   Başlık: 大好きな母
   Japonca başlık: 大好きな母
   Tür/yıl: Anime / 2018
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:256233
   Ham kimlik alanları: MAL ID=500256233 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=2/2, cilt=0, puan=7
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Eşitleme için birleştirilen değerler:
   Başlık: 大好きな母
   İngilizce başlık: Beloved Mother
   Japonca başlık: 大好きな母
   Tür/yıl: Anime / 2018
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:37699
   Ham kimlik alanları: MAL ID=37699 (MAL), AniList kayıt ID=495060880, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=2/2, cilt=0, puan=7
   Tarihler: başlangıç=2026-10-07, bitiş=2026-10-07; favori=false
   
   Kimlik güvencesi: Güvenilir (MAL/Shikimori kaydının kendi kimliği)
```

## Sorun 40 · UYARI · Eşleştirme

- Rapor satırları: `2753–2802`
- Zaman: `2026-10-24 15:34:55.306 GMT+03:00`
- Kod: `—`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `1918`

```text
40. [2026-10-24 15:34:55.306 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Tokyo Ghoul:re 2
   Başlık: Tokyo Ghoul:re 2
   İngilizce başlık: Tokyo Ghoul:re 2
   Japonca başlık: 東京喰種-トーキョーグール-:re 2
   Tür/yıl: Anime / 2018
   Kaynak: anilist
   Harici kimlikler: Anime:mal:37799
   Ham kimlik alanları: MAL ID=37799 (MAL), AniList kayıt ID=495061302, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Tokyo Ghoul:re 2nd Season
   İngilizce başlık: Tokyo Ghoul:re 2nd Season
   Japonca başlık: 東京喰種トーキョーグール：re 第2期
   Tür/yıl: Anime / 2018
   Kaynak: mal
   Harici kimlikler: Anime:mal:37799
   Ham kimlik alanları: MAL ID=37799 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Tokyo Ghoul:Re
   Tür/yıl: Anime / 2018
   Kaynak: simkl
   Harici kimlikler: Anime:mal:37799, Anime:simkl:812189
   Ham kimlik alanları: MAL ID=37799 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=812189, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Tokyo Ghoul:re 2
   İngilizce başlık: Tokyo Ghoul:re 2
   Japonca başlık: 京喰種：re 第2期
   Tür/yıl: Anime / 2018
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:41359
   Ham kimlik alanları: MAL ID=300041359 (dahili Kitsu kimliği, MAL değil: Kitsu #41359), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Tokyo Ghoul:re 2nd Season
   Tür/yıl: Anime / 2018
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:37799, Anime:shikimori:37799
   Ham kimlik alanları: MAL ID=37799 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 41 · UYARI · Eşleştirme

- Rapor satırları: `2804–2852`
- Zaman: `2026-10-24 15:35:04.400 GMT+03:00`
- Kod: `—`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `1941`

```text
41. [2026-10-24 15:35:04.400 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Fate/Grand Order: Shinsei Entaku Ryouiki Camelot - Paladin; Agateram
   Başlık: Fate/Grand Order: Shinsei Entaku Ryouiki Camelot - Paladin; Agateram
   İngilizce başlık: Fate/Grand Order Divine Realm of the Round Table: Camelot - Paladin; Agateram
   Japonca başlık: 劇場版Fate/Grand Order -神聖円卓領域キャメロット- 後編Paladin; Agateram
   Tür/yıl: Anime / 2021
   Kaynak: anilist
   Harici kimlikler: Anime:mal:38086
   Ham kimlik alanları: MAL ID=38086 (MAL), AniList kayıt ID=495060917, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Fate/Grand Order: Shinsei Entaku Ryouiki Camelot 2 - Paladin; Agateram
   İngilizce başlık: Fate/Grand Order: Divine Realm of the Round Table - Camelot Paladin; Agateram
   Japonca başlık: 劇場版Fate/Grand Order -神聖円卓領域キャメロット- Paladin; Agateram
   Tür/yıl: Anime / 2021
   Kaynak: mal
   Harici kimlikler: Anime:mal:38086
   Ham kimlik alanları: MAL ID=38086 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Gekijouban Fate/Grand Order: Shinsei Entaku Ryouiki Camelot
   Tür/yıl: Anime / 2020
   Kaynak: simkl
   Harici kimlikler: Anime:mal:38086, Anime:simkl:868795, Anime:tmdb:637202
   Ham kimlik alanları: MAL ID=38086 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=868795, TMDB ID=637202
   Durum/ilerleme: Planlandı, bölüm=0/2, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Fate/Grand Order: Shinsei Entaku Ryouiki Camelot - Paladin; Agateram
   Japonca başlık: 劇場版Fate/Grand Order -神聖円卓領域キャメロット- Paladin; Agateram
   Tür/yıl: Anime / 2021
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:42271
   Ham kimlik alanları: MAL ID=300042271 (dahili Kitsu kimliği, MAL değil: Kitsu #42271), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Fate/Grand Order: Shinsei Entaku Ryouiki Camelot 2 - Paladin; Agateram
   Tür/yıl: Anime / 2021
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:38086, Anime:shikimori:38086
   Ham kimlik alanları: MAL ID=38086 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 42 · HATA · AniList

- Rapor satırları: `2854–2944`
- Zaman: `2026-10-24 15:35:04.725 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `update_error` / `identity_unverified`
- Tüm olay no: `1943`

```text
42. [2026-10-24 15:35:04.725 GMT+03:00] [HATA] [AniList] [AniList] ! Güncellenemedi: 五等分の花嫁
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Hata: java.lang.IllegalStateException: AniList liste kaydının bu medya ile eşleştiği doğrulanamadı: 五等分の花嫁
     at com.kitsugi.animelist.data.auth.AniListSyncManager.updateAniListEntry(?:718)
     at com.kitsugi.animelist.data.auth.AniListSyncManager.updateAniListEntry$default(?:40)
     at c7.r1.invokeSuspend(?:26941)
     at kotlin.coroutines.jvm.internal.BaseContinuationImpl.resumeWith(?:11)
     at kotlinx.coroutines.DispatchedTask.run(?:128)
     at kotlinx.coroutines.internal.LimitedDispatcher$Worker.run(?:3)
   
   Kaynak platform kayıtları (6):
   Kayıt 1:
   Başlık: Go-toubun no Hanayome
   İngilizce başlık: The Quintessential Quintuplets
   Japonca başlık: 五等分の花嫁
   Tür/yıl: Anime / 2019
   Kaynak: anilist
   Harici kimlikler: Anime:mal:38101
   Ham kimlik alanları: MAL ID=38101 (MAL), AniList kayıt ID=495060809, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=7
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 2:
   Başlık: 5-toubun no Hanayome
   İngilizce başlık: The Quintessential Quintuplets
   Japonca başlık: 五等分の花嫁
   Tür/yıl: Anime / 2019
   Kaynak: mal
   Harici kimlikler: Anime:mal:38101
   Ham kimlik alanları: MAL ID=38101 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=7
   Tarihler: başlangıç=2023-06-03, bitiş=yok; favori=false
   
   Kayıt 3:
   Başlık: Go-Toubun no Hanayome
   Tür/yıl: Anime / 2019
   Kaynak: simkl
   Harici kimlikler: Anime:mal:38101, Anime:simkl:872381, Anime:tmdb:84669
   Ham kimlik alanları: MAL ID=38101 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=872381, TMDB ID=84669
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=7
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 4:
   Başlık: 5-toubun no Hanayome
   İngilizce başlık: The Quintessential Quintuplets
   Japonca başlık: 五等分の花嫁
   Tür/yıl: Anime / 2019
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:41966
   Ham kimlik alanları: MAL ID=300041966 (dahili Kitsu kimliği, MAL değil: Kitsu #41966), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=7
   Tarihler: başlangıç=2023-06-03, bitiş=yok; favori=false
   
   Kayıt 5:
   Başlık: 5-toubun no Hanayome
   Tür/yıl: Anime / 2019
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:38101, Anime:shikimori:38101
   Ham kimlik alanları: MAL ID=38101 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=7
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 6:
   Başlık: 五等分の花嫁
   Japonca başlık: 五等分の花嫁
   Tür/yıl: Anime / 2019
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:256114
   Ham kimlik alanları: MAL ID=500256114 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=7
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Eşitleme için birleştirilen değerler:
   Başlık: 五等分の花嫁
   İngilizce başlık: The Quintessential Quintuplets
   Japonca başlık: 五等分の花嫁
   Tür/yıl: Anime / 2019
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:38101, Anime:simkl:872381, Anime:tmdb:84669
   Ham kimlik alanları: MAL ID=38101 (MAL), AniList kayıt ID=495060809, MAL liste ID=yok, Simkl ID=872381, TMDB ID=84669
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=7
   Tarihler: başlangıç=2023-06-03, bitiş=yok; favori=false
   
   Kimlik güvencesi: Gerek yok (tüm hedef platformlarda kayıt zaten var)
```

## Sorun 43 · UYARI · Eşleştirme

- Rapor satırları: `2946–3013`
- Zaman: `2026-10-24 15:35:07.382 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `1966`

```text
43. [2026-10-24 15:35:07.382 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Ore wo Suki nano wa Omae dake ka yo
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: Ore wo Suki nano wa Omae dake ka yo
   İngilizce başlık: ORESUKI: Are you the only one who loves me?
   Japonca başlık: 俺を好きなのはお前だけかよ
   Tür/yıl: Anime / 2019
   Kaynak: anilist
   Harici kimlikler: Anime:mal:38483
   Ham kimlik alanları: MAL ID=38483 (MAL), AniList kayıt ID=495061168, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=7
   Tarihler: başlangıç=2025-05-07, bitiş=2025-05-07; favori=false
   
   
   Başlık: Ore wo Suki nano wa Omae dake ka yo
   İngilizce başlık: Oresuki: Are You the Only One Who Loves Me?
   Japonca başlık: 俺を好きなのはお前だけかよ
   Tür/yıl: Anime / 2019
   Kaynak: mal
   Harici kimlikler: Anime:mal:38483
   Ham kimlik alanları: MAL ID=38483 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=7
   Tarihler: başlangıç=2025-05-07, bitiş=2025-05-07; favori=false
   
   
   Başlık: Ore o Suki na no wa Omae dake ka yo
   Tür/yıl: Anime / 2019
   Kaynak: simkl
   Harici kimlikler: Anime:mal:38483, Anime:simkl:926577, Anime:tmdb:93019
   Ham kimlik alanları: MAL ID=38483 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=926577, TMDB ID=93019
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=7
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Ore wo Suki na no wa Omae dake ka yo
   İngilizce başlık: ORESUKI: Are you the only one who loves me?
   Japonca başlık: 俺を好きなのはお前だけかよ
   Tür/yıl: Anime / 2019
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:42047
   Ham kimlik alanları: MAL ID=300042047 (dahili Kitsu kimliği, MAL değil: Kitsu #42047), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=7
   Tarihler: başlangıç=2025-07-10, bitiş=2025-07-10; favori=false
   
   
   Başlık: Ore wo Suki nano wa Omae dake ka yo
   Tür/yıl: Anime / 2019
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:38483, Anime:shikimori:38483
   Ham kimlik alanları: MAL ID=38483 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=7
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: 俺を好きなのはお前だけかよ
   Japonca başlık: 俺を好きなのはお前だけかよ
   Tür/yıl: Anime / 2019
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:262943
   Ham kimlik alanları: MAL ID=500262943 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=7
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 44 · UYARI · Eşleştirme

- Rapor satırları: `3015–3073`
- Zaman: `2026-10-24 15:35:12.516 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `2003`

```text
44. [2026-10-24 15:35:12.516 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Koe no Katachi Specials
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: Koe no Katachi Specials
   İngilizce başlık: A Silent Voice Specials
   Japonca başlık: 聲の形スペシャル
   Tür/yıl: Anime / 2017
   Kaynak: anilist
   Harici kimlikler: Anime:mal:35566
   Ham kimlik alanları: MAL ID=35566 (MAL), AniList kayıt ID=495061052, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/2, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Koe no Katachi Specials
   İngilizce başlık: A Silent Voice Specials
   Japonca başlık: 聲の形
   Tür/yıl: Anime / 2017
   Kaynak: mal
   Harici kimlikler: Anime:mal:35566
   Ham kimlik alanları: MAL ID=35566 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/2, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Koi wo Shita no wa
   İngilizce başlık: Speed of Youth
   Japonca başlık: 恋をしたのは
   Tür/yıl: Anime / 2017
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:41567
   Ham kimlik alanları: MAL ID=300041567 (dahili Kitsu kimliği, MAL değil: Kitsu #41567), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Koe no Katachi Specials
   Tür/yıl: Anime / 2017
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:35566, Anime:shikimori:35566
   Ham kimlik alanları: MAL ID=35566 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/2, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: きみの声をとどけたい
   Japonca başlık: きみの声をとどけたい
   Tür/yıl: Anime / 2017
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:189546
   Ham kimlik alanları: MAL ID=500189546 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 45 · UYARI · Eşleştirme

- Rapor satırları: `3075–3142`
- Zaman: `2026-10-24 15:35:12.525 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `2020`

```text
45. [2026-10-24 15:35:12.525 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Tensei Shitara Slime Datta Ken 2nd Season
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: Tensei Shitara Slime Datta Ken 2nd Season
   İngilizce başlık: That Time I Got Reincarnated as a Slime Season 2
   Japonca başlık: 転生したらスライムだった件 第2期
   Tür/yıl: Anime / 2021
   Kaynak: anilist
   Harici kimlikler: Anime:mal:39551
   Ham kimlik alanları: MAL ID=39551 (MAL), AniList kayıt ID=495061283, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Tensei shitara Slime Datta Ken 2nd Season
   İngilizce başlık: That Time I Got Reincarnated as a Slime Season 2
   Japonca başlık: 転生したらスライムだった件
   Tür/yıl: Anime / 2021
   Kaynak: mal
   Harici kimlikler: Anime:mal:39551
   Ham kimlik alanları: MAL ID=39551 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Tensei Shitara Slime Datta Ken
   Tür/yıl: Anime / 2021
   Kaynak: simkl
   Harici kimlikler: Anime:mal:39551, Anime:simkl:1060335
   Ham kimlik alanları: MAL ID=39551 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=1060335, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Tensei shitara Slime Datta Ken 2
   İngilizce başlık: That Time I Got Reincarnated as a Slime 2
   Japonca başlık: 転生したらスライムだった件2
   Tür/yıl: Anime / 2021
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:42196
   Ham kimlik alanları: MAL ID=300042196 (dahili Kitsu kimliği, MAL değil: Kitsu #42196), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Tensei shitara Slime Datta Ken 2nd Season
   Tür/yıl: Anime / 2021
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:39551, Anime:shikimori:39551
   Ham kimlik alanları: MAL ID=39551 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: 転生したらスライムだった件 第2期
   Japonca başlık: 転生したらスライムだった件 第2期
   Tür/yıl: Anime / 2021
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:278031
   Ham kimlik alanları: MAL ID=500278031 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 46 · UYARI · Eşleştirme

- Rapor satırları: `3144–3211`
- Zaman: `2026-10-24 15:35:12.526 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `2021`

```text
46. [2026-10-24 15:35:12.526 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Re:Zero kara Hajimeru Isekai Seikatsu 2nd Season
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: Re:Zero kara Hajimeru Isekai Seikatsu 2nd Season
   İngilizce başlık: Re:ZERO -Starting Life in Another World- Season 2
   Japonca başlık: Re:ゼロから始める異世界生活 2nd Season
   Tür/yıl: Anime / 2020
   Kaynak: anilist
   Harici kimlikler: Anime:mal:39587
   Ham kimlik alanları: MAL ID=39587 (MAL), AniList kayıt ID=495061193, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=13/13, cilt=0, puan=8
   Tarihler: başlangıç=2025-02-21, bitiş=2025-02-21; favori=false
   
   
   Başlık: Re:Zero kara Hajimeru Isekai Seikatsu 2nd Season
   İngilizce başlık: Re:ZERO -Starting Life in Another World- Season 2
   Japonca başlık: Re：ゼロから始める異世界生活 2
   Tür/yıl: Anime / 2020
   Kaynak: mal
   Harici kimlikler: Anime:mal:39587
   Ham kimlik alanları: MAL ID=39587 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=13/13, cilt=0, puan=8
   Tarihler: başlangıç=2025-02-21, bitiş=2025-02-21; favori=false
   
   
   Başlık: Re:Zero kara Hajimeru Isekai Seikatsu
   Tür/yıl: Anime / 2020
   Kaynak: simkl
   Harici kimlikler: Anime:mal:39587, Anime:simkl:1063491
   Ham kimlik alanları: MAL ID=39587 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=1063491, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=13/13, cilt=0, puan=8
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Re:Zero kara Hajimeru Isekai Seikatsu 2
   İngilizce başlık: Re:ZERO -Starting Life in Another World- Season 2
   Japonca başlık: Re:ゼロから始める異世界生活２
   Tür/yıl: Anime / 2020
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:42198
   Ham kimlik alanları: MAL ID=300042198 (dahili Kitsu kimliği, MAL değil: Kitsu #42198), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=13/13, cilt=0, puan=8
   Tarihler: başlangıç=2023-01-24, bitiş=2025-02-21; favori=false
   
   
   Başlık: Re:Zero kara Hajimeru Isekai Seikatsu 2nd Season
   Tür/yıl: Anime / 2020
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:39587, Anime:shikimori:39587
   Ham kimlik alanları: MAL ID=39587 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=13/13, cilt=0, puan=8
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Re:ゼロから始める異世界生活 2nd season
   Japonca başlık: Re:ゼロから始める異世界生活 2nd season
   Tür/yıl: Anime / 2020
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:278826
   Ham kimlik alanları: MAL ID=500278826 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=13/13, cilt=0, puan=8
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 47 · UYARI · Eşleştirme

- Rapor satırları: `3213–3280`
- Zaman: `2026-10-24 15:35:16.242 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `2034`

```text
47. [2026-10-24 15:35:16.242 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Bokutachi wa Benkyou ga Dekinai OVAs
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: Bokutachi wa Benkyou ga Dekinai OVAs
   İngilizce başlık: We Never Learn OVAs
   Japonca başlık: ぼくたちは勉強ができない OVAs
   Tür/yıl: Anime / 2019
   Kaynak: anilist
   Harici kimlikler: Anime:mal:39819
   Ham kimlik alanları: MAL ID=39819 (MAL), AniList kayıt ID=495060862, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/2, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Bokutachi wa Benkyou ga Dekinai: Nagisa ni Usemono Arite Senjin wa Enzen to [X] Suru
   İngilizce başlık: We Never Learn: BOKUBEN - The Predecessor [X] with Elegance with the Missing Item on the Beach
   Japonca başlık: ぼくたちは勉強ができない「渚に失せものありて先人は艶然と[X]する」
   Tür/yıl: Anime / 2019
   Kaynak: mal
   Harici kimlikler: Anime:mal:39819
   Ham kimlik alanları: MAL ID=39819 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Bokutachi wa Benkyou ga Dekinai: Nagisa ni Usemono Arite Senjin wa Enzen to [X] Suru
   Tür/yıl: Anime / 2019
   Kaynak: simkl
   Harici kimlikler: Anime:mal:39819, Anime:simkl:1093409
   Ham kimlik alanları: MAL ID=39819 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=1093409, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Bokutachi wa Benkyou ga Dekinai: Nagisa ni Usemono Arite Senjin wa Enzen to [X] Suru
   İngilizce başlık: We Never Learn OVA
   Japonca başlık: ぼくたちは勉強ができない OVA
   Tür/yıl: Anime / 2019
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:42356
   Ham kimlik alanları: MAL ID=300042356 (dahili Kitsu kimliği, MAL değil: Kitsu #42356), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Bokutachi wa Benkyou ga Dekinai: Nagisa ni Usemono Arite Senjin wa Enzen to [X] Suru
   Tür/yıl: Anime / 2019
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:39819, Anime:shikimori:39819
   Ham kimlik alanları: MAL ID=39819 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: ぼくたちは勉強ができない OVA
   Japonca başlık: ぼくたちは勉強ができない OVA
   Tür/yıl: Anime / 2019
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:294059
   Ham kimlik alanları: MAL ID=500294059 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/2, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 48 · HATA · AniList

- Rapor satırları: `3282–3361`
- Zaman: `2026-10-24 15:35:17.005 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `update_error` / `identity_unverified`
- Tüm olay no: `2043`

```text
48. [2026-10-24 15:35:17.005 GMT+03:00] [HATA] [AniList] [AniList] ! Güncellenemedi: らぶりー♡
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Hata: java.lang.IllegalStateException: AniList liste kaydının bu medya ile eşleştiği doğrulanamadı: らぶりー♡
     at com.kitsugi.animelist.data.auth.AniListSyncManager.updateAniListEntry(?:718)
     at com.kitsugi.animelist.data.auth.AniListSyncManager.updateAniListEntry$default(?:40)
     at c7.r1.invokeSuspend(?:26941)
     at kotlin.coroutines.jvm.internal.BaseContinuationImpl.resumeWith(?:11)
     at kotlinx.coroutines.DispatchedTask.run(?:128)
     at kotlinx.coroutines.internal.LimitedDispatcher$Worker.run(?:3)
   
   Kaynak platform kayıtları (5):
   Kayıt 1:
   Başlık: Lovely ♡
   Japonca başlık: らぶりー♡
   Tür/yıl: Anime / 2019
   Kaynak: anilist
   Harici kimlikler: Anime:mal:40023
   Ham kimlik alanları: MAL ID=40023 (MAL), AniList kayıt ID=495061084, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=2/2, cilt=0, puan=9
   Tarihler: başlangıç=yok, bitiş=yok; favori=true
   
   Kayıt 2:
   Başlık: Lovely ♡
   İngilizce başlık: Lovely Aina-chan
   Japonca başlık: らぶりー♡
   Tür/yıl: Anime / 2019
   Kaynak: mal
   Harici kimlikler: Anime:mal:40023
   Ham kimlik alanları: MAL ID=40023 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=2/2, cilt=0, puan=9
   Tarihler: başlangıç=2026-10-07, bitiş=2026-10-07; favori=false
   
   Kayıt 3:
   Başlık: Lovely Heart
   Japonca başlık: らぶりー♡
   Tür/yıl: Anime / 2019
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:42783
   Ham kimlik alanları: MAL ID=300042783 (dahili Kitsu kimliği, MAL değil: Kitsu #42783), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=2/2, cilt=0, puan=9
   Tarihler: başlangıç=2026-10-07, bitiş=2026-10-07; favori=false
   
   Kayıt 4:
   Başlık: Lovely ♡
   Tür/yıl: Anime / 2019
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:40023, Anime:shikimori:40023
   Ham kimlik alanları: MAL ID=40023 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=2/2, cilt=0, puan=9
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 5:
   Başlık: らぶりー♡
   Japonca başlık: らぶりー♡
   Tür/yıl: Anime / 2019
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:288025
   Ham kimlik alanları: MAL ID=500288025 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=2/2, cilt=0, puan=9
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Eşitleme için birleştirilen değerler:
   Başlık: らぶりー♡
   İngilizce başlık: Lovely Aina-chan
   Japonca başlık: らぶりー♡
   Tür/yıl: Anime / 2019
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:40023
   Ham kimlik alanları: MAL ID=40023 (MAL), AniList kayıt ID=495061084, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=2/2, cilt=0, puan=9
   Tarihler: başlangıç=2026-10-07, bitiş=2026-10-07; favori=true
   
   Kimlik güvencesi: Güvenilir (MAL/Shikimori kaydının kendi kimliği)
```

## Sorun 49 · UYARI · Eşleştirme

- Rapor satırları: `3363–3412`
- Zaman: `2026-10-24 15:35:18.109 GMT+03:00`
- Kod: `—`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `2061`

```text
49. [2026-10-24 15:35:18.109 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Dungeon ni Deai wo Motomeru no wa Machigatteiru Darou ka III
   Başlık: Dungeon ni Deai wo Motomeru no wa Machigatteiru Darou ka III
   İngilizce başlık: Is It Wrong to Try to Pick Up Girls in a Dungeon? III
   Japonca başlık: ダンジョンに出会いを求めるのは間違っているだろうかⅢ
   Tür/yıl: Anime / 2020
   Kaynak: anilist
   Harici kimlikler: Anime:mal:40454
   Ham kimlik alanları: MAL ID=40454 (MAL), AniList kayıt ID=495060901, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=9
   Tarihler: başlangıç=2026-10-04, bitiş=2026-10-04; favori=false
   
   
   Başlık: Dungeon ni Deai wo Motomeru no wa Machigatteiru Darou ka III
   İngilizce başlık: Is It Wrong to Try to Pick Up Girls in a Dungeon? III
   Japonca başlık: ダンジョンに出会いを求めるのは間違っているだろうかIII
   Tür/yıl: Anime / 2020
   Kaynak: mal
   Harici kimlikler: Anime:mal:40454
   Ham kimlik alanları: MAL ID=40454 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=9
   Tarihler: başlangıç=2026-10-04, bitiş=2026-10-04; favori=false
   
   
   Başlık: Dungeon ni Deai o Motomeru no wa Machigatte Iru Darouka: Familia Myth III
   Tür/yıl: Anime / 2020
   Kaynak: simkl
   Harici kimlikler: Anime:mal:40454, Anime:simkl:1175973
   Ham kimlik alanları: MAL ID=40454 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=1175973, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=9
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Dungeon ni Deai wo Motomeru no wa Machigatteiru Darou ka III
   İngilizce başlık: Is It Wrong to Try to Pick Up Girls in a Dungeon? III
   Japonca başlık: ダンジョンに出会いを求めるのは間違っているだろうかIII
   Tür/yıl: Anime / 2020
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:42583
   Ham kimlik alanları: MAL ID=300042583 (dahili Kitsu kimliği, MAL değil: Kitsu #42583), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=9
   Tarihler: başlangıç=2025-10-21, bitiş=2025-10-22; favori=false
   
   
   Başlık: Dungeon ni Deai wo Motomeru no wa Machigatteiru Darou ka III
   Tür/yıl: Anime / 2020
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:40454, Anime:shikimori:40454
   Ham kimlik alanları: MAL ID=40454 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=9
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 50 · HATA · Kitsu

- Rapor satırları: `3414–3477`
- Zaman: `2026-10-24 15:35:29.086 GMT+03:00`
- Kod: `KTS-KIT-4002`
- İşlem / neden: `add_error` / `progress_above_media_length`
- Tüm olay no: `2085`

```text
50. [2026-10-24 15:35:29.086 GMT+03:00] [HATA] [Kitsu] [Kitsu] ! Hata: ○○ Kouhai (Kitsu kütüphanesine eklenemedi (○○ Kouhai): HTTP 422: cannot exceed length of media: progress - cannot exceed length of media [kitsu=42919, önbellek (MAL→Kitsu)])
   Kod: KTS-KIT-4002
   | KTS-KIT-4002 · WARNING · KIT
   | TR — Kitsu hız sınırı
   | Neden: Kitsu dakikada 60 istek ve kısa aralıklı patlamalara karşı ek sınır uyguluyor; limit aşıldığında 429 döner.
   | Çözüm: Bekleyin; istekler otomatik yeniden denenir.
   | EN — Kitsu rate limit
   | Why: Kitsu allows 60 requests/minute and an additional burst limit for short spikes; exceeding it returns 429.
   | Fix: Wait; requests are retried automatically.
   Kaynak platform kayıtları (4):
   Kayıt 1:
   Başlık: ○○ Kouhai
   Japonca başlık: ○○交配
   Tür/yıl: Anime / 2020
   Kaynak: anilist
   Harici kimlikler: Anime:mal:40658
   Ham kimlik alanları: MAL ID=40658 (MAL), AniList kayıt ID=495060804, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: İzleniyor, bölüm=10/?, cilt=0, puan=9
   Tarihler: başlangıç=yok, bitiş=yok; favori=true
   
   Kayıt 2:
   Başlık: ** Kouhai
   İngilizce başlık: Assisted Mating
   Japonca başlık: ○○交配
   Tür/yıl: Anime / 2020
   Kaynak: mal
   Harici kimlikler: Anime:mal:40658
   Ham kimlik alanları: MAL ID=40658 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: İzleniyor, bölüm=10/12, cilt=0, puan=9
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 3:
   Başlık: ** Kouhai
   Tür/yıl: Anime / 2020
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:40658, Anime:shikimori:40658
   Ham kimlik alanları: MAL ID=40658 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: İzleniyor, bölüm=10/12, cilt=0, puan=9
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 4:
   Başlık: ○○ Kouhai
   Japonca başlık: ○○交配
   Tür/yıl: Anime / 2020
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:294669
   Ham kimlik alanları: MAL ID=500294669 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: İzleniyor, bölüm=10/12, cilt=0, puan=9
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Eşitleme için birleştirilen değerler:
   Başlık: ○○ Kouhai
   İngilizce başlık: Assisted Mating
   Japonca başlık: ○○交配
   Tür/yıl: Anime / 2020
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:40658
   Ham kimlik alanları: MAL ID=40658 (MAL), AniList kayıt ID=495060804, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: İzleniyor, bölüm=10/12, cilt=0, puan=9
   Tarihler: başlangıç=yok, bitiş=yok; favori=true
   
   Kimlik güvencesi: Güvenilir (MAL/Shikimori kaydının kendi kimliği)
   
   Kitsu kütüphanesine eklenemedi (○○ Kouhai): HTTP 422: cannot exceed length of media: progress - cannot exceed length of media [kitsu=42919, önbellek (MAL→Kitsu)]
```

## Sorun 51 · UYARI · Eşleştirme

- Rapor satırları: `3478–3545`
- Zaman: `2026-10-24 15:35:30.624 GMT+03:00`
- Kod: `KTS-ANL-2002`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `2106`

```text
51. [2026-10-24 15:35:30.624 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Sword Art Online: Alicization - War of Underworld Part 2
   Kod: KTS-ANL-2002
   | KTS-ANL-2002 · WARNING · ANL
   | TR — AniList çok fazla istek (GraphQL 429)
   | Neden: GraphQL yanıtı "Too Many Requests" döndü. AniList'in dakikalık limitinin yanında kısa aralıklı patlamaları engelleyen ayrı bir burst limiter'ı da var.
   | Çözüm: Bir dakika bekleyin; Retry-After başlığı kadar bekleme otomatik uygulanır.
   | EN — AniList rate limited (GraphQL 429)
   | Why: The GraphQL response returned "Too Many Requests". Besides the per-minute limit, AniList runs a separate burst limiter against short request spikes.
   | Fix: Wait a minute; the Retry-After delay is applied automatically.
   Başlık: Sword Art Online: Alicization - War of Underworld Part 2
   İngilizce başlık: Sword Art Online: Alicization - War of Underworld Part 2
   Japonca başlık: ソードアート・オンライン アリシゼーション War of Underworld 最終章 (2nd Season)
   Tür/yıl: Anime / 2020
   Kaynak: anilist
   Harici kimlikler: Anime:mal:40540
   Ham kimlik alanları: MAL ID=40540 (MAL), AniList kayıt ID=495061266, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/11, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Sword Art Online: Alicization - War of Underworld 2nd Season
   İngilizce başlık: Sword Art Online: Alicization - War of Underworld Part 2
   Japonca başlık: ソードアート・オンライン アリシゼーション War of Underworld
   Tür/yıl: Anime / 2020
   Kaynak: mal
   Harici kimlikler: Anime:mal:40540
   Ham kimlik alanları: MAL ID=40540 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/11, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Sword Art Online: Alicization - War of Underworld
   Tür/yıl: Anime / 2020
   Kaynak: simkl
   Harici kimlikler: Anime:mal:40540, Anime:simkl:1186817
   Ham kimlik alanları: MAL ID=40540 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=1186817, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/11, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Sword Art Online Alicization War of Underworld (2nd cour)
   İngilizce başlık: Sword Art Online: Alicization - War of Underworld - Part 2
   Japonca başlık: ソードアート・オンライン アリシゼーション War of Underworld　最終章(2ndクール)
   Tür/yıl: Anime / 2020
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:42927
   Ham kimlik alanları: MAL ID=300042927 (dahili Kitsu kimliği, MAL değil: Kitsu #42927), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/11, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Sword Art Online: Alicization - War of Underworld 2nd Season
   Tür/yıl: Anime / 2020
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:40540, Anime:shikimori:40540
   Ham kimlik alanları: MAL ID=40540 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/11, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: ソードアート・オンライン アリシゼーション War of Underworld -THE LAST SEASON-
   Japonca başlık: ソードアート・オンライン アリシゼーション War of Underworld -THE LAST SEASON-
   Tür/yıl: Anime / 2020
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:292238
   Ham kimlik alanları: MAL ID=500292238 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/11, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 52 · HATA · AniList

- Rapor satırları: `3547–3633`
- Zaman: `2026-10-24 15:35:30.822 GMT+03:00`
- Kod: `KTS-ANL-2002`
- İşlem / neden: `update_error` / `identity_unverified`
- Tüm olay no: `2108`

```text
52. [2026-10-24 15:35:30.822 GMT+03:00] [HATA] [AniList] [AniList] ! Güncellenemedi: へんたつ
   Kod: KTS-ANL-2002
   | KTS-ANL-2002 · WARNING · ANL
   | TR — AniList çok fazla istek (GraphQL 429)
   | Neden: GraphQL yanıtı "Too Many Requests" döndü. AniList'in dakikalık limitinin yanında kısa aralıklı patlamaları engelleyen ayrı bir burst limiter'ı da var.
   | Çözüm: Bir dakika bekleyin; Retry-After başlığı kadar bekleme otomatik uygulanır.
   | EN — AniList rate limited (GraphQL 429)
   | Why: The GraphQL response returned "Too Many Requests". Besides the per-minute limit, AniList runs a separate burst limiter against short request spikes.
   | Fix: Wait a minute; the Retry-After delay is applied automatically.
   Hata: java.lang.IllegalStateException: AniList liste kaydının bu medya ile eşleştiği doğrulanamadı: へんたつ
     at com.kitsugi.animelist.data.auth.AniListSyncManager.updateAniListEntry(?:718)
     at com.kitsugi.animelist.data.auth.AniListSyncManager.updateAniListEntry$default(?:40)
     at c7.r1.invokeSuspend(?:26941)
     at kotlin.coroutines.jvm.internal.BaseContinuationImpl.resumeWith(?:11)
     at kotlinx.coroutines.DispatchedTask.run(?:128)
     at kotlinx.coroutines.internal.LimitedDispatcher$Worker.run(?:3)
   
   Kaynak platform kayıtları (6):
   Kayıt 1:
   Başlık: Hentatsu (TV Short)
   Japonca başlık: へんたつ (TV Short)
   Tür/yıl: Anime / 2020
   Kaynak: anilist
   Harici kimlikler: Anime:mal:40995
   Ham kimlik alanları: MAL ID=40995 (MAL), AniList kayıt ID=600509883, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: İzleniyor, bölüm=12/12, cilt=0, puan=7
   Tarihler: başlangıç=2026-10-04, bitiş=2026-10-04; favori=false
   
   Kayıt 2:
   Başlık: Hentatsu (TV)
   Japonca başlık: へんたつ
   Tür/yıl: Anime / 2020
   Kaynak: mal
   Harici kimlikler: Anime:mal:40995
   Ham kimlik alanları: MAL ID=40995 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: İzleniyor, bölüm=12/12, cilt=0, puan=7
   Tarihler: başlangıç=2026-10-04, bitiş=2026-10-04; favori=false
   
   Kayıt 3:
   Başlık: Hentatsu
   Tür/yıl: Anime / 2020
   Kaynak: simkl
   Harici kimlikler: Anime:mal:40995, Anime:simkl:1236853
   Ham kimlik alanları: MAL ID=40995 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=1236853, TMDB ID=yok
   Durum/ilerleme: İzleniyor, bölüm=0/12, cilt=0, puan=7
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 4:
   Başlık: Hentatsu (TV)
   Japonca başlık: へんたつ
   Tür/yıl: Anime / 2020
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:42939
   Ham kimlik alanları: MAL ID=300042939 (dahili Kitsu kimliği, MAL değil: Kitsu #42939), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=13/13, cilt=0, puan=7
   Tarihler: başlangıç=2026-10-04, bitiş=2026-10-04; favori=false
   
   Kayıt 5:
   Başlık: Hentatsu (TV)
   Tür/yıl: Anime / 2020
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:40995, Anime:shikimori:40995
   Ham kimlik alanları: MAL ID=40995 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: İzleniyor, bölüm=12/12, cilt=0, puan=7
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 6:
   Başlık: へんたつ
   Japonca başlık: へんたつ
   Tür/yıl: Anime / 2020
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:298010
   Ham kimlik alanları: MAL ID=500298010 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: İzleniyor, bölüm=12/12, cilt=0, puan=7
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Eşitleme için birleştirilen değerler:
   Başlık: へんたつ
   Japonca başlık: へんたつ (TV Short)
   Tür/yıl: Anime / 2020
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:40995, Anime:simkl:1236853
   Ham kimlik alanları: MAL ID=40995 (MAL), AniList kayıt ID=600509883, MAL liste ID=yok, Simkl ID=1236853, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=13/12, cilt=0, puan=7
   Tarihler: başlangıç=2026-10-04, bitiş=2026-10-04; favori=false
   
   Kimlik güvencesi: Gerek yok (tüm hedef platformlarda kayıt zaten var)
```

## Sorun 53 · HATA · AniList

- Rapor satırları: `3635–3712`
- Zaman: `2026-10-24 15:35:33.997 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `update_error` / `identity_unverified`
- Tüm olay no: `2119`

```text
53. [2026-10-24 15:35:33.997 GMT+03:00] [HATA] [AniList] [AniList] ! Güncellenemedi: 義姉はヤンママ授乳中
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Hata: java.lang.IllegalStateException: AniList liste kaydının bu medya ile eşleştiği doğrulanamadı: 義姉はヤンママ授乳中
     at com.kitsugi.animelist.data.auth.AniListSyncManager.updateAniListEntry(?:718)
     at com.kitsugi.animelist.data.auth.AniListSyncManager.updateAniListEntry$default(?:40)
     at c7.r1.invokeSuspend(?:26941)
     at kotlin.coroutines.jvm.internal.BaseContinuationImpl.resumeWith(?:11)
     at kotlinx.coroutines.DispatchedTask.run(?:128)
     at kotlinx.coroutines.internal.LimitedDispatcher$Worker.run(?:3)
   
   Kaynak platform kayıtları (5):
   Kayıt 1:
   Başlık: Ane wa Yanmama Junyuu-chuu
   Japonca başlık: 義姉はヤンママ授乳中
   Tür/yıl: Anime / 2020
   Kaynak: anilist
   Harici kimlikler: Anime:mal:41261
   Ham kimlik alanları: MAL ID=41261 (MAL), AniList kayıt ID=495060829, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=2/2, cilt=0, puan=7
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 2:
   Başlık: Ane wa Yanmama Junyuu-chuu
   Japonca başlık: 義姉はヤンママ授乳中
   Tür/yıl: Anime / 2020
   Kaynak: mal
   Harici kimlikler: Anime:mal:41261
   Ham kimlik alanları: MAL ID=41261 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=2/2, cilt=0, puan=7
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 3:
   Başlık: Gishi wa Yan Mama Junyuu Chuu
   Japonca başlık: 義姉はヤンママ授乳中
   Tür/yıl: Anime / 2020
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:43420
   Ham kimlik alanları: MAL ID=300043420 (dahili Kitsu kimliği, MAL değil: Kitsu #43420), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=2/2, cilt=0, puan=7
   Tarihler: başlangıç=2026-10-07, bitiş=2026-10-07; favori=false
   
   Kayıt 4:
   Başlık: Ane wa Yanmama Junyuu-chuu
   Tür/yıl: Anime / 2020
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:41261, Anime:shikimori:41261
   Ham kimlik alanları: MAL ID=41261 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=2/2, cilt=0, puan=7
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 5:
   Başlık: 義姉はヤンママ授乳中
   Japonca başlık: 義姉はヤンママ授乳中
   Tür/yıl: Anime / 2020
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:305740
   Ham kimlik alanları: MAL ID=500305740 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=2/2, cilt=0, puan=7
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Eşitleme için birleştirilen değerler:
   Başlık: 義姉はヤンママ授乳中
   Japonca başlık: 義姉はヤンママ授乳中
   Tür/yıl: Anime / 2020
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:41261
   Ham kimlik alanları: MAL ID=41261 (MAL), AniList kayıt ID=495060829, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=2/2, cilt=0, puan=7
   Tarihler: başlangıç=2026-10-07, bitiş=2026-10-07; favori=false
   
   Kimlik güvencesi: Güvenilir (MAL/Shikimori kaydının kendi kimliği)
```

## Sorun 54 · UYARI · Eşleştirme

- Rapor satırları: `3714–3763`
- Zaman: `2026-10-24 15:35:36.293 GMT+03:00`
- Kod: `—`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `2143`

```text
54. [2026-10-24 15:35:36.293 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Tensei Shitara Slime Datta Ken 2nd Season Part 2
   Başlık: Tensei Shitara Slime Datta Ken 2nd Season Part 2
   İngilizce başlık: That Time I Got Reincarnated as a Slime Season 2 Part 2
   Japonca başlık: 転生したらスライムだった件 第2期 第2クール
   Tür/yıl: Anime / 2021
   Kaynak: anilist
   Harici kimlikler: Anime:mal:41487
   Ham kimlik alanları: MAL ID=41487 (MAL), AniList kayıt ID=495061284, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Tensei shitara Slime Datta Ken 2nd Season Part 2
   İngilizce başlık: That Time I Got Reincarnated as a Slime Season 2 Part 2
   Japonca başlık: 転生したらスライムだった件
   Tür/yıl: Anime / 2021
   Kaynak: mal
   Harici kimlikler: Anime:mal:41487
   Ham kimlik alanları: MAL ID=41487 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Tensei Shitara Slime Datta Ken (2021 Dai 2 Bu)
   Tür/yıl: Anime / 2021
   Kaynak: simkl
   Harici kimlikler: Anime:mal:41487, Anime:simkl:1301569
   Ham kimlik alanları: MAL ID=41487 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=1301569, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Tensei shitara Slime Datta Ken 2nd Season Part 2
   İngilizce başlık: That Time I Got Reincarnated as a Slime Season 2 Part 2
   Japonca başlık: 転生したらスライムだった件
   Tür/yıl: Anime / 2021
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:43361
   Ham kimlik alanları: MAL ID=300043361 (dahili Kitsu kimliği, MAL değil: Kitsu #43361), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Tensei shitara Slime Datta Ken 2nd Season Part 2
   Tür/yıl: Anime / 2021
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:41487, Anime:shikimori:41487
   Ham kimlik alanları: MAL ID=41487 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 55 · UYARI · Eşleştirme

- Rapor satırları: `3765–3832`
- Zaman: `2026-10-24 15:35:37.892 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `2162`

```text
55. [2026-10-24 15:35:37.892 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Re:Zero kara Hajimeru Isekai Seikatsu 2nd Season Part 2
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: Re:Zero kara Hajimeru Isekai Seikatsu 2nd Season Part 2
   İngilizce başlık: Re:ZERO -Starting Life in Another World- Season 2 Part 2
   Japonca başlık: Re:ゼロから始める異世界生活 2nd Season Part 2
   Tür/yıl: Anime / 2021
   Kaynak: anilist
   Harici kimlikler: Anime:mal:42203
   Ham kimlik alanları: MAL ID=42203 (MAL), AniList kayıt ID=495061194, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=8
   Tarihler: başlangıç=2025-02-21, bitiş=2025-02-21; favori=false
   
   
   Başlık: Re:Zero kara Hajimeru Isekai Seikatsu 2nd Season Part 2
   İngilizce başlık: Re:ZERO -Starting Life in Another World- Season 2 Part 2
   Japonca başlık: Re：ゼロから始める異世界生活 2 part 2
   Tür/yıl: Anime / 2021
   Kaynak: mal
   Harici kimlikler: Anime:mal:42203
   Ham kimlik alanları: MAL ID=42203 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=8
   Tarihler: başlangıç=2025-02-21, bitiş=2025-02-21; favori=false
   
   
   Başlık: Re:Zero kara Hajimeru Isekai Seikatsu
   Tür/yıl: Anime / 2021
   Kaynak: simkl
   Harici kimlikler: Anime:mal:42203, Anime:simkl:1367345
   Ham kimlik alanları: MAL ID=42203 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=1367345, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=8
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Re:Zero kara Hajimeru Isekai Seikatsu 2nd Season Part 2
   İngilizce başlık: Re:ZERO -Starting Life in Another World- Season 2 Part 2
   Japonca başlık: ゼロから始める異世界生活
   Tür/yıl: Anime / 2021
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:43247
   Ham kimlik alanları: MAL ID=300043247 (dahili Kitsu kimliği, MAL değil: Kitsu #43247), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=8
   Tarihler: başlangıç=2023-01-25, bitiş=2025-02-21; favori=false
   
   
   Başlık: Re:Zero kara Hajimeru Isekai Seikatsu 2nd Season Part 2
   Tür/yıl: Anime / 2021
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:42203, Anime:shikimori:42203
   Ham kimlik alanları: MAL ID=42203 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=8
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Re:ゼロから始める異世界生活 2nd season 後半クール
   Japonca başlık: Re:ゼロから始める異世界生活 2nd season 後半クール
   Tür/yıl: Anime / 2021
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:316247
   Ham kimlik alanları: MAL ID=500316247 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=8
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 56 · UYARI · Eşleştirme

- Rapor satırları: `3834–3901`
- Zaman: `2026-10-24 15:35:40.868 GMT+03:00`
- Kod: `KTS-ANL-2002`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `2182`

```text
56. [2026-10-24 15:35:40.868 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Kanojo, Okarishimasu 2nd Season
   Kod: KTS-ANL-2002
   | KTS-ANL-2002 · WARNING · ANL
   | TR — AniList çok fazla istek (GraphQL 429)
   | Neden: GraphQL yanıtı "Too Many Requests" döndü. AniList'in dakikalık limitinin yanında kısa aralıklı patlamaları engelleyen ayrı bir burst limiter'ı da var.
   | Çözüm: Bir dakika bekleyin; Retry-After başlığı kadar bekleme otomatik uygulanır.
   | EN — AniList rate limited (GraphQL 429)
   | Why: The GraphQL response returned "Too Many Requests". Besides the per-minute limit, AniList runs a separate burst limiter against short request spikes.
   | Fix: Wait a minute; the Retry-After delay is applied automatically.
   Başlık: Kanojo, Okarishimasu 2nd Season
   İngilizce başlık: Rent-a-Girlfriend Season 2
   Japonca başlık: 彼女、お借りします 第2期
   Tür/yıl: Anime / 2022
   Kaynak: anilist
   Harici kimlikler: Anime:mal:42963
   Ham kimlik alanları: MAL ID=42963 (MAL), AniList kayıt ID=495061022, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=8
   Tarihler: başlangıç=2026-10-04, bitiş=2026-10-04; favori=false
   
   
   Başlık: Kanojo, Okarishimasu 2nd Season
   İngilizce başlık: Rent-a-Girlfriend Season 2
   Japonca başlık: 彼女、お借りします
   Tür/yıl: Anime / 2022
   Kaynak: mal
   Harici kimlikler: Anime:mal:42963
   Ham kimlik alanları: MAL ID=42963 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=8
   Tarihler: başlangıç=2026-10-04, bitiş=2026-10-04; favori=false
   
   
   Başlık: Kanojo, Okarishimasu
   Tür/yıl: Anime / 2022
   Kaynak: simkl
   Harici kimlikler: Anime:mal:42963, Anime:simkl:1440927
   Ham kimlik alanları: MAL ID=42963 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=1440927, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=8
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Kanojo, Okarishimasu Season 2
   İngilizce başlık: Rent-a-Girlfriend Season 2
   Japonca başlık: 彼女、お借りします
   Tür/yıl: Anime / 2022
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:43588
   Ham kimlik alanları: MAL ID=300043588 (dahili Kitsu kimliği, MAL değil: Kitsu #43588), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=8
   Tarihler: başlangıç=2023-03-28, bitiş=2026-10-04; favori=false
   
   
   Başlık: Kanojo, Okarishimasu 2nd Season
   Tür/yıl: Anime / 2022
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:42963, Anime:shikimori:42963
   Ham kimlik alanları: MAL ID=42963 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=8
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: 彼女、お借りします 第2期
   Japonca başlık: 彼女、お借りします 第2期
   Tür/yıl: Anime / 2022
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:315745
   Ham kimlik alanları: MAL ID=500315745 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=8
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 57 · HATA · AniList

- Rapor satırları: `3903–3992`
- Zaman: `2026-10-24 15:35:41.077 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `update_error` / `identity_unverified`
- Tüm olay no: `2192`

```text
57. [2026-10-24 15:35:41.077 GMT+03:00] [HATA] [AniList] [AniList] ! Güncellenemedi: アリス・ギア・アイギス ～ドキッ！アクトレスだらけのマーメイドグランプリ♡～
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Hata: java.lang.IllegalStateException: AniList liste kaydının bu medya ile eşleştiği doğrulanamadı: アリス・ギア・アイギス ～ドキッ！アクトレスだらけのマーメイドグランプリ♡～
     at com.kitsugi.animelist.data.auth.AniListSyncManager.updateAniListEntry(?:718)
     at com.kitsugi.animelist.data.auth.AniListSyncManager.updateAniListEntry$default(?:40)
     at c7.r1.invokeSuspend(?:26941)
     at kotlin.coroutines.jvm.internal.BaseContinuationImpl.resumeWith(?:11)
     at kotlinx.coroutines.DispatchedTask.run(?:128)
     at kotlinx.coroutines.internal.LimitedDispatcher$Worker.run(?:3)
   
   Kaynak platform kayıtları (6):
   Kayıt 1:
   Başlık: Alice Gear Aegis: Doki! Actress Darake no Mermaid Grand Prix ♥
   İngilizce başlık: alice gear aegis Expansion: Heart Pounding! Actress Packed Mermaid Grand Prix!
   Japonca başlık: アリス・ギア・アイギス ～ドキッ！アクトレスだらけのマーメイドグランプリ♥～
   Tür/yıl: Anime / 2021
   Kaynak: anilist
   Harici kimlikler: Anime:mal:43506
   Ham kimlik alanları: MAL ID=43506 (MAL), AniList kayıt ID=600509599, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=3/3, cilt=0, puan=7
   Tarihler: başlangıç=2026-10-04, bitiş=2026-10-04; favori=false
   
   Kayıt 2:
   Başlık: Alice Gear Aegis: Doki! Actress Darake no Mermaid Grand Prix♥
   İngilizce başlık: Alice Gear Aegis Expansion: Heart Pounding! Actress Packed Mermaid Grand Prix!
   Japonca başlık: アリス・ギア・アイギス ～ドキッ！アクトレスだらけのマーメイドグランプリ♥～
   Tür/yıl: Anime / 2021
   Kaynak: mal
   Harici kimlikler: Anime:mal:43506
   Ham kimlik alanları: MAL ID=43506 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=7
   Tarihler: başlangıç=2026-10-04, bitiş=2026-10-04; favori=false
   
   Kayıt 3:
   Başlık: Alice Gear Aegis: Doki! Actress Darake no Mermaid Grand Prix
   Tür/yıl: Anime / 2021
   Kaynak: simkl
   Harici kimlikler: Anime:mal:43506, Anime:simkl:1530945
   Ham kimlik alanları: MAL ID=43506 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=1530945, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=7
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 4:
   Başlık: Alice Gear Aegis: Doki! Actress Darake no Mermaid Grand Prix ♥
   Japonca başlık: アリス・ギア・アイギス ～ドキッ！アクトレスだらけのマーメイドグランプリ♥～
   Tür/yıl: Anime / 2021
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:47257
   Ham kimlik alanları: MAL ID=300047257 (dahili Kitsu kimliği, MAL değil: Kitsu #47257), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=6/6, cilt=0, puan=7
   Tarihler: başlangıç=2026-10-04, bitiş=2026-10-04; favori=false
   
   Kayıt 5:
   Başlık: Alice Gear Aegis: Doki! Actress Darake no Mermaid Grand Prix♥
   Tür/yıl: Anime / 2021
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:43506, Anime:shikimori:43506
   Ham kimlik alanları: MAL ID=43506 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=7
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 6:
   Başlık: アリス・ギア・アイギス ～ドキッ！アクトレスだらけのマーメイドグランプリ♡～
   Japonca başlık: アリス・ギア・アイギス ～ドキッ！アクトレスだらけのマーメイドグランプリ♡～
   Tür/yıl: Anime / 2021
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:343710
   Ham kimlik alanları: MAL ID=500343710 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=3/3, cilt=0, puan=7
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Eşitleme için birleştirilen değerler:
   Başlık: アリス・ギア・アイギス ～ドキッ！アクトレスだらけのマーメイドグランプリ♡～
   İngilizce başlık: alice gear aegis Expansion: Heart Pounding! Actress Packed Mermaid Grand Prix!
   Japonca başlık: アリス・ギア・アイギス ～ドキッ！アクトレスだらけのマーメイドグランプリ♥～
   Tür/yıl: Anime / 2021
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:43506, Anime:simkl:1530945
   Ham kimlik alanları: MAL ID=43506 (MAL), AniList kayıt ID=600509599, MAL liste ID=yok, Simkl ID=1530945, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=6/3, cilt=0, puan=7
   Tarihler: başlangıç=2026-10-04, bitiş=2026-10-04; favori=false
   
   Kimlik güvencesi: Gerek yok (tüm hedef platformlarda kayıt zaten var)
```

## Sorun 58 · UYARI · Eşleştirme

- Rapor satırları: `3994–4061`
- Zaman: `2026-10-24 15:35:44.677 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `2212`

```text
58. [2026-10-24 15:35:44.677 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Mushoku Tensei: Isekai Ittara Honki Dasu Part 2
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: Mushoku Tensei: Isekai Ittara Honki Dasu Part 2
   İngilizce başlık: Mushoku Tensei: Jobless Reincarnation Cour 2
   Japonca başlık: 無職転生 ～異世界行ったら本気だす～ 第2クール
   Tür/yıl: Anime / 2021
   Kaynak: anilist
   Harici kimlikler: Anime:mal:45576
   Ham kimlik alanları: MAL ID=45576 (MAL), AniList kayıt ID=495061132, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=10
   Tarihler: başlangıç=yok, bitiş=yok; favori=true
   
   
   Başlık: Mushoku Tensei: Isekai Ittara Honki Dasu Part 2
   İngilizce başlık: Mushoku Tensei: Jobless Reincarnation Part 2
   Japonca başlık: 無職転生 ～異世界行ったら本気だす～ 第2クール
   Tür/yıl: Anime / 2021
   Kaynak: mal
   Harici kimlikler: Anime:mal:45576
   Ham kimlik alanları: MAL ID=45576 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=10
   Tarihler: başlangıç=2023-01-18, bitiş=2024-03-20; favori=false
   
   
   Başlık: Mushoku Tensei: Isekai Ittara Honki Dasu
   Tür/yıl: Anime / 2021
   Kaynak: simkl
   Harici kimlikler: Anime:mal:45576, Anime:simkl:1524389
   Ham kimlik alanları: MAL ID=45576 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=1524389, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=10
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Mushoku Tensei: Isekai Ittara Honki Dasu Part 2
   İngilizce başlık: Mushoku Tensei: Jobless Reincarnation Part 2
   Japonca başlık: 無職転生 ～異世界行ったら本気だす～ 第2クール
   Tür/yıl: Anime / 2021
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:43907
   Ham kimlik alanları: MAL ID=300043907 (dahili Kitsu kimliği, MAL değil: Kitsu #43907), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=10
   Tarihler: başlangıç=2023-01-18, bitiş=2024-03-20; favori=false
   
   
   Başlık: Mushoku Tensei: Isekai Ittara Honki Dasu Part 2
   Tür/yıl: Anime / 2021
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:45576, Anime:shikimori:45576
   Ham kimlik alanları: MAL ID=45576 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=10
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: 無職転生 ～異世界行ったら本気だす～ 第2クール
   Japonca başlık: 無職転生 ～異世界行ったら本気だす～ 第2クール
   Tür/yıl: Anime / 2021
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:325585
   Ham kimlik alanları: MAL ID=500325585 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=10
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 59 · HATA · AniList

- Rapor satırları: `4063–4153`
- Zaman: `2026-10-24 15:35:45.050 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `update_error` / `identity_unverified`
- Tüm olay no: `2226`

```text
59. [2026-10-24 15:35:45.050 GMT+03:00] [HATA] [AniList] [AniList] ! Güncellenemedi: 友達の妹が俺にだけウザい
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Hata: java.lang.IllegalStateException: AniList liste kaydının bu medya ile eşleştiği doğrulanamadı: 友達の妹が俺にだけウザい
     at com.kitsugi.animelist.data.auth.AniListSyncManager.updateAniListEntry(?:718)
     at com.kitsugi.animelist.data.auth.AniListSyncManager.updateAniListEntry$default(?:40)
     at c7.r1.invokeSuspend(?:26941)
     at kotlin.coroutines.jvm.internal.BaseContinuationImpl.resumeWith(?:11)
     at kotlinx.coroutines.DispatchedTask.run(?:128)
     at kotlinx.coroutines.internal.LimitedDispatcher$Worker.run(?:3)
   
   Kaynak platform kayıtları (6):
   Kayıt 1:
   Başlık: Tomodachi no Imouto ga Ore ni dake Uzai
   İngilizce başlık: My Friend's Little Sister Has It In for Me!
   Japonca başlık: 友達の妹が俺にだけウザい
   Tür/yıl: Anime / 2025
   Kaynak: anilist
   Harici kimlikler: Anime:mal:47158
   Ham kimlik alanları: MAL ID=47158 (MAL), AniList kayıt ID=510359892, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 2:
   Başlık: Tomodachi no Imouto ga Ore ni dake Uzai
   İngilizce başlık: My Friend's Little Sister Has It In for Me!
   Japonca başlık: 友達の妹が俺にだけウザい
   Tür/yıl: Anime / 2025
   Kaynak: mal
   Harici kimlikler: Anime:mal:47158
   Ham kimlik alanları: MAL ID=47158 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 3:
   Başlık: Tomodachi no Imouto ga Ore ni dake Uzai
   Tür/yıl: Anime / 2025
   Kaynak: simkl
   Harici kimlikler: Anime:mal:47158, Anime:simkl:1536151, Anime:tmdb:117879
   Ham kimlik alanları: MAL ID=47158 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=1536151, TMDB ID=117879
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 4:
   Başlık: Tomodachi no Imouto ga Ore ni dake Uzai
   İngilizce başlık: My Friend's Little Sister Has It In for Me!
   Japonca başlık: 友達の妹が俺にだけウザい
   Tür/yıl: Anime / 2025
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:44019
   Ham kimlik alanları: MAL ID=300044019 (dahili Kitsu kimliği, MAL değil: Kitsu #44019), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 5:
   Başlık: Tomodachi no Imouto ga Ore ni dake Uzai
   Tür/yıl: Anime / 2025
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:47158, Anime:shikimori:47158
   Ham kimlik alanları: MAL ID=47158 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 6:
   Başlık: 友達の妹が俺にだけウザい
   Japonca başlık: 友達の妹が俺にだけウザい
   Tür/yıl: Anime / 2025
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:326859
   Ham kimlik alanları: MAL ID=500326859 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=10
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Eşitleme için birleştirilen değerler:
   Başlık: 友達の妹が俺にだけウザい
   İngilizce başlık: My Friend's Little Sister Has It In for Me!
   Japonca başlık: 友達の妹が俺にだけウザい
   Tür/yıl: Anime / 2025
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:47158, Anime:simkl:1536151, Anime:tmdb:117879
   Ham kimlik alanları: MAL ID=47158 (MAL), AniList kayıt ID=510359892, MAL liste ID=yok, Simkl ID=1536151, TMDB ID=117879
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=10
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kimlik güvencesi: Gerek yok (tüm hedef platformlarda kayıt zaten var)
```

## Sorun 60 · UYARI · Eşleştirme

- Rapor satırları: `4155–4222`
- Zaman: `2026-10-24 15:36:11.672 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `2230`

```text
60. [2026-10-24 15:36:11.672 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Dungeon ni Deai wo Motomeru no wa Machigatteiru Darou ka IV: Shin Shou Meikyuu-hen
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: Dungeon ni Deai wo Motomeru no wa Machigatteiru Darou ka IV: Shin Shou Meikyuu-hen
   İngilizce başlık: Is It Wrong to Try to Pick Up Girls in a Dungeon? IV
   Japonca başlık: ダンジョンに出会いを求めるのは間違っているだろうかⅣ 新章 迷宮篇
   Tür/yıl: Anime / 2022
   Kaynak: anilist
   Harici kimlikler: Anime:mal:47164
   Ham kimlik alanları: MAL ID=47164 (MAL), AniList kayıt ID=495060903, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=11/11, cilt=0, puan=6
   Tarihler: başlangıç=2026-10-04, bitiş=2026-10-04; favori=false
   
   
   Başlık: Dungeon ni Deai wo Motomeru no wa Machigatteiru Darou ka IV: Shin Shou - Meikyuu-hen
   İngilizce başlık: Is It Wrong to Try to Pick Up Girls in a Dungeon? IV
   Japonca başlık: ダンジョンに出会いを求めるのは間違っているだろうかⅣ 新章 迷宮篇
   Tür/yıl: Anime / 2022
   Kaynak: mal
   Harici kimlikler: Anime:mal:47164
   Ham kimlik alanları: MAL ID=47164 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=11/11, cilt=0, puan=6
   Tarihler: başlangıç=2026-10-04, bitiş=2026-10-04; favori=false
   
   
   Başlık: Dungeon ni Deai o Motomeru no wa Machigatte Iru Darouka: Familia Myth IV
   Tür/yıl: Anime / 2022
   Kaynak: simkl
   Harici kimlikler: Anime:mal:47164, Anime:simkl:1536161
   Ham kimlik alanları: MAL ID=47164 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=1536161, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=11/11, cilt=0, puan=6
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Dungeon ni Deai wo Motomeru no wa Machigatteiru Darou ka IV
   İngilizce başlık: Is It Wrong to Try to Pick Up Girls in a Dungeon? IV
   Japonca başlık: ダンジョンに出会いを求めるのは間違っているだろうかⅣ
   Tür/yıl: Anime / 2022
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:44031
   Ham kimlik alanları: MAL ID=300044031 (dahili Kitsu kimliği, MAL değil: Kitsu #44031), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=11/11, cilt=0, puan=6
   Tarihler: başlangıç=2025-10-22, bitiş=2025-10-28; favori=false
   
   
   Başlık: Dungeon ni Deai wo Motomeru no wa Machigatteiru Darou ka IV: Shin Shou - Meikyuu-hen
   Tür/yıl: Anime / 2022
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:47164, Anime:shikimori:47164
   Ham kimlik alanları: MAL ID=47164 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=11/11, cilt=0, puan=6
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: ダンジョンに出会いを求めるのは間違っているだろうかⅣ 新章 迷宮篇
   Japonca başlık: ダンジョンに出会いを求めるのは間違っているだろうかⅣ 新章 迷宮篇
   Tür/yıl: Anime / 2022
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:326874
   Ham kimlik alanları: MAL ID=500326874 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=11/11, cilt=0, puan=6
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 61 · UYARI · Eşleştirme

- Rapor satırları: `4224–4291`
- Zaman: `2026-10-24 15:37:39.287 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `2250`

```text
61. [2026-10-24 15:37:39.287 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Go-toubun no Hanayome Movie
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: Go-toubun no Hanayome Movie
   İngilizce başlık: The Quintessential Quintuplets Movie
   Japonca başlık: 映画 五等分の花嫁
   Tür/yıl: Anime / 2022
   Kaynak: anilist
   Harici kimlikler: Anime:mal:48548
   Ham kimlik alanları: MAL ID=48548 (MAL), AniList kayıt ID=495060811, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: 5-toubun no Hanayome Movie
   İngilizce başlık: The Quintessential Quintuplets Movie
   Japonca başlık: 映画 五等分の花嫁
   Tür/yıl: Anime / 2022
   Kaynak: mal
   Harici kimlikler: Anime:mal:48548
   Ham kimlik alanları: MAL ID=48548 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Eiga Go-Toubun no Hanayome
   Tür/yıl: Anime / 2022
   Kaynak: simkl
   Harici kimlikler: Anime:mal:48548, Anime:simkl:1577789, Anime:tmdb:820067
   Ham kimlik alanları: MAL ID=48548 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=1577789, TMDB ID=820067
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: 5-Toubun no Hanayome
   İngilizce başlık: The Quintessential Quintuplets Movie
   Japonca başlık: 五等分の花嫁
   Tür/yıl: Anime / 2022
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:44229
   Ham kimlik alanları: MAL ID=300044229 (dahili Kitsu kimliği, MAL değil: Kitsu #44229), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: 5-toubun no Hanayome Movie
   Tür/yıl: Anime / 2022
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:48548, Anime:shikimori:48548
   Ham kimlik alanları: MAL ID=48548 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: 映画 五等分の花嫁
   Japonca başlık: 映画 五等分の花嫁
   Tür/yıl: Anime / 2022
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:331489
   Ham kimlik alanları: MAL ID=500331489 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 62 · HATA · AniList

- Rapor satırları: `4293–4374`
- Zaman: `2026-10-24 15:38:32.704 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `update_error` / `identity_unverified`
- Tüm olay no: `2275`

```text
62. [2026-10-24 15:38:32.704 GMT+03:00] [HATA] [AniList] [AniList] ! Güncellenemedi: らぶみー「楓と鈴」THE ANIMATION
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Hata: java.lang.IllegalStateException: AniList liste kaydının bu medya ile eşleştiği doğrulanamadı: らぶみー「楓と鈴」THE ANIMATION
     at com.kitsugi.animelist.data.auth.AniListSyncManager.updateAniListEntry(?:718)
     at com.kitsugi.animelist.data.auth.AniListSyncManager.updateAniListEntry$default(?:40)
     at c7.r1.invokeSuspend(?:26941)
     at kotlin.coroutines.jvm.internal.BaseContinuationImpl.resumeWith(?:11)
     at kotlinx.coroutines.UndispatchedCoroutine.afterResume(?:30)
     at kotlinx.coroutines.AbstractCoroutine.resumeWith(?:13)
   
   Kaynak platform kayıtları (5):
   Kayıt 1:
   Başlık: Kaede to Suzu THE ANIMATION
   İngilizce başlık: Love Me: Kaede and Suzu THE ANIMATION
   Japonca başlık: 楓と鈴 THE ANIMATION
   Tür/yıl: Anime / 2022
   Kaynak: anilist
   Harici kimlikler: Anime:mal:50634
   Ham kimlik alanları: MAL ID=50634 (MAL), AniList kayıt ID=495061083, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=3/3, cilt=0, puan=9
   Tarihler: başlangıç=yok, bitiş=yok; favori=true
   
   Kayıt 2:
   Başlık: Love Me: Kaede to Suzu The Animation
   İngilizce başlık: Love Me: Kaede and Suzu The Animation
   Japonca başlık: らぶみー『楓と鈴』 THE ANIMATION
   Tür/yıl: Anime / 2022
   Kaynak: mal
   Harici kimlikler: Anime:mal:50634
   Ham kimlik alanları: MAL ID=50634 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=3/3, cilt=0, puan=9
   Tarihler: başlangıç=2026-10-07, bitiş=2025-11-10; favori=false
   
   Kayıt 3:
   Başlık: Kaede to Suzu THE ANIMATION
   İngilizce başlık: Love Me: Kaede and Suzu THE ANIMATION
   Japonca başlık: 楓と鈴 THE ANIMATION
   Tür/yıl: Anime / 2022
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:46028
   Ham kimlik alanları: MAL ID=300046028 (dahili Kitsu kimliği, MAL değil: Kitsu #46028), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=3/3, cilt=0, puan=9
   Tarihler: başlangıç=2026-10-07, bitiş=2026-10-07; favori=false
   
   Kayıt 4:
   Başlık: Love Me: Kaede to Suzu The Animation
   Tür/yıl: Anime / 2022
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:50634, Anime:shikimori:50634
   Ham kimlik alanları: MAL ID=50634 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=3/3, cilt=0, puan=9
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 5:
   Başlık: らぶみー「楓と鈴」THE ANIMATION
   Japonca başlık: らぶみー「楓と鈴」THE ANIMATION
   Tür/yıl: Anime / 2022
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:338672
   Ham kimlik alanları: MAL ID=500338672 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=3/3, cilt=0, puan=9
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Eşitleme için birleştirilen değerler:
   Başlık: らぶみー「楓と鈴」THE ANIMATION
   İngilizce başlık: Love Me: Kaede and Suzu THE ANIMATION
   Japonca başlık: 楓と鈴 THE ANIMATION
   Tür/yıl: Anime / 2022
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:50634
   Ham kimlik alanları: MAL ID=50634 (MAL), AniList kayıt ID=495061083, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=3/3, cilt=0, puan=9
   Tarihler: başlangıç=2026-10-07, bitiş=2026-10-07; favori=true
   
   Kimlik güvencesi: Güvenilir (MAL/Shikimori kaydının kendi kimliği)
```

## Sorun 63 · HATA · AniList

- Rapor satırları: `4376–4466`
- Zaman: `2026-10-24 15:39:21.436 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `update_error` / `identity_unverified`
- Tüm olay no: `2296`

```text
63. [2026-10-24 15:39:21.436 GMT+03:00] [HATA] [AniList] [AniList] ! Güncellenemedi: 君を愛したひとりの僕へ
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Hata: java.lang.IllegalStateException: AniList liste kaydının bu medya ile eşleştiği doğrulanamadı: 君を愛したひとりの僕へ
     at com.kitsugi.animelist.data.auth.AniListSyncManager.updateAniListEntry(?:718)
     at com.kitsugi.animelist.data.auth.AniListSyncManager.updateAniListEntry$default(?:40)
     at c7.r1.invokeSuspend(?:26941)
     at kotlin.coroutines.jvm.internal.BaseContinuationImpl.resumeWith(?:11)
     at kotlinx.coroutines.UndispatchedCoroutine.afterResume(?:30)
     at kotlinx.coroutines.AbstractCoroutine.resumeWith(?:13)
   
   Kaynak platform kayıtları (6):
   Kayıt 1:
   Başlık: Kimi wo Aishita Hitori no Boku e
   İngilizce başlık: To Me, The One Who Loved You
   Japonca başlık: 君を愛したひとりの僕へ
   Tür/yıl: Anime / 2022
   Kaynak: anilist
   Harici kimlikler: Anime:mal:49835
   Ham kimlik alanları: MAL ID=49835 (MAL), AniList kayıt ID=495061043, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=7
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 2:
   Başlık: Kimi wo Aishita Hitori no Boku e
   İngilizce başlık: To Me, The One Who Loved You
   Japonca başlık: 君を愛したひとりの僕へ
   Tür/yıl: Anime / 2022
   Kaynak: mal
   Harici kimlikler: Anime:mal:49835
   Ham kimlik alanları: MAL ID=49835 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=7
   Tarihler: başlangıç=2025-07-11, bitiş=2025-07-11; favori=false
   
   Kayıt 3:
   Başlık: Kimi o Aishita Hitori no Boku e
   Tür/yıl: Anime / 2022
   Kaynak: simkl
   Harici kimlikler: Anime:mal:49835, Anime:simkl:1732195, Anime:tmdb:874745
   Ham kimlik alanları: MAL ID=49835 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=1732195, TMDB ID=874745
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=7
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 4:
   Başlık: Kimi wo Aishita Hitori no Boku e
   İngilizce başlık: To Me, The One Who Loved You
   Japonca başlık: 君を愛したひとりの僕へ
   Tür/yıl: Anime / 2022
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:45219
   Ham kimlik alanları: MAL ID=300045219 (dahili Kitsu kimliği, MAL değil: Kitsu #45219), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=7
   Tarihler: başlangıç=2025-07-11, bitiş=2025-07-11; favori=false
   
   Kayıt 5:
   Başlık: Kimi wo Aishita Hitori no Boku e
   Tür/yıl: Anime / 2022
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:49835, Anime:shikimori:49835
   Ham kimlik alanları: MAL ID=49835 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=7
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 6:
   Başlık: 君を愛したひとりの僕へ
   Japonca başlık: 君を愛したひとりの僕へ
   Tür/yıl: Anime / 2022
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:363042
   Ham kimlik alanları: MAL ID=500363042 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=7
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Eşitleme için birleştirilen değerler:
   Başlık: 君を愛したひとりの僕へ
   İngilizce başlık: To Me, The One Who Loved You
   Japonca başlık: 君を愛したひとりの僕へ
   Tür/yıl: Anime / 2022
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:49835, Anime:simkl:1732195, Anime:tmdb:874745
   Ham kimlik alanları: MAL ID=49835 (MAL), AniList kayıt ID=495061043, MAL liste ID=yok, Simkl ID=1732195, TMDB ID=874745
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=7
   Tarihler: başlangıç=2025-07-11, bitiş=2025-07-11; favori=false
   
   Kimlik güvencesi: Gerek yok (tüm hedef platformlarda kayıt zaten var)
```

## Sorun 64 · UYARI · Eşleştirme

- Rapor satırları: `4468–4526`
- Zaman: `2026-10-24 15:39:21.749 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `2308`

```text
64. [2026-10-24 15:39:21.749 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Yonde Yobarete
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: Yonde Yobarete
   İngilizce başlık: call me, call you
   Japonca başlık: よんでよばれて
   Tür/yıl: Anime / 2020
   Kaynak: anilist
   Harici kimlikler: Anime:mal:58219
   Ham kimlik alanları: MAL ID=58219 (MAL), AniList kayıt ID=600512129, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=8
   Tarihler: başlangıç=2026-10-04, bitiş=2026-10-04; favori=false
   
   
   Başlık: Yonde Yobarete
   İngilizce başlık: Call Me, Call You
   Japonca başlık: よんでよばれて
   Tür/yıl: Anime / 2020
   Kaynak: mal
   Harici kimlikler: Anime:mal:58219
   Ham kimlik alanları: MAL ID=58219 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=8
   Tarihler: başlangıç=2026-10-04, bitiş=2026-10-04; favori=false
   
   
   Başlık: Yonde Yobarete
   İngilizce başlık: call me, call you
   Japonca başlık: よんでよばれて
   Tür/yıl: Anime / 2020
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:45332
   Ham kimlik alanları: MAL ID=300045332 (dahili Kitsu kimliği, MAL değil: Kitsu #45332), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=8
   Tarihler: başlangıç=2026-10-04, bitiş=2026-10-04; favori=false
   
   
   Başlık: Yonde Yobarete
   Tür/yıl: Anime / 2020
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:58219, Anime:shikimori:58219
   Ham kimlik alanları: MAL ID=58219 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=8
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: うまよん
   Japonca başlık: うまよん
   Tür/yıl: Anime / 2020
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:269389
   Ham kimlik alanları: MAL ID=500269389 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/12, cilt=0, puan=8
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 65 · HATA · AniList

- Rapor satırları: `4528–4607`
- Zaman: `2026-10-24 15:39:46.923 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `update_error` / `identity_unverified`
- Tüm olay no: `2318`

```text
65. [2026-10-24 15:39:46.923 GMT+03:00] [HATA] [AniList] [AniList] ! Güncellenemedi: エロ医師
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Hata: java.lang.IllegalStateException: AniList liste kaydının bu medya ile eşleştiği doğrulanamadı: エロ医師
     at com.kitsugi.animelist.data.auth.AniListSyncManager.updateAniListEntry(?:718)
     at com.kitsugi.animelist.data.auth.AniListSyncManager.updateAniListEntry$default(?:40)
     at c7.r1.invokeSuspend(?:26941)
     at kotlin.coroutines.jvm.internal.BaseContinuationImpl.resumeWith(?:11)
     at kotlinx.coroutines.UndispatchedCoroutine.afterResume(?:30)
     at kotlinx.coroutines.AbstractCoroutine.resumeWith(?:13)
   
   Kaynak platform kayıtları (5):
   Kayıt 1:
   Başlık: Ero Ishi
   İngilizce başlık: Ero doctor
   Japonca başlık: エロ医師
   Tür/yıl: Anime / 2022
   Kaynak: anilist
   Harici kimlikler: Anime:mal:50434
   Ham kimlik alanları: MAL ID=50434 (MAL), AniList kayıt ID=495060909, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: İzleniyor, bölüm=0/4, cilt=0, puan=5
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 2:
   Başlık: Ero Ishi: Seijun Bishoujo wo Kotoba Takumi ni Hametai Houdai
   Japonca başlık: エロ医師 ~清純美少女を言葉巧みにハメたい放題~
   Tür/yıl: Anime / 2022
   Kaynak: mal
   Harici kimlikler: Anime:mal:50434
   Ham kimlik alanları: MAL ID=50434 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: İzleniyor, bölüm=0/4, cilt=0, puan=5
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 3:
   Başlık: Ero Ishi: Seijun Bishoujo wo Kotoba Takumi ni Hametai Houdai
   Japonca başlık: エロ医師 ~清純美少女を言葉巧みにハメたい放題~
   Tür/yıl: Anime / 2022
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:45919
   Ham kimlik alanları: MAL ID=300045919 (dahili Kitsu kimliği, MAL değil: Kitsu #45919), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: İzleniyor, bölüm=0/4, cilt=0, puan=5
   Tarihler: başlangıç=2026-10-07, bitiş=yok; favori=false
   
   Kayıt 4:
   Başlık: Ero Ishi: Seijun Bishoujo wo Kotoba Takumi ni Hametai Houdai
   Tür/yıl: Anime / 2022
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:50434, Anime:shikimori:50434
   Ham kimlik alanları: MAL ID=50434 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: İzleniyor, bölüm=0/4, cilt=0, puan=5
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 5:
   Başlık: エロ医師
   Japonca başlık: エロ医師
   Tür/yıl: Anime / 2022
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:354684
   Ham kimlik alanları: MAL ID=500354684 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: İzleniyor, bölüm=0/4, cilt=0, puan=5
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Eşitleme için birleştirilen değerler:
   Başlık: エロ医師
   İngilizce başlık: Ero doctor
   Japonca başlık: エロ医師
   Tür/yıl: Anime / 2022
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:50434
   Ham kimlik alanları: MAL ID=50434 (MAL), AniList kayıt ID=495060909, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: İzleniyor, bölüm=0/4, cilt=0, puan=5
   Tarihler: başlangıç=2026-10-07, bitiş=yok; favori=false
   
   Kimlik güvencesi: Güvenilir (MAL/Shikimori kaydının kendi kimliği)
```

## Sorun 66 · UYARI · Eşleştirme

- Rapor satırları: `4609–4676`
- Zaman: `2026-10-24 15:39:48.372 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `2324`

```text
66. [2026-10-24 15:39:48.372 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Tonikaku Kawaii Season 2
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: Tonikaku Kawaii Season 2
   İngilizce başlık: TONIKAWA: Over The Moon For You Season 2
   Japonca başlık: トニカクカワイイ（シーズン2）
   Tür/yıl: Anime / 2023
   Kaynak: anilist
   Harici kimlikler: Anime:mal:50307
   Ham kimlik alanları: MAL ID=50307 (MAL), AniList kayıt ID=495061308, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Tonikaku Kawaii 2nd Season
   İngilizce başlık: Tonikawa: Over The Moon For You Season 2
   Japonca başlık: トニカクカワイイ
   Tür/yıl: Anime / 2023
   Kaynak: mal
   Harici kimlikler: Anime:mal:50307
   Ham kimlik alanları: MAL ID=50307 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Tonikaku Kawaii
   Tür/yıl: Anime / 2023
   Kaynak: simkl
   Harici kimlikler: Anime:mal:50307, Anime:simkl:1771533
   Ham kimlik alanları: MAL ID=50307 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=1771533, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Tonikaku Kawaii 2
   İngilizce başlık: TONIKAWA: Over the Moon For You 2
   Japonca başlık: トニカクカワイイ2
   Tür/yıl: Anime / 2023
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:45415
   Ham kimlik alanları: MAL ID=300045415 (dahili Kitsu kimliği, MAL değil: Kitsu #45415), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Tonikaku Kawaii 2nd Season
   Tür/yıl: Anime / 2023
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:50307, Anime:shikimori:50307
   Ham kimlik alanları: MAL ID=50307 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: トニカクカワイイ 第2期
   Japonca başlık: トニカクカワイイ 第2期
   Tür/yıl: Anime / 2023
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:355798
   Ham kimlik alanları: MAL ID=500355798 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 67 · UYARI · Eşleştirme

- Rapor satırları: `4678–4726`
- Zaman: `2026-10-24 15:39:48.386 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `2331`

```text
67. [2026-10-24 15:39:48.386 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Mushoku Tensei: Isekai Ittara Honki Dasu Part 2 - Eris no Goblin Toubatsu
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: Mushoku Tensei: Isekai Ittara Honki Dasu Part 2 - Eris no Goblin Toubatsu
   İngilizce başlık: Mushoku Tensei: Jobless Reincarnation Cour 2 - Eris the Goblin Slayer
   Japonca başlık: 無職転生 ～異世界行ったら本気だす～ 第2クール エリスのゴブリン討伐
   Tür/yıl: Anime / 2022
   Kaynak: anilist
   Harici kimlikler: Anime:mal:50360
   Ham kimlik alanları: MAL ID=50360 (MAL), AniList kayıt ID=495061131, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=8
   Tarihler: başlangıç=2025-02-21, bitiş=2025-02-21; favori=true
   
   
   Başlık: Mushoku Tensei: Isekai Ittara Honki Dasu - Eris no Goblin Toubatsu
   İngilizce başlık: Mushoku Tensei: Jobless Reincarnation - Eris the Goblin Slayer
   Japonca başlık: 無職転生 ～異世界行ったら本気だす～ エリスのゴブリン討伐
   Tür/yıl: Anime / 2022
   Kaynak: mal
   Harici kimlikler: Anime:mal:50360
   Ham kimlik alanları: MAL ID=50360 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=8
   Tarihler: başlangıç=2025-02-21, bitiş=2025-02-21; favori=false
   
   
   Başlık: Mushoku Tensei: Isekai Ittara Honki Dasu Part 2 - Eris no Goblin Toubatsu
   İngilizce başlık: Mushoku Tensei: Jobless Reincarnation Part 2 - Eris the Goblin Slayer
   Japonca başlık: 無職転生 ～異世界行ったら本気だす～ 第2クール エリスのゴブリン討伐
   Tür/yıl: Anime / 2022
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:45492
   Ham kimlik alanları: MAL ID=300045492 (dahili Kitsu kimliği, MAL değil: Kitsu #45492), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=8
   Tarihler: başlangıç=2023-01-21, bitiş=2024-07-10; favori=false
   
   
   Başlık: Mushoku Tensei: Isekai Ittara Honki Dasu - Eris no Goblin Toubatsu
   Tür/yıl: Anime / 2022
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:50360, Anime:shikimori:50360
   Ham kimlik alanları: MAL ID=50360 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=8
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 68 · HATA · AniList

- Rapor satırları: `4728–4807`
- Zaman: `2026-10-24 15:40:06.691 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `update_error` / `identity_unverified`
- Tüm olay no: `2337`

```text
68. [2026-10-24 15:40:06.691 GMT+03:00] [HATA] [AniList] [AniList] ! Güncellenemedi: Garden ～高嶺家の二輪花～ THE ANIMATION
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Hata: java.lang.IllegalStateException: AniList liste kaydının bu medya ile eşleştiği doğrulanamadı: Garden ～高嶺家の二輪花～ THE ANIMATION
     at com.kitsugi.animelist.data.auth.AniListSyncManager.updateAniListEntry(?:718)
     at com.kitsugi.animelist.data.auth.AniListSyncManager.updateAniListEntry$default(?:40)
     at c7.r1.invokeSuspend(?:26941)
     at kotlin.coroutines.jvm.internal.BaseContinuationImpl.resumeWith(?:11)
     at kotlinx.coroutines.DispatchedTask.run(?:128)
     at kotlinx.coroutines.internal.LimitedDispatcher$Worker.run(?:3)
   
   Kaynak platform kayıtları (5):
   Kayıt 1:
   Başlık: Garden: Takamine-ke no Nirinka The Animation
   İngilizce başlık: Garden -The Two Flowers of the Takamine Family- THE ANIMATION
   Japonca başlık: Garden ～高嶺家の二輪花～ The Animation
   Tür/yıl: Anime / 2022
   Kaynak: anilist
   Harici kimlikler: Anime:mal:50488
   Ham kimlik alanları: MAL ID=50488 (MAL), AniList kayıt ID=495060944, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=5
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 2:
   Başlık: Garden: Takamine-ke no Nirinka - The Animation
   Japonca başlık: Garden ~高嶺家の二輪花~ THE ANIMATION
   Tür/yıl: Anime / 2022
   Kaynak: mal
   Harici kimlikler: Anime:mal:50488
   Ham kimlik alanları: MAL ID=50488 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=5
   Tarihler: başlangıç=2026-10-07, bitiş=2026-10-07; favori=false
   
   Kayıt 3:
   Başlık: Garden: Takamine-ke no Nirinka
   Japonca başlık: Garden ～高嶺家の二輪花～ The Animation
   Tür/yıl: Anime / 2022
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:46024
   Ham kimlik alanları: MAL ID=300046024 (dahili Kitsu kimliği, MAL değil: Kitsu #46024), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=5
   Tarihler: başlangıç=2026-10-07, bitiş=2026-10-07; favori=false
   
   Kayıt 4:
   Başlık: Garden: Takamine-ke no Nirinka - The Animation
   Tür/yıl: Anime / 2022
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:50488, Anime:shikimori:50488
   Ham kimlik alanları: MAL ID=50488 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=5
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 5:
   Başlık: Garden ～高嶺家の二輪花～ THE ANIMATION
   Japonca başlık: Garden ～高嶺家の二輪花～ THE ANIMATION
   Tür/yıl: Anime / 2022
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:360050
   Ham kimlik alanları: MAL ID=500360050 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=5
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Eşitleme için birleştirilen değerler:
   Başlık: Garden ～高嶺家の二輪花～ THE ANIMATION
   İngilizce başlık: Garden -The Two Flowers of the Takamine Family- THE ANIMATION
   Japonca başlık: Garden ～高嶺家の二輪花～ The Animation
   Tür/yıl: Anime / 2022
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:50488
   Ham kimlik alanları: MAL ID=50488 (MAL), AniList kayıt ID=495060944, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=5
   Tarihler: başlangıç=2026-10-07, bitiş=2026-10-07; favori=false
   
   Kimlik güvencesi: Güvenilir (MAL/Shikimori kaydının kendi kimliği)
```

## Sorun 69 · UYARI · Eşleştirme

- Rapor satırları: `4809–4876`
- Zaman: `2026-10-24 15:40:06.708 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `2346`

```text
69. [2026-10-24 15:40:06.708 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Komi-san wa, Komyushou desu. 2
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: Komi-san wa, Komyushou desu. 2
   İngilizce başlık: Komi Can't Communicate Part 2
   Japonca başlık: 古見さんは、コミュ症です。2
   Tür/yıl: Anime / 2022
   Kaynak: anilist
   Harici kimlikler: Anime:mal:50631
   Ham kimlik alanları: MAL ID=50631 (MAL), AniList kayıt ID=495061055, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Komi-san wa, Comyushou desu. 2nd Season
   İngilizce başlık: Komi Can't Communicate Season 2
   Japonca başlık: 古見さんは、コミュ症です。 2
   Tür/yıl: Anime / 2022
   Kaynak: mal
   Harici kimlikler: Anime:mal:50631
   Ham kimlik alanları: MAL ID=50631 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Komi-san wa, Komyushou Desu.
   Tür/yıl: Anime / 2022
   Kaynak: simkl
   Harici kimlikler: Anime:mal:50631, Anime:simkl:1812124
   Ham kimlik alanları: MAL ID=50631 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=1812124, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Komi-san wa, Komyushou desu. 2
   İngilizce başlık: Komi Can't Communicate Season 2
   Japonca başlık: 古見さんは, コミュ症です. 2
   Tür/yıl: Anime / 2022
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:45641
   Ham kimlik alanları: MAL ID=300045641 (dahili Kitsu kimliği, MAL değil: Kitsu #45641), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Komi-san wa, Comyushou desu. 2nd Season
   Tür/yıl: Anime / 2022
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:50631, Anime:shikimori:50631
   Ham kimlik alanları: MAL ID=50631 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: 古見さんは、コミュ症です。2期
   Japonca başlık: 古見さんは、コミュ症です。2期
   Tür/yıl: Anime / 2022
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:363242
   Ham kimlik alanları: MAL ID=500363242 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 70 · HATA · AniList

- Rapor satırları: `4878–4955`
- Zaman: `2026-10-24 15:40:07.119 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `update_error` / `identity_unverified`
- Tüm olay no: `2348`

```text
70. [2026-10-24 15:40:07.119 GMT+03:00] [HATA] [AniList] [AniList] ! Güncellenemedi: けものっ娘通信〜The Animation〜
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Hata: java.lang.IllegalStateException: AniList liste kaydının bu medya ile eşleştiği doğrulanamadı: けものっ娘通信〜The Animation〜
     at com.kitsugi.animelist.data.auth.AniListSyncManager.updateAniListEntry(?:718)
     at com.kitsugi.animelist.data.auth.AniListSyncManager.updateAniListEntry$default(?:40)
     at c7.r1.invokeSuspend(?:26941)
     at kotlin.coroutines.jvm.internal.BaseContinuationImpl.resumeWith(?:11)
     at kotlinx.coroutines.DispatchedTask.run(?:128)
     at kotlinx.coroutines.internal.LimitedDispatcher$Worker.run(?:3)
   
   Kaynak platform kayıtları (5):
   Kayıt 1:
   Başlık: Kemonokko Tsuushin: The Animation - Ushi Musume Bell
   Japonca başlık: けものっ娘通信〜The Animation〜 牛娘ベル
   Tür/yıl: Anime / 2021
   Kaynak: anilist
   Harici kimlikler: Anime:mal:50622
   Ham kimlik alanları: MAL ID=50622 (MAL), AniList kayıt ID=495061026, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=7
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 2:
   Başlık: Kemonokko Tsuushin: The Animation
   Japonca başlık: けものっ娘通信 〜The Animation〜
   Tür/yıl: Anime / 2021
   Kaynak: mal
   Harici kimlikler: Anime:mal:50622
   Ham kimlik alanları: MAL ID=50622 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: İzleniyor, bölüm=1/?, cilt=0, puan=7
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 3:
   Başlık: Kemonokko Tsuushin: The Animation - Ushi Musume Bell
   Japonca başlık: けものっ娘通信 〜The Animation〜 牛娘ベル
   Tür/yıl: Anime / 2021
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:45817
   Ham kimlik alanları: MAL ID=300045817 (dahili Kitsu kimliği, MAL değil: Kitsu #45817), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=7
   Tarihler: başlangıç=2026-10-07, bitiş=2026-10-07; favori=false
   
   Kayıt 4:
   Başlık: Kemonokko Tsuushin: The Animation
   Tür/yıl: Anime / 2021
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:50622, Anime:shikimori:50622
   Ham kimlik alanları: MAL ID=50622 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/?, cilt=0, puan=7
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 5:
   Başlık: けものっ娘通信〜The Animation〜
   Japonca başlık: けものっ娘通信〜The Animation〜
   Tür/yıl: Anime / 2021
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:363866
   Ham kimlik alanları: MAL ID=500363866 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/4, cilt=0, puan=7
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Eşitleme için birleştirilen değerler:
   Başlık: けものっ娘通信〜The Animation〜
   Japonca başlık: けものっ娘通信〜The Animation〜 牛娘ベル
   Tür/yıl: Anime / 2021
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:50622
   Ham kimlik alanları: MAL ID=50622 (MAL), AniList kayıt ID=495061026, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/4, cilt=0, puan=7
   Tarihler: başlangıç=2026-10-07, bitiş=2026-10-07; favori=false
   
   Kimlik güvencesi: Güvenilir (MAL/Shikimori kaydının kendi kimliği)
```

## Sorun 71 · UYARI · Eşleştirme

- Rapor satırları: `4957–5024`
- Zaman: `2026-10-24 15:45:23.714 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `2359`

```text
71. [2026-10-24 15:45:23.714 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Jujutsu Kaisen 2nd Season
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: Jujutsu Kaisen 2nd Season
   İngilizce başlık: JUJUTSU KAISEN Season 2
   Japonca başlık: 呪術廻戦 第2期
   Tür/yıl: Anime / 2023
   Kaynak: anilist
   Harici kimlikler: Anime:mal:51009
   Ham kimlik alanları: MAL ID=51009 (MAL), AniList kayıt ID=550730489, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=23/23, cilt=0, puan=6
   Tarihler: başlangıç=2026-10-04, bitiş=2026-10-04; favori=false
   
   
   Başlık: Jujutsu Kaisen 2nd Season
   İngilizce başlık: Jujutsu Kaisen Season 2
   Japonca başlık: 呪術廻戦 懐玉・玉折／渋谷事変
   Tür/yıl: Anime / 2023
   Kaynak: mal
   Harici kimlikler: Anime:mal:51009
   Ham kimlik alanları: MAL ID=51009 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=23/23, cilt=0, puan=6
   Tarihler: başlangıç=2026-10-04, bitiş=2026-10-04; favori=false
   
   
   Başlık: Jujutsu Kaisen
   Tür/yıl: Anime / 2023
   Kaynak: simkl
   Harici kimlikler: Anime:mal:51009, Anime:simkl:1847578
   Ham kimlik alanları: MAL ID=51009 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=1847578, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=23/23, cilt=0, puan=6
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Jujutsu Kaisen Season 2
   İngilizce başlık: Jujutsu Kaisen Season 2
   Japonca başlık: 呪術廻戦 第2期
   Tür/yıl: Anime / 2023
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:45857
   Ham kimlik alanları: MAL ID=300045857 (dahili Kitsu kimliği, MAL değil: Kitsu #45857), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=23/23, cilt=0, puan=6
   Tarihler: başlangıç=2026-04-15, bitiş=2026-04-15; favori=false
   
   
   Başlık: Jujutsu Kaisen 2nd Season
   Tür/yıl: Anime / 2023
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:51009, Anime:shikimori:51009
   Ham kimlik alanları: MAL ID=51009 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=23/23, cilt=0, puan=6
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: 呪術廻戦 懐玉・玉折／渋谷事変
   Japonca başlık: 呪術廻戦 懐玉・玉折／渋谷事変
   Tür/yıl: Anime / 2023
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:369304
   Ham kimlik alanları: MAL ID=500369304 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=23/23, cilt=0, puan=6
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 72 · UYARI · Eşleştirme

- Rapor satırları: `5026–5091`
- Zaman: `2026-10-24 15:45:23.725 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `2366`

```text
72. [2026-10-24 15:45:23.725 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Uma Musume: Pretty Derby - 1st Anniversary Special Animation
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: Uma Musume: Pretty Derby - 1st Anniversary Special Animation
   İngilizce başlık: Umamusume: Pretty Derby - 1st Anniversary Special Animation
   Japonca başlık: ウマ娘 プリティーダービー 1st Anniversary Special Animation
   Tür/yıl: Anime / 2022
   Kaynak: anilist
   Harici kimlikler: Anime:mal:51225
   Ham kimlik alanları: MAL ID=51225 (MAL), AniList kayıt ID=495061323, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Uma Musume: Pretty Derby - 1st Anniversary Special Animation
   Japonca başlık: ウマ娘 プリティーダービー 1st Anniversary Special Animation
   Tür/yıl: Anime / 2022
   Kaynak: mal
   Harici kimlikler: Anime:mal:51225
   Ham kimlik alanları: MAL ID=51225 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Uma Musume: Pretty Derby
   Tür/yıl: Anime / 2022
   Kaynak: simkl
   Harici kimlikler: Anime:mal:51225, Anime:simkl:1855716
   Ham kimlik alanları: MAL ID=51225 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=1855716, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Uma Musume: Pretty Derby - 1st Anniversary Special Animation
   Japonca başlık: ウマ娘 プリティーダービー 1st Anniversary Special Animation
   Tür/yıl: Anime / 2022
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:49189
   Ham kimlik alanları: MAL ID=300049189 (dahili Kitsu kimliği, MAL değil: Kitsu #49189), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Uma Musume: Pretty Derby - 1st Anniversary Special Animation
   Tür/yıl: Anime / 2022
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:51225, Anime:shikimori:51225
   Ham kimlik alanları: MAL ID=51225 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: ウマ娘 プリティーダービー「ぱか☆アゲ↑ミックス」
   Japonca başlık: ウマ娘 プリティーダービー「ぱか☆アゲ↑ミックス」
   Tür/yıl: Anime / 2022
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:406283
   Ham kimlik alanları: MAL ID=500406283 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/10, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 73 · HATA · Kitsu

- Rapor satırları: `5093–5218`
- Zaman: `2026-10-24 15:56:29.313 GMT+03:00`
- Kod: `KTS-COM-1003`
- İşlem / neden: `update_error` / `timeout`
- Tüm olay no: `2376`

```text
73. [2026-10-24 15:56:29.313 GMT+03:00] [HATA] [Kitsu] [Kitsu] ! Güncellenemedi: 無職転生Ⅱ ～異世界行ったら本気だす～ (Hata: java.io.InterruptedIOException: timeout
  at okhttp3.internal.connection.RealCall.timeoutExit(?:18)
  at okhttp3.internal.connection.RealCall.callDone(?:147)
  at okhttp3.internal.connection.RealCall.noMoreExchanges$okhttp(?:33)
  at okhttp3.internal.connection.RealCall.getResponseWithInterceptorChain$okhttp(?:140)
  at okhttp3.internal.connection.RealCall.execute(?:27)
  at com.kitsugi.animelist.data.auth.KitsuApiClient.executeWithHostFallback(?:8)
Neden 1: java.io.IOException: Canceled
  at o6.m.intercept(?:388)
  at okhttp3.internal.http.RealInterceptorChain.proceed(?:149)
  at okhttp3.internal.connection.RealCall.getResponseWithInterceptorChain$okhttp(?:111)
  at okhttp3.internal.connection.RealCall.execute(?:27)
  at com.kitsugi.animelist.data.auth.KitsuApiClient.executeWithHostFallback(?:8)
  at com.kitsugi.animelist.data.auth.KitsuApiClient.access$executeWithHostFallback(?:0)
Neden 2: java.io.IOException: Canceled
  at okhttp3.internal.connection.FastFallbackExchangeFinder.find(?:182)
  at okhttp3.internal.connection.RealCall.initExchange$okhttp(?:34)
  at okhttp3.internal.connection.ConnectInterceptor.intercept(?:12)
  at okhttp3.internal.http.RealInterceptorChain.proceed(?:149)
  at okhttp3.internal.cache.CacheInterceptor.intercept(?:185)
  at okhttp3.internal.http.RealInterceptorChain.proceed(?:149)
)
   Kod: KTS-COM-1003
   | KTS-COM-1003 · WARNING · COM
   | TR — Zaman aşımı
   | Neden: Sunucu tanımlı süre içinde yanıt vermedi. Sunucu yoğun, bağlantı çok yavaş ya da istek arka planda askıya alınmış olabilir.
   | Çözüm: Birkaç dakika sonra tekrar deneyin; mümkünse Wi-Fi bağlantısı kullanın.
   | EN — Request timed out
   | Why: The server did not respond within the configured window. The server may be overloaded, the connection very slow, or the request was suspended in the background.
   | Fix: Try again in a few minutes; use a Wi-Fi connection where possible.
   Kaynak platform kayıtları (6):
   Kayıt 1:
   Başlık: Mushoku Tensei II: Isekai Ittara Honki Dasu
   İngilizce başlık: Mushoku Tensei: Jobless Reincarnation Season 2
   Japonca başlık: 無職転生Ⅱ ～異世界行ったら本気だす～
   Tür/yıl: Anime / 2023
   Kaynak: anilist
   Harici kimlikler: Anime:mal:51179
   Ham kimlik alanları: MAL ID=51179 (MAL), AniList kayıt ID=495061128, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=13/13, cilt=0, puan=10
   Tarihler: başlangıç=2025-02-21, bitiş=2025-02-21; favori=true
   
   Kayıt 2:
   Başlık: Mushoku Tensei II: Isekai Ittara Honki Dasu
   İngilizce başlık: Mushoku Tensei: Jobless Reincarnation Season 2
   Japonca başlık: 無職転生 II ～異世界行ったら本気だす～
   Tür/yıl: Anime / 2023
   Kaynak: mal
   Harici kimlikler: Anime:mal:51179
   Ham kimlik alanları: MAL ID=51179 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=10
   Tarihler: başlangıç=2025-02-21, bitiş=2025-02-21; favori=false
   
   Kayıt 3:
   Başlık: Mushoku Tensei II: Isekai Ittara Honki Dasu
   Tür/yıl: Anime / 2023
   Kaynak: simkl
   Harici kimlikler: Anime:mal:51179, Anime:simkl:1863030
   Ham kimlik alanları: MAL ID=51179 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=1863030, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=10
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 4:
   Başlık: Mushoku Tensei: Isekai Ittara Honki Dasu Season 2
   İngilizce başlık: Mushoku Tensei: Jobless Reincarnation Season 2
   Japonca başlık: 無職転生 ～異世界行ったら本気だす～ 第2期
   Tür/yıl: Anime / 2023
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:45950
   Ham kimlik alanları: MAL ID=300045950 (dahili Kitsu kimliği, MAL değil: Kitsu #45950), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=10
   Tarihler: başlangıç=2023-01-19, bitiş=2026-07-20; favori=false
   
   Kayıt 5:
   Başlık: Mushoku Tensei II: Isekai Ittara Honki Dasu
   Tür/yıl: Anime / 2023
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:51179, Anime:shikimori:51179
   Ham kimlik alanları: MAL ID=51179 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=10
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 6:
   Başlık: 無職転生Ⅱ ～異世界行ったら本気だす～
   Japonca başlık: 無職転生Ⅱ ～異世界行ったら本気だす～
   Tür/yıl: Anime / 2023
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:373247
   Ham kimlik alanları: MAL ID=500373247 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=13/13, cilt=0, puan=10
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Eşitleme için birleştirilen değerler:
   Başlık: 無職転生Ⅱ ～異世界行ったら本気だす～
   İngilizce başlık: Mushoku Tensei: Jobless Reincarnation Season 2
   Japonca başlık: 無職転生Ⅱ ～異世界行ったら本気だす～
   Tür/yıl: Anime / 2023
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:51179, Anime:simkl:1863030
   Ham kimlik alanları: MAL ID=51179 (MAL), AniList kayıt ID=495061128, MAL liste ID=yok, Simkl ID=1863030, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=13/13, cilt=0, puan=10
   Tarihler: başlangıç=2023-01-19, bitiş=2026-07-20; favori=true
   
   Kimlik güvencesi: Gerek yok (tüm hedef platformlarda kayıt zaten var)
   
   Hata: java.io.InterruptedIOException: timeout
     at okhttp3.internal.connection.RealCall.timeoutExit(?:18)
     at okhttp3.internal.connection.RealCall.callDone(?:147)
     at okhttp3.internal.connection.RealCall.noMoreExchanges$okhttp(?:33)
     at okhttp3.internal.connection.RealCall.getResponseWithInterceptorChain$okhttp(?:140)
     at okhttp3.internal.connection.RealCall.execute(?:27)
     at com.kitsugi.animelist.data.auth.KitsuApiClient.executeWithHostFallback(?:8)
   Neden 1: java.io.IOException: Canceled
     at o6.m.intercept(?:388)
     at okhttp3.internal.http.RealInterceptorChain.proceed(?:149)
     at okhttp3.internal.connection.RealCall.getResponseWithInterceptorChain$okhttp(?:111)
     at okhttp3.internal.connection.RealCall.execute(?:27)
     at com.kitsugi.animelist.data.auth.KitsuApiClient.executeWithHostFallback(?:8)
     at com.kitsugi.animelist.data.auth.KitsuApiClient.access$executeWithHostFallback(?:0)
   Neden 2: java.io.IOException: Canceled
     at okhttp3.internal.connection.FastFallbackExchangeFinder.find(?:182)
     at okhttp3.internal.connection.RealCall.initExchange$okhttp(?:34)
     at okhttp3.internal.connection.ConnectInterceptor.intercept(?:12)
     at okhttp3.internal.http.RealInterceptorChain.proceed(?:149)
     at okhttp3.internal.cache.CacheInterceptor.intercept(?:185)
     at okhttp3.internal.http.RealInterceptorChain.proceed(?:149)
```

## Sorun 74 · HATA · Bangumi

- Rapor satırları: `5220–5285`
- Zaman: `2026-10-24 16:02:15.298 GMT+03:00`
- Kod: `KTS-COM-1003`
- İşlem / neden: `update_error` / `timeout`
- Tüm olay no: `2415`

```text
74. [2026-10-24 16:02:15.298 GMT+03:00] [HATA] [Bangumi] [Bangumi] ! Hata: Yuusha, Yamemasu: Kenshuu Ryokou wa Mokuteki wo Miushinau na (Bangumi güncellenemedi (Yuusha, Yamemasu: Kenshuu Ryokou wa Mokuteki wo Miushinau na): Bangumi'ye ulaşılamadı: timeout)
   Kod: KTS-COM-1003
   | KTS-COM-1003 · WARNING · COM
   | TR — Zaman aşımı
   | Neden: Sunucu tanımlı süre içinde yanıt vermedi. Sunucu yoğun, bağlantı çok yavaş ya da istek arka planda askıya alınmış olabilir.
   | Çözüm: Birkaç dakika sonra tekrar deneyin; mümkünse Wi-Fi bağlantısı kullanın.
   | EN — Request timed out
   | Why: The server did not respond within the configured window. The server may be overloaded, the connection very slow, or the request was suspended in the background.
   | Fix: Try again in a few minutes; use a Wi-Fi connection where possible.
   Kaynak platform kayıtları (4):
   Kayıt 1:
   Başlık: Yuusha, Yamemasu: Kenshuu Ryokou wa Mokuteki wo Miushinau na
   İngilizce başlık: I'm Quitting Heroing: Remember, the Work Trip is First and Foremost a Learning Opportunity
   Japonca başlık: 勇者、辞めます 研修旅行は目的を見失うな
   Tür/yıl: Anime / 2022
   Kaynak: anilist
   Harici kimlikler: Anime:mal:51562
   Ham kimlik alanları: MAL ID=51562 (MAL), AniList kayıt ID=503153096, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=2/2, cilt=0, puan=7
   Tarihler: başlangıç=2025-09-09, bitiş=2025-09-09; favori=false
   
   Kayıt 2:
   Başlık: Yuusha, Yamemasu: Kenshuu Ryokou wa Mokuteki wo Miushinau na
   İngilizce başlık: I'm Quitting Heroing: Remember, the Work Trip is First and Foremost a Learning Opportunity
   Japonca başlık: 勇者、辞めます「研修旅行は目的を見失うな」
   Tür/yıl: Anime / 2022
   Kaynak: mal
   Harici kimlikler: Anime:mal:51562
   Ham kimlik alanları: MAL ID=51562 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=2/2, cilt=0, puan=7
   Tarihler: başlangıç=2025-09-09, bitiş=2025-09-09; favori=false
   
   Kayıt 3:
   Başlık: Yuusha, Yamemasu: Kenshuu Ryokou wa Mokuteki wo Miushinau na
   İngilizce başlık: I'm Quitting Heroing: Remember, the Work Trip is First and Foremost a Learning Opportunity
   Japonca başlık: 勇者、辞めます「研修旅行は目的を見失うな」
   Tür/yıl: Anime / 2022
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:46219
   Ham kimlik alanları: MAL ID=300046219 (dahili Kitsu kimliği, MAL değil: Kitsu #46219), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=2/2, cilt=0, puan=7
   Tarihler: başlangıç=2026-10-04, bitiş=2026-10-04; favori=false
   
   Kayıt 4:
   Başlık: Yuusha, Yamemasu: Kenshuu Ryokou wa Mokuteki wo Miushinau na
   Tür/yıl: Anime / 2022
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:51562, Anime:shikimori:51562
   Ham kimlik alanları: MAL ID=51562 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=2/2, cilt=0, puan=7
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Eşitleme için birleştirilen değerler:
   Başlık: Yuusha, Yamemasu: Kenshuu Ryokou wa Mokuteki wo Miushinau na
   İngilizce başlık: I'm Quitting Heroing: Remember, the Work Trip is First and Foremost a Learning Opportunity
   Japonca başlık: 勇者、辞めます 研修旅行は目的を見失うな
   Tür/yıl: Anime / 2022
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:51562
   Ham kimlik alanları: MAL ID=51562 (MAL), AniList kayıt ID=503153096, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=2/2, cilt=0, puan=7
   Tarihler: başlangıç=2025-09-09, bitiş=2026-10-04; favori=false
   
   Kimlik güvencesi: Güvenilir (MAL/Shikimori kaydının kendi kimliği)
   
   Bangumi güncellenemedi (Yuusha, Yamemasu: Kenshuu Ryokou wa Mokuteki wo Miushinau na): Bangumi'ye ulaşılamadı: timeout
```

## Sorun 75 · HATA · Kitsu

- Rapor satırları: `5286–5452`
- Zaman: `2026-10-24 16:06:51.789 GMT+03:00`
- Kod: `KTS-COM-1002`
- İşlem / neden: `update_error` / `timeout`
- Tüm olay no: `2418`

```text
75. [2026-10-24 16:06:51.789 GMT+03:00] [HATA] [Kitsu] [Kitsu] ! Güncellenemedi: デート・ア・ライブV (Hata: java.io.InterruptedIOException: timeout
  at okhttp3.internal.connection.RealCall.timeoutExit(?:18)
  at okhttp3.internal.connection.RealCall.callDone(?:147)
  at okhttp3.internal.connection.RealCall.noMoreExchanges$okhttp(?:33)
  at okhttp3.internal.connection.RealCall.getResponseWithInterceptorChain$okhttp(?:140)
  at okhttp3.internal.connection.RealCall.execute(?:27)
  at com.kitsugi.animelist.data.auth.KitsuApiClient.executeWithHostFallback(?:8)
Neden 1: java.io.IOException: Canceled
  at o6.m.intercept(?:388)
  at okhttp3.internal.http.RealInterceptorChain.proceed(?:149)
  at okhttp3.internal.connection.RealCall.getResponseWithInterceptorChain$okhttp(?:111)
  at okhttp3.internal.connection.RealCall.execute(?:27)
  at com.kitsugi.animelist.data.auth.KitsuApiClient.executeWithHostFallback(?:8)
  at com.kitsugi.animelist.data.auth.KitsuApiClient.access$executeWithHostFallback(?:0)
Neden 2: java.net.UnknownHostException: kitsu.app
  at okhttp3.dnsoverhttps.DnsOverHttps.throwBestFailure(?:19)
  at okhttp3.dnsoverhttps.DnsOverHttps.lookupHttps(?:62)
  at okhttp3.dnsoverhttps.DnsOverHttps.lookup(?:49)
  at o6.h.lookup(?:13)
  at okhttp3.internal.connection.RouteSelector.resetNextInetSocketAddress(?:148)
  at okhttp3.internal.connection.RouteSelector.nextProxy(?:20)
Neden 3: java.net.ConnectException: Failed to connect to /2606:4700:4700::1111:443
  at okhttp3.internal.connection.ConnectPlan.connectSocket(?:145)
  at okhttp3.internal.connection.ConnectPlan.connectTcp(?:56)
  at okhttp3.internal.connection.FastFallbackExchangeFinder$launchTcpConnect$1.runOnce(?:2)
  at okhttp3.internal.concurrent.TaskRunner$runnable$1.run(?:79)
  at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1137)
  at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:637)
Neden 4: java.net.ConnectException: failed to connect to /2606:4700:4700::1111 (port 443) from /:: (port 0) after 10000ms: connect failed: ENETUNREACH (Network is unreachable)
  at libcore.io.IoBridge.connect(IoBridge.java:187)
  at java.net.PlainSocketImpl.socketConnect(PlainSocketImpl.java:142)
  at java.net.AbstractPlainSocketImpl.doConnect(AbstractPlainSocketImpl.java:390)
  at java.net.AbstractPlainSocketImpl.connectToAddress(AbstractPlainSocketImpl.java:230)
  at java.net.AbstractPlainSocketImpl.connect(AbstractPlainSocketImpl.java:212)
  at java.net.SocksSocketImpl.connect(SocksSocketImpl.java:436)
Neden 5: android.system.ErrnoException: connect failed: ENETUNREACH (Network is unreachable)
  at libcore.io.Linux.connect(Linux.java:-2)
  at libcore.io.ForwardingOs.connect(ForwardingOs.java:201)
  at libcore.io.BlockGuardOs.connect(BlockGuardOs.java:158)
  at libcore.io.ForwardingOs.connect(ForwardingOs.java:201)
  at libcore.io.IoBridge.connectErrno(IoBridge.java:218)
  at libcore.io.IoBridge.connect(IoBridge.java:179)
)
   Kod: KTS-COM-1002
   | KTS-COM-1002 · ERROR · COM
   | TR — Alan adı çözümlenemedi (DNS)
   | Neden: (unknownhost) DNS sunucusu alan adını IP adresine çeviremedi. Sağlayıcı DNS'i engelliyor, alan adı taşınmış ya da liste kaynağı adresini değiştirmiş olabilir.
   | Çözüm: Ayarlar > Sistem bölümünden DNS-over-HTTPS sağlayıcısını değiştirin veya VPN ile deneyin.
   | EN — Domain name could not be resolved (DNS)
   | Why: (unknownhost) The DNS server could not translate the domain into an IP address. Your ISP may be blocking it, the domain may have moved, or the platform changed its address.
   | Fix: Change the DNS-over-HTTPS provider under Settings > System, or try again over a VPN.
   Kaynak platform kayıtları (6):
   Kayıt 1:
   Başlık: Date A Live V
   İngilizce başlık: Date A Live V
   Japonca başlık: デート・ア・ライブV
   Tür/yıl: Anime / 2024
   Kaynak: anilist
   Harici kimlikler: Anime:mal:52196
   Ham kimlik alanları: MAL ID=52196 (MAL), AniList kayıt ID=495060894, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=10
   Tarihler: başlangıç=2023-01-15, bitiş=2024-08-23; favori=true
   
   Kayıt 2:
   Başlık: Date A Live V
   İngilizce başlık: Date A Live V
   Japonca başlık: デート・ア・ライブⅤ
   Tür/yıl: Anime / 2024
   Kaynak: mal
   Harici kimlikler: Anime:mal:52196
   Ham kimlik alanları: MAL ID=52196 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=10
   Tarihler: başlangıç=2023-01-15, bitiş=2024-08-23; favori=false
   
   Kayıt 3:
   Başlık: Date a Live V
   Tür/yıl: Anime / 2024
   Kaynak: simkl
   Harici kimlikler: Anime:mal:52196, Anime:simkl:1937760
   Ham kimlik alanları: MAL ID=52196 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=1937760, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=10
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 4:
   Başlık: Date A Live V
   Japonca başlık: デート・ア・ライブ IV
   Tür/yıl: Anime / 2024
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:46207
   Ham kimlik alanları: MAL ID=300046207 (dahili Kitsu kimliği, MAL değil: Kitsu #46207), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=10
   Tarihler: başlangıç=2025-02-20, bitiş=2025-02-20; favori=false
   
   Kayıt 5:
   Başlık: Date A Live V
   Tür/yıl: Anime / 2024
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:52196, Anime:shikimori:52196
   Ham kimlik alanları: MAL ID=52196 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=10
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 6:
   Başlık: デート・ア・ライブV
   Japonca başlık: デート・ア・ライブV
   Tür/yıl: Anime / 2024
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:389466
   Ham kimlik alanları: MAL ID=500389466 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=10
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Eşitleme için birleştirilen değerler:
   Başlık: デート・ア・ライブV
   İngilizce başlık: Date A Live V
   Japonca başlık: デート・ア・ライブV
   Tür/yıl: Anime / 2024
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:52196, Anime:simkl:1937760
   Ham kimlik alanları: MAL ID=52196 (MAL), AniList kayıt ID=495060894, MAL liste ID=yok, Simkl ID=1937760, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=10
   Tarihler: başlangıç=2023-01-15, bitiş=2025-02-20; favori=true
   
   Kimlik güvencesi: Gerek yok (tüm hedef platformlarda kayıt zaten var)
   
   Hata: java.io.InterruptedIOException: timeout
     at okhttp3.internal.connection.RealCall.timeoutExit(?:18)
     at okhttp3.internal.connection.RealCall.callDone(?:147)
     at okhttp3.internal.connection.RealCall.noMoreExchanges$okhttp(?:33)
     at okhttp3.internal.connection.RealCall.getResponseWithInterceptorChain$okhttp(?:140)
     at okhttp3.internal.connection.RealCall.execute(?:27)
     at com.kitsugi.animelist.data.auth.KitsuApiClient.executeWithHostFallback(?:8)
   Neden 1: java.io.IOException: Canceled
     at o6.m.intercept(?:388)
     at okhttp3.internal.http.RealInterceptorChain.proceed(?:149)
     at okhttp3.internal.connection.RealCall.getResponseWithInterceptorChain$okhttp(?:111)
     at okhttp3.internal.connection.RealCall.execute(?:27)
     at com.kitsugi.animelist.data.auth.KitsuApiClient.executeWithHostFallback(?:8)
     at com.kitsugi.animelist.data.auth.KitsuApiClient.access$executeWithHostFallback(?:0)
   Neden 2: java.net.UnknownHostException: kitsu.app
     at okhttp3.dnsoverhttps.DnsOverHttps.throwBestFailure(?:19)
     at okhttp3.dnsoverhttps.DnsOverHttps.lookupHttps(?:62)
     at okhttp3.dnsoverhttps.DnsOverHttps.lookup(?:49)
     at o6.h.lookup(?:13)
     at okhttp3.internal.connection.RouteSelector.resetNextInetSocketAddress(?:148)
     at okhttp3.internal.connection.RouteSelector.nextProxy(?:20)
   Neden 3: java.net.ConnectException: Failed to connect to /2606:4700:4700::1111:443
     at okhttp3.internal.connection.ConnectPlan.connectSocket(?:145)
     at okhttp3.internal.connection.ConnectPlan.connectTcp(?:56)
     at okhttp3.internal.connection.FastFallbackExchangeFinder$launchTcpConnect$1.runOnce(?:2)
     at okhttp3.internal.concurrent.TaskRunner$runnable$1.run(?:79)
     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1137)
     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:637)
   Neden 4: java.net.ConnectException: failed to connect to /2606:4700:4700::1111 (port 443) from /:: (port 0) after 10000ms: connect failed: ENETUNREACH (Network is unreachable)
     at libcore.io.IoBridge.connect(IoBridge.java:187)
     at java.net.PlainSocketImpl.socketConnect(PlainSocketImpl.java:142)
     at java.net.AbstractPlainSocketImpl.doConnect(AbstractPlainSocketImpl.java:390)
     at java.net.AbstractPlainSocketImpl.connectToAddress(AbstractPlainSocketImpl.java:230)
     at java.net.AbstractPlainSocketImpl.connect(AbstractPlainSocketImpl.java:212)
     at java.net.SocksSocketImpl.connect(SocksSocketImpl.java:436)
   Neden 5: android.system.ErrnoException: connect failed: ENETUNREACH (Network is unreachable)
     at libcore.io.Linux.connect(Linux.java:-2)
     at libcore.io.ForwardingOs.connect(ForwardingOs.java:201)
     at libcore.io.BlockGuardOs.connect(BlockGuardOs.java:158)
     at libcore.io.ForwardingOs.connect(ForwardingOs.java:201)
     at libcore.io.IoBridge.connectErrno(IoBridge.java:218)
     at libcore.io.IoBridge.connect(IoBridge.java:179)
```

## Sorun 76 · HATA · Bangumi

- Rapor satırları: `5454–5538`
- Zaman: `2026-10-24 16:17:57.116 GMT+03:00`
- Kod: `KTS-COM-1003`
- İşlem / neden: `update_error` / `timeout`
- Tüm olay no: `2428`

```text
76. [2026-10-24 16:17:57.116 GMT+03:00] [HATA] [Bangumi] [Bangumi] ! Güncellenemedi: 俺だけレベルアップな件 (Bangumi bölüm ilerlemesi yazılamadı (俺だけレベルアップな件): Bangumi'ye ulaşılamadı: timeout)
   Kod: KTS-COM-1003
   | KTS-COM-1003 · WARNING · COM
   | TR — Zaman aşımı
   | Neden: Sunucu tanımlı süre içinde yanıt vermedi. Sunucu yoğun, bağlantı çok yavaş ya da istek arka planda askıya alınmış olabilir.
   | Çözüm: Birkaç dakika sonra tekrar deneyin; mümkünse Wi-Fi bağlantısı kullanın.
   | EN — Request timed out
   | Why: The server did not respond within the configured window. The server may be overloaded, the connection very slow, or the request was suspended in the background.
   | Fix: Try again in a few minutes; use a Wi-Fi connection where possible.
   Kaynak platform kayıtları (6):
   Kayıt 1:
   Başlık: Ore dake Level Up na Ken
   İngilizce başlık: Solo Leveling
   Japonca başlık: 俺だけレベルアップな件
   Tür/yıl: Anime / 2024
   Kaynak: anilist
   Harici kimlikler: Anime:mal:52299
   Ham kimlik alanları: MAL ID=52299 (MAL), AniList kayıt ID=495061163, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=6
   Tarihler: başlangıç=2023-06-17, bitiş=2025-02-21; favori=true
   
   Kayıt 2:
   Başlık: Ore dake Level Up na Ken
   İngilizce başlık: Solo Leveling
   Japonca başlık: 俺だけレベルアップな件
   Tür/yıl: Anime / 2024
   Kaynak: mal
   Harici kimlikler: Anime:mal:52299
   Ham kimlik alanları: MAL ID=52299 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=6
   Tarihler: başlangıç=2023-06-17, bitiş=2025-02-21; favori=false
   
   Kayıt 3:
   Başlık: Ore dake Level Up na Ken
   Tür/yıl: Anime / 2024
   Kaynak: simkl
   Harici kimlikler: Anime:mal:52299, Anime:simkl:1944032, Anime:tmdb:127532
   Ham kimlik alanları: MAL ID=52299 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=1944032, TMDB ID=127532
   Durum/ilerleme: Planlandı, bölüm=12/12, cilt=0, puan=6
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 4:
   Başlık: Ore Dake Level Up na Ken
   İngilizce başlık: Solo Leveling
   Japonca başlık: 俺だけレベルアップな件
   Tür/yıl: Anime / 2024
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:46231
   Ham kimlik alanları: MAL ID=300046231 (dahili Kitsu kimliği, MAL değil: Kitsu #46231), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=6
   Tarihler: başlangıç=2025-02-21, bitiş=2025-02-21; favori=false
   
   Kayıt 5:
   Başlık: Ore dake Level Up na Ken
   Tür/yıl: Anime / 2024
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:52299, Anime:shikimori:52299
   Ham kimlik alanları: MAL ID=52299 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=6
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 6:
   Başlık: 俺だけレベルアップな件
   Japonca başlık: 俺だけレベルアップな件
   Tür/yıl: Anime / 2024
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:390353
   Ham kimlik alanları: MAL ID=500390353 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=12/12, cilt=0, puan=6
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Eşitleme için birleştirilen değerler:
   Başlık: 俺だけレベルアップな件
   İngilizce başlık: Solo Leveling
   Japonca başlık: 俺だけレベルアップな件
   Tür/yıl: Anime / 2024
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:52299, Anime:simkl:1944032, Anime:tmdb:127532
   Ham kimlik alanları: MAL ID=52299 (MAL), AniList kayıt ID=495061163, MAL liste ID=yok, Simkl ID=1944032, TMDB ID=127532
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=6
   Tarihler: başlangıç=2023-06-17, bitiş=2025-02-21; favori=true
   
   Kimlik güvencesi: Gerek yok (tüm hedef platformlarda kayıt zaten var)
   
   Bangumi bölüm ilerlemesi yazılamadı (俺だけレベルアップな件): Bangumi'ye ulaşılamadı: timeout
```

## Sorun 77 · HATA · AniList

- Rapor satırları: `5539–5618`
- Zaman: `2026-10-24 16:21:24.173 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `update_error` / `identity_unverified`
- Tüm olay no: `2438`

```text
77. [2026-10-24 16:21:24.173 GMT+03:00] [HATA] [AniList] [AniList] ! Güncellenemedi: サキュバス喚んだら義母が来た！？
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Hata: java.lang.IllegalStateException: AniList liste kaydının bu medya ile eşleştiği doğrulanamadı: サキュバス喚んだら義母が来た！？
     at com.kitsugi.animelist.data.auth.AniListSyncManager.updateAniListEntry(?:718)
     at com.kitsugi.animelist.data.auth.AniListSyncManager.updateAniListEntry$default(?:40)
     at c7.r1.invokeSuspend(?:26941)
     at kotlin.coroutines.jvm.internal.BaseContinuationImpl.resumeWith(?:11)
     at kotlinx.coroutines.DispatchedTask.run(?:128)
     at kotlinx.coroutines.internal.LimitedDispatcher$Worker.run(?:3)
   
   Kaynak platform kayıtları (5):
   Kayıt 1:
   Başlık: Succubus Yondara Haha ga Kita!?
   Japonca başlık: サキュバス喚んだら義母が来た！？
   Tür/yıl: Anime / 2022
   Kaynak: anilist
   Harici kimlikler: Anime:mal:52617
   Ham kimlik alanları: MAL ID=52617 (MAL), AniList kayıt ID=495061250, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=2/2, cilt=0, puan=7
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 2:
   Başlık: Succubus Yondara Gibo ga Kita!?
   Japonca başlık: サキュバス喚んだら義母が来た!?
   Tür/yıl: Anime / 2022
   Kaynak: mal
   Harici kimlikler: Anime:mal:52617
   Ham kimlik alanları: MAL ID=52617 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=2/2, cilt=0, puan=7
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 3:
   Başlık: Succubus Yondara Gibo ga Kita!?
   İngilizce başlık: I Summoned a Succubus and My Mom Appeared!?
   Japonca başlık: サキュバス喚んだら義母が来た!?
   Tür/yıl: Anime / 2022
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:46736
   Ham kimlik alanları: MAL ID=300046736 (dahili Kitsu kimliği, MAL değil: Kitsu #46736), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=2/2, cilt=0, puan=7
   Tarihler: başlangıç=2026-10-07, bitiş=2026-10-07; favori=false
   
   Kayıt 4:
   Başlık: Succubus Yondara Gibo ga Kita!?
   Tür/yıl: Anime / 2022
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:52617, Anime:shikimori:52617
   Ham kimlik alanları: MAL ID=52617 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=2/2, cilt=0, puan=7
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 5:
   Başlık: サキュバス喚んだら義母が来た！？
   Japonca başlık: サキュバス喚んだら義母が来た！？
   Tür/yıl: Anime / 2022
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:395292
   Ham kimlik alanları: MAL ID=500395292 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=2/2, cilt=0, puan=7
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Eşitleme için birleştirilen değerler:
   Başlık: サキュバス喚んだら義母が来た！？
   İngilizce başlık: I Summoned a Succubus and My Mom Appeared!?
   Japonca başlık: サキュバス喚んだら義母が来た！？
   Tür/yıl: Anime / 2022
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:52617
   Ham kimlik alanları: MAL ID=52617 (MAL), AniList kayıt ID=495061250, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=2/2, cilt=0, puan=7
   Tarihler: başlangıç=2026-10-07, bitiş=2026-10-07; favori=false
   
   Kimlik güvencesi: Güvenilir (MAL/Shikimori kaydının kendi kimliği)
```

## Sorun 78 · HATA · AniList

- Rapor satırları: `5620–5710`
- Zaman: `2026-10-24 16:21:35.212 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `update_error` / `identity_unverified`
- Tüm olay no: `2458`

```text
78. [2026-10-24 16:21:35.212 GMT+03:00] [HATA] [AniList] [AniList] ! Güncellenemedi: 婚約破棄された令嬢を拾った俺が、イケナイことを教え込む
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Hata: java.lang.IllegalStateException: AniList liste kaydının bu medya ile eşleştiği doğrulanamadı: 婚約破棄された令嬢を拾った俺が、イケナイことを教え込む
     at com.kitsugi.animelist.data.auth.AniListSyncManager.updateAniListEntry(?:718)
     at com.kitsugi.animelist.data.auth.AniListSyncManager.updateAniListEntry$default(?:40)
     at c7.r1.invokeSuspend(?:26941)
     at kotlin.coroutines.jvm.internal.BaseContinuationImpl.resumeWith(?:11)
     at kotlinx.coroutines.UndispatchedCoroutine.afterResume(?:30)
     at kotlinx.coroutines.AbstractCoroutine.resumeWith(?:13)
   
   Kaynak platform kayıtları (6):
   Kayıt 1:
   Başlık: Konyaku Haki sareta Reijou wo Hirotta Ore ga, Ikenai Koto wo Oshiekomu
   İngilizce başlık: I'm Giving the Disgraced Noble Lady I Rescued a Crash Course in Naughtiness
   Japonca başlık: 婚約破棄された令嬢を拾った俺が、イケナイことを教え込む
   Tür/yıl: Anime / 2023
   Kaynak: anilist
   Harici kimlikler: Anime:mal:52934
   Ham kimlik alanları: MAL ID=52934 (MAL), AniList kayıt ID=495061063, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 2:
   Başlık: Konyaku Haki sareta Reijou wo Hirotta Ore ga, Ikenai Koto wo Oshiekomu
   İngilizce başlık: I'm Giving the Disgraced Noble Lady I Rescued a Crash Course in Naughtiness
   Japonca başlık: 婚約破棄された令嬢を拾った俺が、イケナイことを教え込む
   Tür/yıl: Anime / 2023
   Kaynak: mal
   Harici kimlikler: Anime:mal:52934
   Ham kimlik alanları: MAL ID=52934 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=2025-03-10, bitiş=yok; favori=false
   
   Kayıt 3:
   Başlık: Kon'yakuhaki Sareta Reijou o Hirotta Ore ga, Ikenai Koto o Oshiekomu
   Tür/yıl: Anime / 2023
   Kaynak: simkl
   Harici kimlikler: Anime:mal:52934, Anime:simkl:1984862, Anime:tmdb:217405
   Ham kimlik alanları: MAL ID=52934 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=1984862, TMDB ID=217405
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 4:
   Başlık: Konyaku Haki sareta Reijou wo Hirotta Ore ga, Ikenai Koto wo Oshiekomu: Oishii Mono wo Tabesasete Oshare wo Sasete, Sekaiichi Shiawase na Shoujo ni Produce!
   İngilizce başlık: I'm Giving the Disgraced Noble Lady I Rescued a Crash Course in Naughtiness
   Japonca başlık: 婚約破棄された令嬢を拾った俺が、イケナイことを教え込む 〜美味しいものを食べさせておしゃれをさせて、世界一幸せな少女にプロデュース!〜
   Tür/yıl: Anime / 2023
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:46434
   Ham kimlik alanları: MAL ID=300046434 (dahili Kitsu kimliği, MAL değil: Kitsu #46434), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=2025-03-10, bitiş=yok; favori=false
   
   Kayıt 5:
   Başlık: Konyaku Haki sareta Reijou wo Hirotta Ore ga, Ikenai Koto wo Oshiekomu
   Tür/yıl: Anime / 2023
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:52934, Anime:shikimori:52934
   Ham kimlik alanları: MAL ID=52934 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 6:
   Başlık: 婚約破棄された令嬢を拾った俺が、イケナイことを教え込む
   Japonca başlık: 婚約破棄された令嬢を拾った俺が、イケナイことを教え込む
   Tür/yıl: Anime / 2023
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:398922
   Ham kimlik alanları: MAL ID=500398922 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Eşitleme için birleştirilen değerler:
   Başlık: 婚約破棄された令嬢を拾った俺が、イケナイことを教え込む
   İngilizce başlık: I'm Giving the Disgraced Noble Lady I Rescued a Crash Course in Naughtiness
   Japonca başlık: 婚約破棄された令嬢を拾った俺が、イケナイことを教え込む
   Tür/yıl: Anime / 2023
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:52934, Anime:simkl:1984862, Anime:tmdb:217405
   Ham kimlik alanları: MAL ID=52934 (MAL), AniList kayıt ID=495061063, MAL liste ID=yok, Simkl ID=1984862, TMDB ID=217405
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=2025-03-10, bitiş=yok; favori=false
   
   Kimlik güvencesi: Gerek yok (tüm hedef platformlarda kayıt zaten var)
```

## Sorun 79 · UYARI · Eşleştirme

- Rapor satırları: `5712–5779`
- Zaman: `2026-10-24 16:21:35.225 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `2469`

```text
79. [2026-10-24 16:21:35.225 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Kanojo, Okarishimasu 3rd Season
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: Kanojo, Okarishimasu 3rd Season
   İngilizce başlık: Rent-a-Girlfriend Season 3
   Japonca başlık: 彼女、お借りします 第3期
   Tür/yıl: Anime / 2023
   Kaynak: anilist
   Harici kimlikler: Anime:mal:53050
   Ham kimlik alanları: MAL ID=53050 (MAL), AniList kayıt ID=495061023, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=8
   Tarihler: başlangıç=2026-10-04, bitiş=2026-10-04; favori=false
   
   
   Başlık: Kanojo, Okarishimasu 3rd Season
   İngilizce başlık: Rent-a-Girlfriend Season 3
   Japonca başlık: 彼女、お借りします
   Tür/yıl: Anime / 2023
   Kaynak: mal
   Harici kimlikler: Anime:mal:53050
   Ham kimlik alanları: MAL ID=53050 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=8
   Tarihler: başlangıç=2026-10-04, bitiş=2026-10-04; favori=false
   
   
   Başlık: Kanojo, Okarishimasu
   Tür/yıl: Anime / 2023
   Kaynak: simkl
   Harici kimlikler: Anime:mal:53050, Anime:simkl:1994640
   Ham kimlik alanları: MAL ID=53050 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=1994640, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=8
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Kanojo, Okarishimasu Season 3
   İngilizce başlık: Rent-a-Girlfriend Season 3
   Japonca başlık: 彼女、お借りします 第3期
   Tür/yıl: Anime / 2023
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:46489
   Ham kimlik alanları: MAL ID=300046489 (dahili Kitsu kimliği, MAL değil: Kitsu #46489), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=8
   Tarihler: başlangıç=2023-03-29, bitiş=2026-10-04; favori=false
   
   
   Başlık: Kanojo, Okarishimasu 3rd Season
   Tür/yıl: Anime / 2023
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:53050, Anime:shikimori:53050
   Ham kimlik alanları: MAL ID=53050 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=8
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: 彼女、お借りします 第3期
   Japonca başlık: 彼女、お借りします 第3期
   Tür/yıl: Anime / 2023
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:401783
   Ham kimlik alanları: MAL ID=500401783 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=10
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 80 · UYARI · Eşleştirme

- Rapor satırları: `5781–5848`
- Zaman: `2026-10-24 16:21:35.226 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `2470`

```text
80. [2026-10-24 16:21:35.226 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Sono Bisque Doll wa Koi wo Suru Season 2
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: Sono Bisque Doll wa Koi wo Suru Season 2
   İngilizce başlık: My Dress-Up Darling Season 2
   Japonca başlık: その着せ替え人形は恋をする Season 2
   Tür/yıl: Anime / 2025
   Kaynak: anilist
   Harici kimlikler: Anime:mal:53065
   Ham kimlik alanları: MAL ID=53065 (MAL), AniList kayıt ID=512899136, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=5
   Tarihler: başlangıç=2026-10-04, bitiş=2026-10-04; favori=false
   
   
   Başlık: Sono Bisque Doll wa Koi wo Suru Season 2
   İngilizce başlık: My Dress-Up Darling Season 2
   Japonca başlık: その着せ替え人形は恋をする Season 2
   Tür/yıl: Anime / 2025
   Kaynak: mal
   Harici kimlikler: Anime:mal:53065
   Ham kimlik alanları: MAL ID=53065 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=5
   Tarihler: başlangıç=2026-10-04, bitiş=2026-10-04; favori=false
   
   
   Başlık: Sono Bisque Doll wa Koi o Suru
   Tür/yıl: Anime / 2025
   Kaynak: simkl
   Harici kimlikler: Anime:mal:53065, Anime:simkl:1995266
   Ham kimlik alanları: MAL ID=53065 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=1995266, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=5
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Sono Bisque Doll wa Koi wo Suru 2nd Season
   İngilizce başlık: My Dress-Up Darling Season 2
   Japonca başlık: その着せ替え人形は恋をする 第2季
   Tür/yıl: Anime / 2025
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:46492
   Ham kimlik alanları: MAL ID=300046492 (dahili Kitsu kimliği, MAL değil: Kitsu #46492), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=5
   Tarihler: başlangıç=2025-10-16, bitiş=2025-10-23; favori=false
   
   
   Başlık: Sono Bisque Doll wa Koi wo Suru Season 2
   Tür/yıl: Anime / 2025
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:53065, Anime:shikimori:53065
   Ham kimlik alanları: MAL ID=53065 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=5
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: その着せ替え人形は恋をする Season 2
   Japonca başlık: その着せ替え人形は恋をする Season 2
   Tür/yıl: Anime / 2025
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:398951
   Ham kimlik alanları: MAL ID=500398951 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=5
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 81 · UYARI · Eşleştirme

- Rapor satırları: `5850–5899`
- Zaman: `2026-10-24 16:21:35.231 GMT+03:00`
- Kod: `—`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `2477`

```text
81. [2026-10-24 16:21:35.231 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Hataraku Maou-sama!! 2nd Season
   Başlık: Hataraku Maou-sama!! 2nd Season
   İngilizce başlık: The Devil is a Part-Timer! Season 2 Part 2
   Japonca başlık: はたらく魔王さま！！2nd Season
   Tür/yıl: Anime / 2023
   Kaynak: anilist
   Harici kimlikler: Anime:mal:53200
   Ham kimlik alanları: MAL ID=53200 (MAL), AniList kayıt ID=509715762, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Hataraku Maou-sama!! 2nd Season
   İngilizce başlık: The Devil is a Part-Timer! Season 2 Part 2
   Japonca başlık: はたらく魔王さま！！
   Tür/yıl: Anime / 2023
   Kaynak: mal
   Harici kimlikler: Anime:mal:53200
   Ham kimlik alanları: MAL ID=53200 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Hataraku Maou-sama!!
   Tür/yıl: Anime / 2023
   Kaynak: simkl
   Harici kimlikler: Anime:mal:53200, Anime:simkl:2014824
   Ham kimlik alanları: MAL ID=53200 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=2014824, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Hataraku Maou-sama!! 2nd Season
   İngilizce başlık: The Devil is a Part-Timer! Season 2 Part 2
   Japonca başlık: はたらく魔王さま！！2nd Season
   Tür/yıl: Anime / 2023
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:46550
   Ham kimlik alanları: MAL ID=300046550 (dahili Kitsu kimliği, MAL değil: Kitsu #46550), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Hataraku Maou-sama!! 2nd Season
   Tür/yıl: Anime / 2023
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:53200, Anime:shikimori:53200
   Ham kimlik alanları: MAL ID=53200 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 82 · UYARI · Eşleştirme

- Rapor satırları: `5901–5968`
- Zaman: `2026-10-24 16:21:35.233 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `2478`

```text
82. [2026-10-24 16:21:35.233 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Dungeon ni Deai wo Motomeru no wa Machigatteiru Darou ka IV: Shin Shou Yakusai-hen
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: Dungeon ni Deai wo Motomeru no wa Machigatteiru Darou ka IV: Shin Shou Yakusai-hen
   İngilizce başlık: Is It Wrong to Try to Pick Up Girls in a Dungeon? IV Part 2
   Japonca başlık: ダンジョンに出会いを求めるのは間違っているだろうかⅣ 深章 厄災篇
   Tür/yıl: Anime / 2023
   Kaynak: anilist
   Harici kimlikler: Anime:mal:53111
   Ham kimlik alanları: MAL ID=53111 (MAL), AniList kayıt ID=495060904, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=11/11, cilt=0, puan=6
   Tarihler: başlangıç=2026-10-04, bitiş=2026-10-04; favori=false
   
   
   Başlık: Dungeon ni Deai wo Motomeru no wa Machigatteiru Darou ka IV: Shin Shou - Yakusai-hen
   İngilizce başlık: Is It Wrong to Try to Pick Up Girls in a Dungeon? IV Part 2
   Japonca başlık: ダンジョンに出会いを求めるのは間違っているだろうかⅣ深章 厄災篇
   Tür/yıl: Anime / 2023
   Kaynak: mal
   Harici kimlikler: Anime:mal:53111
   Ham kimlik alanları: MAL ID=53111 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=11/11, cilt=0, puan=6
   Tarihler: başlangıç=2026-10-04, bitiş=2026-10-04; favori=false
   
   
   Başlık: Dungeon ni Deai o Motomeru no wa Machigatte Iru Darouka: Familia Myth IV
   Tür/yıl: Anime / 2022
   Kaynak: simkl
   Harici kimlikler: Anime:mal:53111, Anime:simkl:2002956
   Ham kimlik alanları: MAL ID=53111 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=2002956, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=11/11, cilt=0, puan=6
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Dungeon ni Deai wo Motomeru no wa Machigatteiru Darou ka IV: Fuka Shou Yakusai-hen
   İngilizce başlık: Is It Wrong to Try to Pick Up Girls in a Dungeon? IV Part 2
   Japonca başlık: ダンジョンに出会いを求めるのは間違っているだろうかⅣ 深章 厄災篇
   Tür/yıl: Anime / 2023
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:46556
   Ham kimlik alanları: MAL ID=300046556 (dahili Kitsu kimliği, MAL değil: Kitsu #46556), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=11/11, cilt=0, puan=6
   Tarihler: başlangıç=2025-10-27, bitiş=2025-10-28; favori=false
   
   
   Başlık: Dungeon ni Deai wo Motomeru no wa Machigatteiru Darou ka IV: Shin Shou - Yakusai-hen
   Tür/yıl: Anime / 2023
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:53111, Anime:shikimori:53111
   Ham kimlik alanları: MAL ID=53111 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=11/11, cilt=0, puan=6
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: ダンジョンに出会いを求めるのは間違っているだろうかⅣ 深章 厄災編
   Japonca başlık: ダンジョンに出会いを求めるのは間違っているだろうかⅣ 深章 厄災編
   Tür/yıl: Anime / 2023
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:402223
   Ham kimlik alanları: MAL ID=500402223 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=11/11, cilt=0, puan=6
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 83 · UYARI · Eşleştirme

- Rapor satırları: `5970–6037`
- Zaman: `2026-10-24 16:21:35.240 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `2489`

```text
83. [2026-10-24 16:21:35.240 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Tensei Shitara Dai Nana Ouji Datta node, Kimamani Majutsu wo Kiwamemasu
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: Tensei Shitara Dai Nana Ouji Datta node, Kimamani Majutsu wo Kiwamemasu
   İngilizce başlık: I Was Reincarnated as the 7th Prince so I Can Take My Time Perfecting My Magical Ability
   Japonca başlık: 転生したら第七王子だったので、気ままに魔術を極めます
   Tür/yıl: Anime / 2024
   Kaynak: anilist
   Harici kimlikler: Anime:mal:53516
   Ham kimlik alanları: MAL ID=53516 (MAL), AniList kayıt ID=495061281, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=7
   Tarihler: başlangıç=2026-10-04, bitiş=2026-10-04; favori=false
   
   
   Başlık: Tensei shitara Dainana Ouji Datta node, Kimama ni Majutsu wo Kiwamemasu
   İngilizce başlık: I Was Reincarnated as the 7th Prince so I Can Take My Time Perfecting My Magical Ability
   Japonca başlık: 転生したら第七王子だったので、気ままに魔術を極めます
   Tür/yıl: Anime / 2024
   Kaynak: mal
   Harici kimlikler: Anime:mal:53516
   Ham kimlik alanları: MAL ID=53516 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=7
   Tarihler: başlangıç=2026-10-04, bitiş=2026-10-04; favori=false
   
   
   Başlık: Tensei Shitara Dai Nana Ouji Datta no de, Kimama ni Majutsu o Kiwamemasu
   Tür/yıl: Anime / 2024
   Kaynak: simkl
   Harici kimlikler: Anime:mal:53516, Anime:simkl:2028052, Anime:tmdb:213830
   Ham kimlik alanları: MAL ID=53516 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=2028052, TMDB ID=213830
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=7
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Tensei Shitara Dai Nana Ouji Dattanode, Kimamani Majutsu wo Kiwamemasu
   İngilizce başlık: I Was Reincarnated as the 7th Prince So I Can Take My Time Perfecting My Magical Ability
   Japonca başlık: 転生したら第七王子だったので、気ままに魔術を極めます
   Tür/yıl: Anime / 2024
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:46704
   Ham kimlik alanları: MAL ID=300046704 (dahili Kitsu kimliği, MAL değil: Kitsu #46704), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=7
   Tarihler: başlangıç=2025-05-19, bitiş=2025-05-19; favori=false
   
   
   Başlık: Tensei shitara Dainana Ouji Datta node, Kimama ni Majutsu wo Kiwamemasu
   Tür/yıl: Anime / 2024
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:53516, Anime:shikimori:53516
   Ham kimlik alanları: MAL ID=53516 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=7
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: 転生したら第七王子だったので、気ままに魔術を極めます
   Japonca başlık: 転生したら第七王子だったので、気ままに魔術を極めます
   Tür/yıl: Anime / 2024
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:407133
   Ham kimlik alanları: MAL ID=500407133 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=7
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 84 · UYARI · Eşleştirme

- Rapor satırları: `6039–6106`
- Zaman: `2026-10-24 16:21:35.242 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `2492`

```text
84. [2026-10-24 16:21:35.242 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Tensei Shitara Slime Datta Ken 3rd Season
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: Tensei Shitara Slime Datta Ken 3rd Season
   İngilizce başlık: That Time I Got Reincarnated as a Slime Season 3
   Japonca başlık: 転生したらスライムだった件 第3期
   Tür/yıl: Anime / 2024
   Kaynak: anilist
   Harici kimlikler: Anime:mal:53580
   Ham kimlik alanları: MAL ID=53580 (MAL), AniList kayıt ID=495061285, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/24, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Tensei shitara Slime Datta Ken 3rd Season
   İngilizce başlık: That Time I Got Reincarnated as a Slime Season 3
   Japonca başlık: 転生したらスライムだった件 第3期
   Tür/yıl: Anime / 2024
   Kaynak: mal
   Harici kimlikler: Anime:mal:53580
   Ham kimlik alanları: MAL ID=53580 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/24, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Tensei Shitara Slime Datta Ken
   Tür/yıl: Anime / 2024
   Kaynak: simkl
   Harici kimlikler: Anime:mal:53580, Anime:simkl:2031512
   Ham kimlik alanları: MAL ID=53580 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=2031512, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/24, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Tensei Shitara Slime Datta Ken 3rd Season
   İngilizce başlık: That Time I Got Reincarnated as a Slime Season 3
   Japonca başlık: 転生したらスライムだった件 第3期
   Tür/yıl: Anime / 2024
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:46729
   Ham kimlik alanları: MAL ID=300046729 (dahili Kitsu kimliği, MAL değil: Kitsu #46729), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/24, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Tensei shitara Slime Datta Ken 3rd Season
   Tür/yıl: Anime / 2024
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:53580, Anime:shikimori:53580
   Ham kimlik alanları: MAL ID=53580 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/24, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: 転生したらスライムだった件 第3期
   Japonca başlık: 転生したらスライムだった件 第3期
   Tür/yıl: Anime / 2024
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:407573
   Ham kimlik alanları: MAL ID=500407573 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/24, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 85 · HATA · AniList

- Rapor satırları: `6108–6187`
- Zaman: `2026-10-24 16:21:37.312 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `update_error` / `identity_unverified`
- Tüm olay no: `2498`

```text
85. [2026-10-24 16:21:37.312 GMT+03:00] [HATA] [AniList] [AniList] ! Güncellenemedi: クラスで男は僕一人！？
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Hata: java.lang.IllegalStateException: AniList liste kaydının bu medya ile eşleştiği doğrulanamadı: クラスで男は僕一人！？
     at com.kitsugi.animelist.data.auth.AniListSyncManager.updateAniListEntry(?:718)
     at com.kitsugi.animelist.data.auth.AniListSyncManager.updateAniListEntry$default(?:40)
     at c7.r1.invokeSuspend(?:26941)
     at kotlin.coroutines.jvm.internal.BaseContinuationImpl.resumeWith(?:11)
     at kotlinx.coroutines.DispatchedTask.run(?:128)
     at kotlinx.coroutines.internal.LimitedDispatcher$Worker.run(?:3)
   
   Kaynak platform kayıtları (5):
   Kayıt 1:
   Başlık: Class de Otoko wa Boku Hitori!?: Kawaii Anoko-tachi ni Kakomarete
   Japonca başlık: クラスで男は僕一人！？～可愛いあの子達に囲まれて～
   Tür/yıl: Anime / 2023
   Kaynak: anilist
   Harici kimlikler: Anime:mal:53725
   Ham kimlik alanları: MAL ID=53725 (MAL), AniList kayıt ID=495060876, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=8
   Tarihler: başlangıç=yok, bitiş=2025-05-09; favori=true
   
   Kayıt 2:
   Başlık: Class de Otoko wa Boku Hitori!?
   Japonca başlık: クラスで男は僕一人!?
   Tür/yıl: Anime / 2023
   Kaynak: mal
   Harici kimlikler: Anime:mal:53725
   Ham kimlik alanları: MAL ID=53725 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=8
   Tarihler: başlangıç=yok, bitiş=2025-05-09; favori=false
   
   Kayıt 3:
   Başlık: Class de Otoko wa Boku Hitori!?: Kawaii Anoko-tachi ni Kakomarete
   İngilizce başlık: I'm the Only Guy in the Class!?
   Japonca başlık: クラスで男は僕一人！？～可愛いあの子達に囲まれて～
   Tür/yıl: Anime / 2023
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:47174
   Ham kimlik alanları: MAL ID=300047174 (dahili Kitsu kimliği, MAL değil: Kitsu #47174), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=8
   Tarihler: başlangıç=2026-10-07, bitiş=2025-05-09; favori=false
   
   Kayıt 4:
   Başlık: Class de Otoko wa Boku Hitori!?
   Tür/yıl: Anime / 2023
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:53725, Anime:shikimori:53725
   Ham kimlik alanları: MAL ID=53725 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=8
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 5:
   Başlık: クラスで男は僕一人！？
   Japonca başlık: クラスで男は僕一人！？
   Tür/yıl: Anime / 2023
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:409371
   Ham kimlik alanları: MAL ID=500409371 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=8
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Eşitleme için birleştirilen değerler:
   Başlık: クラスで男は僕一人！？
   İngilizce başlık: I'm the Only Guy in the Class!?
   Japonca başlık: クラスで男は僕一人！？～可愛いあの子達に囲まれて～
   Tür/yıl: Anime / 2023
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:53725
   Ham kimlik alanları: MAL ID=53725 (MAL), AniList kayıt ID=495060876, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=8
   Tarihler: başlangıç=2026-10-07, bitiş=2025-05-09; favori=true
   
   Kimlik güvencesi: Güvenilir (MAL/Shikimori kaydının kendi kimliği)
```

## Sorun 86 · UYARI · Eşleştirme

- Rapor satırları: `6189–6255`
- Zaman: `2026-10-24 16:21:39.503 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `2506`

```text
86. [2026-10-24 16:21:39.503 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: SPY×FAMILY Season 2
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: SPY×FAMILY Season 2
   İngilizce başlık: SPY x FAMILY Season 2
   Japonca başlık: SPY×FAMILY Season 2
   Tür/yıl: Anime / 2023
   Kaynak: anilist
   Harici kimlikler: Anime:mal:53887
   Ham kimlik alanları: MAL ID=53887 (MAL), AniList kayıt ID=495061249, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Spy x Family Season 2
   Japonca başlık: SPY×FAMILY Season 2
   Tür/yıl: Anime / 2023
   Kaynak: mal
   Harici kimlikler: Anime:mal:53887
   Ham kimlik alanları: MAL ID=53887 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Spy x Family
   Tür/yıl: Anime / 2023
   Kaynak: simkl
   Harici kimlikler: Anime:mal:53887, Anime:simkl:2060000
   Ham kimlik alanları: MAL ID=53887 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=2060000, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: SPY×FAMILY Season 2
   İngilizce başlık: SPY x FAMILY Season 2
   Japonca başlık: SPY×FAMILY Season 2
   Tür/yıl: Anime / 2023
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:46873
   Ham kimlik alanları: MAL ID=300046873 (dahili Kitsu kimliği, MAL değil: Kitsu #46873), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Spy x Family Season 2
   Tür/yıl: Anime / 2023
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:53887, Anime:shikimori:53887
   Ham kimlik alanları: MAL ID=53887 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: SPY×FAMILY Season 2
   Japonca başlık: SPY×FAMILY Season 2
   Tür/yıl: Anime / 2023
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:411427
   Ham kimlik alanları: MAL ID=500411427 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 87 · HATA · AniList

- Rapor satırları: `6257–6347`
- Zaman: `2026-10-24 16:21:42.189 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `update_error` / `identity_unverified`
- Tüm olay no: `2513`

```text
87. [2026-10-24 16:21:42.189 GMT+03:00] [HATA] [AniList] [AniList] ! Güncellenemedi: ゾン100～ゾンビになるまでにしたい100のこと～
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Hata: java.lang.IllegalStateException: AniList liste kaydının bu medya ile eşleştiği doğrulanamadı: ゾン100～ゾンビになるまでにしたい100のこと～
     at com.kitsugi.animelist.data.auth.AniListSyncManager.updateAniListEntry(?:718)
     at com.kitsugi.animelist.data.auth.AniListSyncManager.updateAniListEntry$default(?:40)
     at c7.r1.invokeSuspend(?:26941)
     at kotlin.coroutines.jvm.internal.BaseContinuationImpl.resumeWith(?:11)
     at kotlinx.coroutines.UndispatchedCoroutine.afterResume(?:30)
     at kotlinx.coroutines.AbstractCoroutine.resumeWith(?:13)
   
   Kaynak platform kayıtları (6):
   Kayıt 1:
   Başlık: Zom 100: Zombie ni Naru Made ni Shitai 100 no Koto
   İngilizce başlık: Zom 100: Bucket List of the Dead
   Japonca başlık: ゾン100～ゾンビになるまでにしたい100のこと～
   Tür/yıl: Anime / 2023
   Kaynak: anilist
   Harici kimlikler: Anime:mal:54112
   Ham kimlik alanları: MAL ID=54112 (MAL), AniList kayıt ID=573072637, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Bırakıldı, bölüm=4/12, cilt=0, puan=yok
   Tarihler: başlangıç=2026-10-22, bitiş=yok; favori=false
   
   Kayıt 2:
   Başlık: Zom 100: Zombie ni Naru made ni Shitai 100 no Koto
   İngilizce başlık: Zom 100: Bucket List of the Dead
   Japonca başlık: ゾン100～ゾンビになるまでにしたい100のこと～
   Tür/yıl: Anime / 2023
   Kaynak: mal
   Harici kimlikler: Anime:mal:54112
   Ham kimlik alanları: MAL ID=54112 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Bırakıldı, bölüm=4/12, cilt=0, puan=yok
   Tarihler: başlangıç=2026-10-22, bitiş=yok; favori=false
   
   Kayıt 3:
   Başlık: Zom 100: Zombie ni Naru made ni Shitai 100 no Koto
   Tür/yıl: Anime / 2023
   Kaynak: simkl
   Harici kimlikler: Anime:mal:54112, Anime:simkl:2070506, Anime:tmdb:217766
   Ham kimlik alanları: MAL ID=54112 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=2070506, TMDB ID=217766
   Durum/ilerleme: İzleniyor, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 4:
   Başlık: Zom 100: Zombie ni Naru made ni Shitai 100 no Koto
   İngilizce başlık: Zom 100: Bucket List of the Dead
   Japonca başlık: ン100～ゾンビになるまでにしたい100のこと～
   Tür/yıl: Anime / 2023
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:46954
   Ham kimlik alanları: MAL ID=300046954 (dahili Kitsu kimliği, MAL değil: Kitsu #46954), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: İzleniyor, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=2026-10-04, bitiş=yok; favori=false
   
   Kayıt 5:
   Başlık: Zom 100: Zombie ni Naru made ni Shitai 100 no Koto
   Tür/yıl: Anime / 2023
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:54112, Anime:shikimori:54112
   Ham kimlik alanları: MAL ID=54112 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: İzleniyor, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 6:
   Başlık: ゾン100～ゾンビになるまでにしたい100のこと～
   Japonca başlık: ゾン100～ゾンビになるまでにしたい100のこと～
   Tür/yıl: Anime / 2023
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:414461
   Ham kimlik alanları: MAL ID=500414461 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: İzleniyor, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Eşitleme için birleştirilen değerler:
   Başlık: ゾン100～ゾンビになるまでにしたい100のこと～
   İngilizce başlık: Zom 100: Bucket List of the Dead
   Japonca başlık: ゾン100～ゾンビになるまでにしたい100のこと～
   Tür/yıl: Anime / 2023
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:54112, Anime:simkl:2070506, Anime:tmdb:217766
   Ham kimlik alanları: MAL ID=54112 (MAL), AniList kayıt ID=573072637, MAL liste ID=yok, Simkl ID=2070506, TMDB ID=217766
   Durum/ilerleme: İzleniyor, bölüm=4/12, cilt=0, puan=yok
   Tarihler: başlangıç=2026-10-04, bitiş=yok; favori=false
   
   Kimlik güvencesi: Gerek yok (tüm hedef platformlarda kayıt zaten var)
```

## Sorun 88 · UYARI · Eşleştirme

- Rapor satırları: `6349–6416`
- Zaman: `2026-10-24 16:21:44.597 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `2526`

```text
88. [2026-10-24 16:21:44.597 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Seishun Buta Yarou wa Randoseru Girl no Yume wo Minai
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: Seishun Buta Yarou wa Randoseru Girl no Yume wo Minai
   İngilizce başlık: Rascal Does Not Dream of a Knapsack Kid
   Japonca başlık: 青春ブタ野郎はランドセルガールの夢を見ない
   Tür/yıl: Anime / 2023
   Kaynak: anilist
   Harici kimlikler: Anime:mal:54870
   Ham kimlik alanları: MAL ID=54870 (MAL), AniList kayıt ID=495061219, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Seishun Buta Yarou wa Randoseru Girl no Yume wo Minai
   İngilizce başlık: Rascal Does Not Dream of a Knapsack Kid
   Japonca başlık: 青春ブタ野郎はランドセルガールの夢を見ない
   Tür/yıl: Anime / 2023
   Kaynak: mal
   Harici kimlikler: Anime:mal:54870
   Ham kimlik alanları: MAL ID=54870 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Seishun Buta Yarou wa Ransel Girl no Yume o Minai
   Tür/yıl: Anime / 2023
   Kaynak: simkl
   Harici kimlikler: Anime:mal:54870, Anime:simkl:2093846, Anime:tmdb:1086591
   Ham kimlik alanları: MAL ID=54870 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=2093846, TMDB ID=1086591
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Seishun Buta Yarou wa Randoseru Girl no Yume wo Minai
   İngilizce başlık: Rascal Does Not Dream of a Knapsack Kid
   Japonca başlık: 青春ブタ野郎はランドセルガールの夢を見ない
   Tür/yıl: Anime / 2023
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:47742
   Ham kimlik alanları: MAL ID=300047742 (dahili Kitsu kimliği, MAL değil: Kitsu #47742), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Seishun Buta Yarou wa Randoseru Girl no Yume wo Minai
   Tür/yıl: Anime / 2023
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:54870, Anime:shikimori:54870
   Ham kimlik alanları: MAL ID=54870 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: 青春ブタ野郎はランドセルガールの夢を見ない
   Japonca başlık: 青春ブタ野郎はランドセルガールの夢を見ない
   Tür/yıl: Anime / 2023
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:426239
   Ham kimlik alanları: MAL ID=500426239 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 89 · UYARI · Eşleştirme

- Rapor satırları: `6418–6485`
- Zaman: `2026-10-24 16:21:44.603 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `2533`

```text
89. [2026-10-24 16:21:44.603 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Kimi no Koto ga Dai Dai Dai Dai Daisuki na 100-nin no Kanojo
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: Kimi no Koto ga Dai Dai Dai Dai Daisuki na 100-nin no Kanojo
   İngilizce başlık: The 100 Girlfriends Who Really, Really, Really, Really, REALLY Love You
   Japonca başlık: 君のことが大大大大大好きな100人の彼女
   Tür/yıl: Anime / 2023
   Kaynak: anilist
   Harici kimlikler: Anime:mal:54714
   Ham kimlik alanları: MAL ID=54714 (MAL), AniList kayıt ID=495061035, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Kimi no Koto ga Daidaidaidaidaisuki na 100-nin no Kanojo
   İngilizce başlık: The 100 Girlfriends Who Really, Really, Really, Really, Really Love You
   Japonca başlık: 君のことが大大大大大好きな100人の彼女
   Tür/yıl: Anime / 2023
   Kaynak: mal
   Harici kimlikler: Anime:mal:54714
   Ham kimlik alanları: MAL ID=54714 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Kimi no Koto ga Dai Dai Dai Dai Daisuki na Hyakunin no Kanojo
   Tür/yıl: Anime / 2023
   Kaynak: simkl
   Harici kimlikler: Anime:mal:54714, Anime:simkl:2120192, Anime:tmdb:223564
   Ham kimlik alanları: MAL ID=54714 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=2120192, TMDB ID=223564
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Kimi no Koto ga Dai Dai Dai Dai Daisuki na 100-nin no Kanojo
   İngilizce başlık: The 100 Girlfriends Who Really, Really, Really, Really, REALLY Love You
   Japonca başlık: 君のことが大大大大大好きな100人の彼女
   Tür/yıl: Anime / 2023
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:47179
   Ham kimlik alanları: MAL ID=300047179 (dahili Kitsu kimliği, MAL değil: Kitsu #47179), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Kimi no Koto ga Daidaidaidaidaisuki na 100-nin no Kanojo
   Tür/yıl: Anime / 2023
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:54714, Anime:shikimori:54714
   Ham kimlik alanları: MAL ID=54714 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: 君のことが大大大大大好きな100人の彼女
   Japonca başlık: 君のことが大大大大大好きな100人の彼女
   Tür/yıl: Anime / 2023
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:424379
   Ham kimlik alanları: MAL ID=500424379 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 90 · UYARI · Eşleştirme

- Rapor satırları: `6487–6553`
- Zaman: `2026-10-24 16:21:44.608 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `2540`

```text
90. [2026-10-24 16:21:44.608 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Sugar Apple Fairy Tale Part 2
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: Sugar Apple Fairy Tale Part 2
   İngilizce başlık: Sugar Apple Fairy Tale Season 2
   Japonca başlık: シュガーアップル・フェアリーテイル 第2クール
   Tür/yıl: Anime / 2023
   Kaynak: anilist
   Harici kimlikler: Anime:mal:54842
   Ham kimlik alanları: MAL ID=54842 (MAL), AniList kayıt ID=500615511, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Sugar Apple Fairy Tale Part 2
   Japonca başlık: シュガーアップル・フェアリーテイル
   Tür/yıl: Anime / 2023
   Kaynak: mal
   Harici kimlikler: Anime:mal:54842
   Ham kimlik alanları: MAL ID=54842 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Sugar Apple Fairy Tale
   Tür/yıl: Anime / 2023
   Kaynak: simkl
   Harici kimlikler: Anime:mal:54842, Anime:simkl:2125618
   Ham kimlik alanları: MAL ID=54842 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=2125618, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Sugar Apple Fairy Tale Part 2
   İngilizce başlık: Sugar Apple Fairy Tale Season 2
   Japonca başlık: シュガーアップル・フェアリーテイル 第2クール
   Tür/yıl: Anime / 2023
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:47231
   Ham kimlik alanları: MAL ID=300047231 (dahili Kitsu kimliği, MAL değil: Kitsu #47231), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Sugar Apple Fairy Tale Part 2
   Tür/yıl: Anime / 2023
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:54842, Anime:shikimori:54842
   Ham kimlik alanları: MAL ID=54842 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: シュガーアップル・フェアリーテイル 第2クール
   Japonca başlık: シュガーアップル・フェアリーテイル 第2クール
   Tür/yıl: Anime / 2023
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:425916
   Ham kimlik alanları: MAL ID=500425916 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 91 · UYARI · Eşleştirme

- Rapor satırları: `6555–6622`
- Zaman: `2026-10-24 16:21:44.610 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `2543`

```text
91. [2026-10-24 16:21:44.610 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Re:Zero kara Hajimeru Isekai Seikatsu 3rd Season
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: Re:Zero kara Hajimeru Isekai Seikatsu 3rd Season
   İngilizce başlık: Re:ZERO -Starting Life in Another World- Season 3
   Japonca başlık: Re:ゼロから始める異世界生活 3rd season
   Tür/yıl: Anime / 2024
   Kaynak: anilist
   Harici kimlikler: Anime:mal:54857
   Ham kimlik alanları: MAL ID=54857 (MAL), AniList kayıt ID=495061195, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=16/16, cilt=0, puan=6
   Tarihler: başlangıç=2025-04-14, bitiş=2026-10-04; favori=false
   
   
   Başlık: Re:Zero kara Hajimeru Isekai Seikatsu 3rd Season
   İngilizce başlık: Re:ZERO -Starting Life in Another World- Season 3
   Japonca başlık: Re:ゼロから始める異世界生活 3rd season
   Tür/yıl: Anime / 2024
   Kaynak: mal
   Harici kimlikler: Anime:mal:54857
   Ham kimlik alanları: MAL ID=54857 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=16/16, cilt=0, puan=6
   Tarihler: başlangıç=2025-04-14, bitiş=2026-10-04; favori=false
   
   
   Başlık: Re:Zero kara Hajimeru Isekai Seikatsu
   Tür/yıl: Anime / 2024
   Kaynak: simkl
   Harici kimlikler: Anime:mal:54857, Anime:simkl:2125704
   Ham kimlik alanları: MAL ID=54857 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=2125704, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=16/16, cilt=0, puan=6
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Re:Zero kara Hajimeru Isekai Seikatsu 3
   İngilizce başlık: Re:ZERO -Starting Life in Another World- Season 3
   Japonca başlık: Re:ゼロから始める異世界生活 3
   Tür/yıl: Anime / 2024
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:47235
   Ham kimlik alanları: MAL ID=300047235 (dahili Kitsu kimliği, MAL değil: Kitsu #47235), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=16/16, cilt=0, puan=6
   Tarihler: başlangıç=2025-01-29, bitiş=2025-07-10; favori=false
   
   
   Başlık: Re:Zero kara Hajimeru Isekai Seikatsu 3rd Season
   Tür/yıl: Anime / 2024
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:54857, Anime:shikimori:54857
   Ham kimlik alanları: MAL ID=54857 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=16/16, cilt=0, puan=6
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Re:ゼロから始める異世界生活 3rd season 襲擊編
   Japonca başlık: Re:ゼロから始める異世界生活 3rd season 襲擊編
   Tür/yıl: Anime / 2024
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:425998
   Ham kimlik alanları: MAL ID=500425998 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=8/8, cilt=0, puan=6
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 92 · UYARI · Eşleştirme

- Rapor satırları: `6624–6680`
- Zaman: `2026-10-24 16:21:44.617 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `2554`

```text
92. [2026-10-24 16:21:44.617 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Re:STARS: Mirai e Tsunagu 2-tsu no Kiraboshi
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: Re:STARS: Mirai e Tsunagu 2-tsu no Kiraboshi
   Japonca başlık: Re:STARS 〜未来へ繋ぐ2つのきらぼし〜
   Tür/yıl: Anime / 2023
   Kaynak: anilist
   Harici kimlikler: Anime:mal:58198
   Ham kimlik alanları: MAL ID=58198 (MAL), AniList kayıt ID=600509776, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=9
   Tarihler: başlangıç=2026-10-04, bitiş=2026-10-04; favori=false
   
   
   Başlık: Jintian Kaishi Zuo Mingxing: Tianshi Qingge
   İngilizce başlık: Re:STARS: Two Shining Stars Connect to the Future
   Japonca başlık: 今天开始做明星之天使情歌
   Tür/yıl: Anime / 2021
   Kaynak: mal
   Harici kimlikler: Anime:mal:58198
   Ham kimlik alanları: MAL ID=58198 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=9
   Tarihler: başlangıç=2026-10-04, bitiş=2026-10-04; favori=false
   
   
   Başlık: Jintian Kaishi Zuo Mingxing: Tianshi Qingge
   Japonca başlık: 今天开始做明星之天使情歌
   Tür/yıl: Anime / 2021
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:48637
   Ham kimlik alanları: MAL ID=300048637 (dahili Kitsu kimliği, MAL değil: Kitsu #48637), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=9
   Tarihler: başlangıç=2026-10-04, bitiş=2026-10-04; favori=false
   
   
   Başlık: Jintian Kaishi Zuo Mingxing: Tianshi Qingge
   Tür/yıl: Anime / 2021
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:58198, Anime:shikimori:58198
   Ham kimlik alanları: MAL ID=58198 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=9
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: 今天开始做明星之天使情歌
   Japonca başlık: 今天开始做明星之天使情歌
   Tür/yıl: Anime / 2021
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:364866
   Ham kimlik alanları: MAL ID=500364866 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=9
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 93 · UYARI · Eşleştirme

- Rapor satırları: `6682–6749`
- Zaman: `2026-10-24 16:21:44.623 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `2567`

```text
93. [2026-10-24 16:21:44.623 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Boku no Kokoro no Yabai Yatsu 2nd Season
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: Boku no Kokoro no Yabai Yatsu 2nd Season
   İngilizce başlık: The Dangers in My Heart Season 2
   Japonca başlık: 僕の心のヤバイやつ 第2期
   Tür/yıl: Anime / 2024
   Kaynak: anilist
   Harici kimlikler: Anime:mal:55690
   Ham kimlik alanları: MAL ID=55690 (MAL), AniList kayıt ID=495060857, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/13, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Boku no Kokoro no Yabai Yatsu 2nd Season
   İngilizce başlık: The Dangers in My Heart Season 2
   Japonca başlık: 僕の心のヤバイやつ 第2期
   Tür/yıl: Anime / 2024
   Kaynak: mal
   Harici kimlikler: Anime:mal:55690
   Ham kimlik alanları: MAL ID=55690 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/13, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Boku no Kokoro no Yabai Yatsu
   Tür/yıl: Anime / 2024
   Kaynak: simkl
   Harici kimlikler: Anime:mal:55690, Anime:simkl:2190420
   Ham kimlik alanları: MAL ID=55690 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=2190420, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/13, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Boku no Kokoro no Yabai Yatsu 2nd Season
   İngilizce başlık: The Dangers in My Heart Season 2
   Japonca başlık: 僕の心のヤバイやつ 第2期
   Tür/yıl: Anime / 2024
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:47634
   Ham kimlik alanları: MAL ID=300047634 (dahili Kitsu kimliği, MAL değil: Kitsu #47634), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/13, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Boku no Kokoro no Yabai Yatsu 2nd Season
   Tür/yıl: Anime / 2024
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:55690, Anime:shikimori:55690
   Ham kimlik alanları: MAL ID=55690 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/13, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: 僕の心のヤバイやつ 第2期
   Japonca başlık: 僕の心のヤバイやつ 第2期
   Tür/yıl: Anime / 2024
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:441795
   Ham kimlik alanları: MAL ID=500441795 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/13, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 94 · UYARI · Eşleştirme

- Rapor satırları: `6751–6818`
- Zaman: `2026-10-24 16:21:44.629 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `2574`

```text
94. [2026-10-24 16:21:44.629 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: [Oshi no Ko] 2nd Season
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: [Oshi no Ko] 2nd Season
   İngilizce başlık: OSHI NO KO Season 2
   Japonca başlık: 【推しの子】第2期
   Tür/yıl: Anime / 2024
   Kaynak: anilist
   Harici kimlikler: Anime:mal:55791
   Ham kimlik alanları: MAL ID=55791 (MAL), AniList kayıt ID=495061349, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/13, cilt=0, puan=10
   Tarihler: başlangıç=2026-07-16, bitiş=2026-07-18; favori=false
   
   
   Başlık: [Oshi no Ko] 2nd Season
   İngilizce başlık: [Oshi No Ko] Season 2
   Japonca başlık: 【推しの子】第2期
   Tür/yıl: Anime / 2024
   Kaynak: mal
   Harici kimlikler: Anime:mal:55791
   Ham kimlik alanları: MAL ID=55791 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/13, cilt=0, puan=10
   Tarihler: başlangıç=2026-07-16, bitiş=2026-07-18; favori=false
   
   
   Başlık: "Oshi no Ko"
   Tür/yıl: Anime / 2024
   Kaynak: simkl
   Harici kimlikler: Anime:mal:55791, Anime:simkl:2198092
   Ham kimlik alanları: MAL ID=55791 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=2198092, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/13, cilt=0, puan=10
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: [Oshi no Ko] Season 2
   İngilizce başlık: Oshi no Ko Season 2
   Japonca başlık: 【推しの子】第2期
   Tür/yıl: Anime / 2024
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:47659
   Ham kimlik alanları: MAL ID=300047659 (dahili Kitsu kimliği, MAL değil: Kitsu #47659), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/13, cilt=0, puan=10
   Tarihler: başlangıç=2026-07-16, bitiş=2026-07-18; favori=false
   
   
   Başlık: [Oshi no Ko] 2nd Season
   Tür/yıl: Anime / 2024
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:55791, Anime:shikimori:55791
   Ham kimlik alanları: MAL ID=55791 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/13, cilt=0, puan=10
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: 【推しの子】 第2期
   Japonca başlık: 【推しの子】 第2期
   Tür/yıl: Anime / 2024
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:443428
   Ham kimlik alanları: MAL ID=500443428 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/13, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 95 · UYARI · Eşleştirme

- Rapor satırları: `6820–6887`
- Zaman: `2026-10-24 16:21:44.630 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `2577`

```text
95. [2026-10-24 16:21:44.630 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Jigokuraku 2nd Season
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: Jigokuraku 2nd Season
   İngilizce başlık: Hell’s Paradise Season 2
   Japonca başlık: 地獄楽 第二期
   Tür/yıl: Anime / 2026
   Kaynak: anilist
   Harici kimlikler: Anime:mal:55825
   Ham kimlik alanları: MAL ID=55825 (MAL), AniList kayıt ID=551216931, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=6
   Tarihler: başlangıç=2026-10-04, bitiş=2026-10-04; favori=false
   
   
   Başlık: Jigokuraku 2nd Season
   İngilizce başlık: Hell's Paradise Season 2
   Japonca başlık: 地獄楽第二期
   Tür/yıl: Anime / 2026
   Kaynak: mal
   Harici kimlikler: Anime:mal:55825
   Ham kimlik alanları: MAL ID=55825 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=6
   Tarihler: başlangıç=2026-10-04, bitiş=2026-10-04; favori=false
   
   
   Başlık: Jigokuraku
   Tür/yıl: Anime / 2026
   Kaynak: simkl
   Harici kimlikler: Anime:mal:55825, Anime:simkl:2200134
   Ham kimlik alanları: MAL ID=55825 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=2200134, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=6
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Jigokuraku 2nd Season
   İngilizce başlık: Hell's Paradise Season 2
   Japonca başlık: 地獄楽 第二期
   Tür/yıl: Anime / 2026
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:47679
   Ham kimlik alanları: MAL ID=300047679 (dahili Kitsu kimliği, MAL değil: Kitsu #47679), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=6
   Tarihler: başlangıç=2026-04-15, bitiş=2026-04-17; favori=false
   
   
   Başlık: Jigokuraku 2nd Season
   Tür/yıl: Anime / 2026
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:55825, Anime:shikimori:55825
   Ham kimlik alanları: MAL ID=55825 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=6
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: 地獄楽 第二期
   Japonca başlık: 地獄楽 第二期
   Tür/yıl: Anime / 2026
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:443446
   Ham kimlik alanları: MAL ID=500443446 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=6
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 96 · UYARI · Eşleştirme

- Rapor satırları: `6889–6956`
- Zaman: `2026-10-24 16:21:44.632 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `2580`

```text
96. [2026-10-24 16:21:44.632 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Mushoku Tensei II: Isekai Ittara Honki Dasu Part 2
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: Mushoku Tensei II: Isekai Ittara Honki Dasu Part 2
   İngilizce başlık: Mushoku Tensei: Jobless Reincarnation Season 2 Part 2
   Japonca başlık: 無職転生Ⅱ ～異世界行ったら本気だす～ 第2クール
   Tür/yıl: Anime / 2024
   Kaynak: anilist
   Harici kimlikler: Anime:mal:55888
   Ham kimlik alanları: MAL ID=55888 (MAL), AniList kayıt ID=495061129, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=10
   Tarihler: başlangıç=2025-02-21, bitiş=2025-02-21; favori=true
   
   
   Başlık: Mushoku Tensei II: Isekai Ittara Honki Dasu Part 2
   İngilizce başlık: Mushoku Tensei: Jobless Reincarnation Season 2 Part 2
   Japonca başlık: 無職転生 II ～異世界行ったら本気だす～ (第2クール)
   Tür/yıl: Anime / 2024
   Kaynak: mal
   Harici kimlikler: Anime:mal:55888
   Ham kimlik alanları: MAL ID=55888 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=10
   Tarihler: başlangıç=2025-02-21, bitiş=2025-02-21; favori=false
   
   
   Başlık: Mushoku Tensei II: Isekai Ittara Honki Dasu
   Tür/yıl: Anime / 2024
   Kaynak: simkl
   Harici kimlikler: Anime:mal:55888, Anime:simkl:2204668
   Ham kimlik alanları: MAL ID=55888 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=2204668, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=10
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Mushoku Tensei II: Isekai Ittara Honki Dasu Part 2
   İngilizce başlık: Mushoku Tensei: Jobless Reincarnation Season 2 Part 2
   Japonca başlık: 無職転生 Ⅱ ～異世界行ったら本気だす～ 第2クール
   Tür/yıl: Anime / 2024
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:47694
   Ham kimlik alanları: MAL ID=300047694 (dahili Kitsu kimliği, MAL değil: Kitsu #47694), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=10
   Tarihler: başlangıç=2023-01-20, bitiş=2024-07-10; favori=false
   
   
   Başlık: Mushoku Tensei II: Isekai Ittara Honki Dasu Part 2
   Tür/yıl: Anime / 2024
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:55888, Anime:shikimori:55888
   Ham kimlik alanları: MAL ID=55888 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=10
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: 無職転生Ⅱ ～異世界行ったら本気だす～ 第2クール
   Japonca başlık: 無職転生Ⅱ ～異世界行ったら本気だす～ 第2クール
   Tür/yıl: Anime / 2024
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:444557
   Ham kimlik alanları: MAL ID=500444557 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=10
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 97 · UYARI · Eşleştirme

- Rapor satırları: `6958–7006`
- Zaman: `2026-10-24 16:21:44.637 GMT+03:00`
- Kod: `—`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `2589`

```text
97. [2026-10-24 16:21:44.637 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: NieR:Automata Ver1.1a 2nd Season
   Başlık: NieR:Automata Ver1.1a 2nd Season
   İngilizce başlık: NieR:Automata Ver1.1a Cour 2
   Japonca başlık: NieR:Automata Ver1.1a 第2期
   Tür/yıl: Anime / 2024
   Kaynak: anilist
   Harici kimlikler: Anime:mal:56063
   Ham kimlik alanları: MAL ID=56063 (MAL), AniList kayıt ID=495061145, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: NieR:Automata Ver1.1a Part 2
   İngilizce başlık: NieR:Automata Ver1.1a (Cour 2)
   Japonca başlık: NieR:Automata Ver1.1a 第2クール
   Tür/yıl: Anime / 2024
   Kaynak: mal
   Harici kimlikler: Anime:mal:56063
   Ham kimlik alanları: MAL ID=56063 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: NieR:Automata Ver1.1a
   Tür/yıl: Anime / 2024
   Kaynak: simkl
   Harici kimlikler: Anime:mal:56063, Anime:simkl:2215664
   Ham kimlik alanları: MAL ID=56063 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=2215664, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: NieR:Automata Ver1.1a Part 2
   Japonca başlık: NieR:Automata Ver1.1a 第2クール
   Tür/yıl: Anime / 2024
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:47784
   Ham kimlik alanları: MAL ID=300047784 (dahili Kitsu kimliği, MAL değil: Kitsu #47784), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: NieR:Automata Ver1.1a Part 2
   Tür/yıl: Anime / 2024
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:56063, Anime:shikimori:56063
   Ham kimlik alanları: MAL ID=56063 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 98 · HATA · AniList

- Rapor satırları: `7008–7085`
- Zaman: `2026-10-24 16:21:44.828 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `update_error` / `identity_unverified`
- Tüm olay no: `2591`

```text
98. [2026-10-24 16:21:44.828 GMT+03:00] [HATA] [AniList] [AniList] ! Güncellenemedi: 初恋時間。
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Hata: java.lang.IllegalStateException: AniList liste kaydının bu medya ile eşleştiği doğrulanamadı: 初恋時間。
     at com.kitsugi.animelist.data.auth.AniListSyncManager.updateAniListEntry(?:718)
     at com.kitsugi.animelist.data.auth.AniListSyncManager.updateAniListEntry$default(?:40)
     at c7.r1.invokeSuspend(?:26941)
     at kotlin.coroutines.jvm.internal.BaseContinuationImpl.resumeWith(?:11)
     at kotlinx.coroutines.DispatchedTask.run(?:128)
     at kotlinx.coroutines.internal.LimitedDispatcher$Worker.run(?:3)
   
   Kaynak platform kayıtları (5):
   Kayıt 1:
   Başlık: Hatsukoi Time.
   Japonca başlık: 初恋時間。
   Tür/yıl: Anime / 2023
   Kaynak: anilist
   Harici kimlikler: Anime:mal:56511
   Ham kimlik alanları: MAL ID=56511 (MAL), AniList kayıt ID=495060967, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=6/6, cilt=0, puan=10
   Tarihler: başlangıç=yok, bitiş=yok; favori=true
   
   Kayıt 2:
   Başlık: Hatsukoi Jikan
   Japonca başlık: 初恋時間.
   Tür/yıl: Anime / 2023
   Kaynak: mal
   Harici kimlikler: Anime:mal:56511
   Ham kimlik alanları: MAL ID=56511 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=6/6, cilt=0, puan=10
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 3:
   Başlık: Hatsukoi Jikan
   Japonca başlık: 初恋時間。
   Tür/yıl: Anime / 2023
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:48301
   Ham kimlik alanları: MAL ID=300048301 (dahili Kitsu kimliği, MAL değil: Kitsu #48301), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=6/6, cilt=0, puan=10
   Tarihler: başlangıç=2026-10-07, bitiş=2026-10-07; favori=false
   
   Kayıt 4:
   Başlık: Hatsukoi Jikan
   Tür/yıl: Anime / 2023
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:56511, Anime:shikimori:56511
   Ham kimlik alanları: MAL ID=56511 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=6/6, cilt=0, puan=10
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 5:
   Başlık: 初恋時間。
   Japonca başlık: 初恋時間。
   Tür/yıl: Anime / 2023
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:451561
   Ham kimlik alanları: MAL ID=500451561 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=6/6, cilt=0, puan=10
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Eşitleme için birleştirilen değerler:
   Başlık: 初恋時間。
   Japonca başlık: 初恋時間。
   Tür/yıl: Anime / 2023
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:56511
   Ham kimlik alanları: MAL ID=56511 (MAL), AniList kayıt ID=495060967, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=6/6, cilt=0, puan=10
   Tarihler: başlangıç=2026-10-07, bitiş=2026-10-07; favori=true
   
   Kimlik güvencesi: Güvenilir (MAL/Shikimori kaydının kendi kimliği)
```

## Sorun 99 · UYARI · Eşleştirme

- Rapor satırları: `7087–7125`
- Zaman: `2026-10-24 16:21:45.413 GMT+03:00`
- Kod: `—`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `2595`

```text
99. [2026-10-24 16:21:45.413 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Kanojo, Okarishimasu × Temple Collab Mini Anime
   Başlık: Kanojo, Okarishimasu × Temple Collab Mini Anime
   Japonca başlık: 彼女、お借りします × てんぷる コラボミニアニメ
   Tür/yıl: Anime / 2023
   Kaynak: anilist
   Harici kimlikler: Anime:mal:56172
   Ham kimlik alanları: MAL ID=56172 (MAL), AniList kayıt ID=600509588, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=4/4, cilt=0, puan=10
   Tarihler: başlangıç=2026-10-04, bitiş=2026-10-04; favori=false
   
   
   Başlık: Temple x Kanojo, Okarishimasu
   Japonca başlık: てんぷる×彼女お借りします
   Tür/yıl: Anime / 2023
   Kaynak: mal
   Harici kimlikler: Anime:mal:56172
   Ham kimlik alanları: MAL ID=56172 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=4/4, cilt=0, puan=10
   Tarihler: başlangıç=2026-10-04, bitiş=2026-10-04; favori=false
   
   
   Başlık: Temple x Kanojo, Okarishimasu Collab Mini Anime
   İngilizce başlık: TenPuru x Rent-a-Girlfriend Collab Mini Anime
   Japonca başlık: てんぷる×彼女お借りします
   Tür/yıl: Anime / 2023
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:47846
   Ham kimlik alanları: MAL ID=300047846 (dahili Kitsu kimliği, MAL değil: Kitsu #47846), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=4/4, cilt=0, puan=10
   Tarihler: başlangıç=2026-10-04, bitiş=2026-10-04; favori=false
   
   
   Başlık: Temple x Kanojo, Okarishimasu
   Tür/yıl: Anime / 2023
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:56172, Anime:shikimori:56172
   Ham kimlik alanları: MAL ID=56172 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=4/4, cilt=0, puan=10
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 100 · UYARI · Eşleştirme

- Rapor satırları: `7127–7192`
- Zaman: `2026-10-24 16:21:45.418 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `2600`

```text
100. [2026-10-24 16:21:45.418 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: SYNDUALITY Noir Part 2
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: SYNDUALITY Noir Part 2
   İngilizce başlık: Synduality Noir Part 2
   Japonca başlık: SYNDUALITY Noir 第2クール
   Tür/yıl: Anime / 2024
   Kaynak: anilist
   Harici kimlikler: Anime:mal:56731
   Ham kimlik alanları: MAL ID=56731 (MAL), AniList kayıt ID=495061269, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=8
   Tarihler: başlangıç=2025-02-21, bitiş=2025-02-21; favori=true
   
   
   Başlık: Synduality: Noir Part 2
   Japonca başlık: SYNDUALITY Noir 第2クール
   Tür/yıl: Anime / 2024
   Kaynak: mal
   Harici kimlikler: Anime:mal:56731
   Ham kimlik alanları: MAL ID=56731 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=8
   Tarihler: başlangıç=2025-02-21, bitiş=2025-02-21; favori=false
   
   
   Başlık: Synduality Noir
   Tür/yıl: Anime / 2024
   Kaynak: simkl
   Harici kimlikler: Anime:mal:56731, Anime:simkl:2263618
   Ham kimlik alanları: MAL ID=56731 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=2263618, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=8
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Synduality: Noir Part 2
   Japonca başlık: SYNDUALITY Noir 第2クール
   Tür/yıl: Anime / 2024
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:47999
   Ham kimlik alanları: MAL ID=300047999 (dahili Kitsu kimliği, MAL değil: Kitsu #47999), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=8
   Tarihler: başlangıç=2023-03-10, bitiş=2025-02-21; favori=false
   
   
   Başlık: Synduality: Noir Part 2
   Tür/yıl: Anime / 2024
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:56731, Anime:shikimori:56731
   Ham kimlik alanları: MAL ID=56731 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=8
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: SYNDUALITY Noir 第2クール
   Japonca başlık: SYNDUALITY Noir 第2クール
   Tür/yıl: Anime / 2024
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:456042
   Ham kimlik alanları: MAL ID=500456042 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=8
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 101 · UYARI · Eşleştirme

- Rapor satırları: `7194–7261`
- Zaman: `2026-10-24 16:21:46.811 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `2618`

```text
101. [2026-10-24 16:21:46.811 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Dungeon ni Deai wo Motomeru no wa Machigatteiru Darou ka V: Houjou no Megami-hen
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: Dungeon ni Deai wo Motomeru no wa Machigatteiru Darou ka V: Houjou no Megami-hen
   İngilizce başlık: Is It Wrong To Try To Pick Up Girls in a Dungeon? V
   Japonca başlık: ダンジョンに出会いを求めるのは間違っているだろうかⅤ 豊穣の女神篇
   Tür/yıl: Anime / 2024
   Kaynak: anilist
   Harici kimlikler: Anime:mal:57066
   Ham kimlik alanları: MAL ID=57066 (MAL), AniList kayıt ID=495060905, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=15/15, cilt=0, puan=10
   Tarihler: başlangıç=2026-10-04, bitiş=2026-10-07; favori=false
   
   
   Başlık: Dungeon ni Deai wo Motomeru no wa Machigatteiru Darou ka V: Houjou no Megami-hen
   İngilizce başlık: Is It Wrong to Try to Pick Up Girls in a Dungeon? V
   Japonca başlık: ダンジョンに出会いを求めるのは間違っているだろうかV 豊穣の女神篇
   Tür/yıl: Anime / 2024
   Kaynak: mal
   Harici kimlikler: Anime:mal:57066
   Ham kimlik alanları: MAL ID=57066 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=15/15, cilt=0, puan=10
   Tarihler: başlangıç=2026-10-04, bitiş=2026-10-07; favori=false
   
   
   Başlık: Dungeon ni Deai o Motomeru no wa Machigatte Iru Darouka: Familia Myth V
   Tür/yıl: Anime / 2024
   Kaynak: simkl
   Harici kimlikler: Anime:mal:57066, Anime:simkl:2282064
   Ham kimlik alanları: MAL ID=57066 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=2282064, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=15/15, cilt=0, puan=10
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Dungeon ni Deai o Motomeru no wa Machigatteiru Darou ka V: Houjou no Megami-hen
   İngilizce başlık: Is It Wrong to Try to Pick Up Girls in a Dungeon? V: Goddess of the Harvest Arc
   Japonca başlık: ダンジョンに出会いを求めるのは間違っているだろうか V 豊穣の女神篇
   Tür/yıl: Anime / 2024
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:48216
   Ham kimlik alanları: MAL ID=300048216 (dahili Kitsu kimliği, MAL değil: Kitsu #48216), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=15/15, cilt=0, puan=10
   Tarihler: başlangıç=2025-10-28, bitiş=2025-10-29; favori=false
   
   
   Başlık: Dungeon ni Deai wo Motomeru no wa Machigatteiru Darou ka V: Houjou no Megami-hen
   Tür/yıl: Anime / 2024
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:57066, Anime:shikimori:57066
   Ham kimlik alanları: MAL ID=57066 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=15/15, cilt=0, puan=10
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: ダンジョンに出会いを求めるのは間違っているだろうかⅤ 豊穣の女神篇
   Japonca başlık: ダンジョンに出会いを求めるのは間違っているだろうかⅤ 豊穣の女神篇
   Tür/yıl: Anime / 2024
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:463778
   Ham kimlik alanları: MAL ID=500463778 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=15/15, cilt=0, puan=10
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 102 · HATA · AniList

- Rapor satırları: `7263–7344`
- Zaman: `2026-10-24 16:21:47.303 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `update_error` / `identity_unverified`
- Tüm olay no: `2622`

```text
102. [2026-10-24 16:21:47.303 GMT+03:00] [HATA] [AniList] [AniList] ! Güncellenemedi: 悶えてよ、アダムくん
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Hata: java.lang.IllegalStateException: AniList liste kaydının bu medya ile eşleştiği doğrulanamadı: 悶えてよ、アダムくん
     at com.kitsugi.animelist.data.auth.AniListSyncManager.updateAniListEntry(?:718)
     at com.kitsugi.animelist.data.auth.AniListSyncManager.updateAniListEntry$default(?:40)
     at c7.r1.invokeSuspend(?:26941)
     at kotlin.coroutines.jvm.internal.BaseContinuationImpl.resumeWith(?:11)
     at kotlinx.coroutines.UndispatchedCoroutine.afterResume(?:30)
     at kotlinx.coroutines.AbstractCoroutine.resumeWith(?:13)
   
   Kaynak platform kayıtları (5):
   Kayıt 1:
   Başlık: Modaete yo, Adam-kun
   İngilizce başlık: Adam's Sweet Agony
   Japonca başlık: 悶えてよ、アダムくん
   Tür/yıl: Anime / 2024
   Kaynak: anilist
   Harici kimlikler: Anime:mal:57470
   Ham kimlik alanları: MAL ID=57470 (MAL), AniList kayıt ID=495061121, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=8/8, cilt=0, puan=7
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 2:
   Başlık: Modaete yo, Adam-kun
   İngilizce başlık: Adam's Sweet Agony
   Japonca başlık: 悶えてよ、アダムくん
   Tür/yıl: Anime / 2023
   Kaynak: mal
   Harici kimlikler: Anime:mal:57470
   Ham kimlik alanları: MAL ID=57470 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=8/8, cilt=0, puan=7
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 3:
   Başlık: Modaete yo, Adam-kun
   İngilizce başlık: Adam's Sweet Agony
   Japonca başlık: 悶えてよ、アダムくん
   Tür/yıl: Anime / 2023
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:48295
   Ham kimlik alanları: MAL ID=300048295 (dahili Kitsu kimliği, MAL değil: Kitsu #48295), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=8/8, cilt=0, puan=7
   Tarihler: başlangıç=2026-10-07, bitiş=2026-10-07; favori=false
   
   Kayıt 4:
   Başlık: Modaete yo, Adam-kun
   Tür/yıl: Anime / 2023
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:57470, Anime:shikimori:57470
   Ham kimlik alanları: MAL ID=57470 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=8/8, cilt=0, puan=7
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 5:
   Başlık: 悶えてよ、アダムくん
   Japonca başlık: 悶えてよ、アダムくん
   Tür/yıl: Anime / 2024
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:469072
   Ham kimlik alanları: MAL ID=500469072 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=8/8, cilt=0, puan=7
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Eşitleme için birleştirilen değerler:
   Başlık: 悶えてよ、アダムくん
   İngilizce başlık: Adam's Sweet Agony
   Japonca başlık: 悶えてよ、アダムくん
   Tür/yıl: Anime / 2024
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:57470
   Ham kimlik alanları: MAL ID=57470 (MAL), AniList kayıt ID=495061121, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=8/8, cilt=0, puan=7
   Tarihler: başlangıç=2026-10-07, bitiş=2026-10-07; favori=false
   
   Kimlik güvencesi: Güvenilir (MAL/Shikimori kaydının kendi kimliği)
```

## Sorun 103 · HATA · AniList

- Rapor satırları: `7346–7423`
- Zaman: `2026-10-24 16:21:49.133 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `update_error` / `identity_unverified`
- Tüm olay no: `2629`

```text
103. [2026-10-24 16:21:49.133 GMT+03:00] [HATA] [AniList] [AniList] ! Güncellenemedi: 69〜偽りの微笑〜
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Hata: java.lang.IllegalStateException: AniList liste kaydının bu medya ile eşleştiği doğrulanamadı: 69〜偽りの微笑〜
     at com.kitsugi.animelist.data.auth.AniListSyncManager.updateAniListEntry(?:718)
     at com.kitsugi.animelist.data.auth.AniListSyncManager.updateAniListEntry$default(?:40)
     at c7.r1.invokeSuspend(?:26941)
     at kotlin.coroutines.jvm.internal.BaseContinuationImpl.resumeWith(?:11)
     at kotlinx.coroutines.DispatchedTask.run(?:128)
     at kotlinx.coroutines.internal.LimitedDispatcher$Worker.run(?:3)
   
   Kaynak platform kayıtları (5):
   Kayıt 1:
   Başlık: 69: Itsuwari no Hohoe
   Japonca başlık: ６９〜偽りの微笑〜
   Tür/yıl: Anime / 2024
   Kaynak: anilist
   Harici kimlikler: Anime:mal:57860
   Ham kimlik alanları: MAL ID=57860 (MAL), AniList kayıt ID=495060813, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=2/2, cilt=0, puan=6
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 2:
   Başlık: 69: Itsuwari no Bishou
   Japonca başlık: 69~偽りの微笑~
   Tür/yıl: Anime / 2024
   Kaynak: mal
   Harici kimlikler: Anime:mal:57860
   Ham kimlik alanları: MAL ID=57860 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=2/2, cilt=0, puan=6
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 3:
   Başlık: 69: Itsuwari no Bishou
   Japonca başlık: 69~偽りの微笑~
   Tür/yıl: Anime / 2024
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:48675
   Ham kimlik alanları: MAL ID=300048675 (dahili Kitsu kimliği, MAL değil: Kitsu #48675), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=2/2, cilt=0, puan=6
   Tarihler: başlangıç=2026-10-07, bitiş=2026-10-07; favori=false
   
   Kayıt 4:
   Başlık: 69: Itsuwari no Bishou
   Tür/yıl: Anime / 2024
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:57860, Anime:shikimori:57860
   Ham kimlik alanları: MAL ID=57860 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=2/2, cilt=0, puan=6
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 5:
   Başlık: 69〜偽りの微笑〜
   Japonca başlık: 69〜偽りの微笑〜
   Tür/yıl: Anime / 2024
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:467344
   Ham kimlik alanları: MAL ID=500467344 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=2/2, cilt=0, puan=6
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Eşitleme için birleştirilen değerler:
   Başlık: 69〜偽りの微笑〜
   Japonca başlık: ６９〜偽りの微笑〜
   Tür/yıl: Anime / 2024
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:57860
   Ham kimlik alanları: MAL ID=57860 (MAL), AniList kayıt ID=495060813, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=2/2, cilt=0, puan=6
   Tarihler: başlangıç=2026-10-07, bitiş=2026-10-07; favori=false
   
   Kimlik güvencesi: Güvenilir (MAL/Shikimori kaydının kendi kimliği)
```

## Sorun 104 · UYARI · Eşleştirme

- Rapor satırları: `7425–7492`
- Zaman: `2026-10-24 16:21:52.321 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `2642`

```text
104. [2026-10-24 16:21:52.321 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Kimi no Koto ga Dai Dai Dai Dai Daisuki na 100-nin no Kanojo 2nd Season
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: Kimi no Koto ga Dai Dai Dai Dai Daisuki na 100-nin no Kanojo 2nd Season
   İngilizce başlık: The 100 Girlfriends Who Really, Really, Really, Really, REALLY Love You Season 2
   Japonca başlık: 君のことが大大大大大好きな100人の彼女 第2期
   Tür/yıl: Anime / 2025
   Kaynak: anilist
   Harici kimlikler: Anime:mal:57616
   Ham kimlik alanları: MAL ID=57616 (MAL), AniList kayıt ID=495061036, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Kimi no Koto ga Daidaidaidaidaisuki na 100-nin no Kanojo 2nd Season
   İngilizce başlık: The 100 Girlfriends Who Really, Really, Really, Really, Really Love You Season 2
   Japonca başlık: 君のことが大大大大大好きな100人の彼女 2期
   Tür/yıl: Anime / 2025
   Kaynak: mal
   Harici kimlikler: Anime:mal:57616
   Ham kimlik alanları: MAL ID=57616 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Kimi no Koto ga Dai Dai Dai Dai Daisuki na Hyakunin no Kanojo
   Tür/yıl: Anime / 2025
   Kaynak: simkl
   Harici kimlikler: Anime:mal:57616, Anime:simkl:2330428
   Ham kimlik alanları: MAL ID=57616 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=2330428, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Kimi no Koto ga Daidaidaidaidaisuki na 100-nin no Kanojo 2nd Season
   İngilizce başlık: The 100 Girlfriends Who Really, Really, Really, Really, REALLY Love You Season 2
   Japonca başlık: 君のことが大大大大大好きな100人の彼女 2期
   Tür/yıl: Anime / 2025
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:48348
   Ham kimlik alanları: MAL ID=300048348 (dahili Kitsu kimliği, MAL değil: Kitsu #48348), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Kimi no Koto ga Daidaidaidaidaisuki na 100-nin no Kanojo 2nd Season
   Tür/yıl: Anime / 2025
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:57616, Anime:shikimori:57616
   Ham kimlik alanları: MAL ID=57616 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: 君のことが大大大大大好きな100人の彼女 第2期
   Japonca başlık: 君のことが大大大大大好きな100人の彼女 第2期
   Tür/yıl: Anime / 2025
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:471793
   Ham kimlik alanları: MAL ID=500471793 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 105 · UYARI · Eşleştirme

- Rapor satırları: `7494–7552`
- Zaman: `2026-10-24 16:21:52.338 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `2663`

```text
105. [2026-10-24 16:21:52.338 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Itsuwari no Kotowari
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: Itsuwari no Kotowari
   İngilizce başlık: no rhyme nor reason
   Japonca başlık: 偽りの理
   Tür/yıl: Anime / 2023
   Kaynak: anilist
   Harici kimlikler: Anime:mal:55987
   Ham kimlik alanları: MAL ID=55987 (MAL), AniList kayıt ID=600509865, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Itsuwari no Kotowari
   İngilizce başlık: No Rhyme Nor Reason
   Japonca başlık: 偽りの理
   Tür/yıl: Anime / 2023
   Kaynak: mal
   Harici kimlikler: Anime:mal:55987
   Ham kimlik alanları: MAL ID=55987 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Itsuwari no Kotowari
   İngilizce başlık: No Rhyme Nor Reason
   Japonca başlık: 偽りの理
   Tür/yıl: Anime / 2023
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:48755
   Ham kimlik alanları: MAL ID=300048755 (dahili Kitsu kimliği, MAL değil: Kitsu #48755), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Itsuwari no Kotowari
   Tür/yıl: Anime / 2023
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:55987, Anime:shikimori:55987
   Ham kimlik alanları: MAL ID=55987 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: 火星西路7号
   Japonca başlık: 火星西路7号
   Tür/yıl: Anime / 2023
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:358564
   Ham kimlik alanları: MAL ID=500358564 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 106 · HATA · AniList

- Rapor satırları: `7554–7644`
- Zaman: `2026-10-24 16:21:52.525 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `update_error` / `identity_unverified`
- Tüm olay no: `2669`

```text
106. [2026-10-24 16:21:52.525 GMT+03:00] [HATA] [AniList] [AniList] ! Güncellenemedi: しかのこのこのここしたんたん
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Hata: java.lang.IllegalStateException: AniList liste kaydının bu medya ile eşleştiği doğrulanamadı: しかのこのこのここしたんたん
     at com.kitsugi.animelist.data.auth.AniListSyncManager.updateAniListEntry(?:718)
     at com.kitsugi.animelist.data.auth.AniListSyncManager.updateAniListEntry$default(?:40)
     at c7.r1.invokeSuspend(?:26941)
     at kotlin.coroutines.jvm.internal.BaseContinuationImpl.resumeWith(?:11)
     at kotlinx.coroutines.DispatchedTask.run(?:128)
     at kotlinx.coroutines.internal.LimitedDispatcher$Worker.run(?:3)
   
   Kaynak platform kayıtları (6):
   Kayıt 1:
   Başlık: Shikanoko Nokonoko Koshitantan
   İngilizce başlık: My Deer Friend Nokotan
   Japonca başlık: しかのこのこのここしたんたん
   Tür/yıl: Anime / 2024
   Kaynak: anilist
   Harici kimlikler: Anime:mal:58426
   Ham kimlik alanları: MAL ID=58426 (MAL), AniList kayıt ID=495061223, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: İzleniyor, bölüm=1/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 2:
   Başlık: Shikanoko Nokonoko Koshitantan
   İngilizce başlık: My Deer Friend Nokotan
   Japonca başlık: しかのこのこのここしたんたん
   Tür/yıl: Anime / 2024
   Kaynak: mal
   Harici kimlikler: Anime:mal:58426
   Ham kimlik alanları: MAL ID=58426 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: İzleniyor, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=2025-02-21, bitiş=yok; favori=false
   
   Kayıt 3:
   Başlık: Shikanoko Nokonoko Koshitantan
   Tür/yıl: Anime / 2024
   Kaynak: simkl
   Harici kimlikler: Anime:mal:58426, Anime:simkl:2403434, Anime:tmdb:248866
   Ham kimlik alanları: MAL ID=58426 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=2403434, TMDB ID=248866
   Durum/ilerleme: İzleniyor, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 4:
   Başlık: Shikanoko Nokonoko Koshitantan
   İngilizce başlık: My Deer Friend Nokotan
   Japonca başlık: しかのこのこのここしたんたん
   Tür/yıl: Anime / 2024
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:48618
   Ham kimlik alanları: MAL ID=300048618 (dahili Kitsu kimliği, MAL değil: Kitsu #48618), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: İzleniyor, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=2025-02-21, bitiş=yok; favori=false
   
   Kayıt 5:
   Başlık: Shikanoko Nokonoko Koshitantan
   Tür/yıl: Anime / 2024
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:58426, Anime:shikimori:58426
   Ham kimlik alanları: MAL ID=58426 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: İzleniyor, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 6:
   Başlık: しかのこのこのここしたんたん
   Japonca başlık: しかのこのこのここしたんたん
   Tür/yıl: Anime / 2024
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:484761
   Ham kimlik alanları: MAL ID=500484761 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: İzleniyor, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Eşitleme için birleştirilen değerler:
   Başlık: しかのこのこのここしたんたん
   İngilizce başlık: My Deer Friend Nokotan
   Japonca başlık: しかのこのこのここしたんたん
   Tür/yıl: Anime / 2024
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:58426, Anime:simkl:2403434, Anime:tmdb:248866
   Ham kimlik alanları: MAL ID=58426 (MAL), AniList kayıt ID=495061223, MAL liste ID=yok, Simkl ID=2403434, TMDB ID=248866
   Durum/ilerleme: İzleniyor, bölüm=1/12, cilt=0, puan=yok
   Tarihler: başlangıç=2025-02-21, bitiş=yok; favori=false
   
   Kimlik güvencesi: Gerek yok (tüm hedef platformlarda kayıt zaten var)
```

## Sorun 107 · UYARI · Eşleştirme

- Rapor satırları: `7646–7713`
- Zaman: `2026-10-24 16:21:56.669 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `2677`

```text
107. [2026-10-24 16:21:56.669 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Kusuriya no Hitorigoto 2nd Season
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: Kusuriya no Hitorigoto 2nd Season
   İngilizce başlık: The Apothecary Diaries Season 2
   Japonca başlık: 薬屋のひとりごと 第2期
   Tür/yıl: Anime / 2025
   Kaynak: anilist
   Harici kimlikler: Anime:mal:58514
   Ham kimlik alanları: MAL ID=58514 (MAL), AniList kayıt ID=495061075, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/24, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Kusuriya no Hitorigoto 2nd Season
   İngilizce başlık: The Apothecary Diaries Season 2
   Japonca başlık: 薬屋のひとりごと 第2期
   Tür/yıl: Anime / 2025
   Kaynak: mal
   Harici kimlikler: Anime:mal:58514
   Ham kimlik alanları: MAL ID=58514 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/24, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Kusuriya no Hitorigoto
   Tür/yıl: Anime / 2025
   Kaynak: simkl
   Harici kimlikler: Anime:mal:58514, Anime:simkl:2413572
   Ham kimlik alanları: MAL ID=58514 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=2413572, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/24, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Kusuriya no Hitorigoto 2nd Season
   İngilizce başlık: The Apothecary Diaries Season 2
   Japonca başlık: 薬屋のひとりごと 第2期
   Tür/yıl: Anime / 2025
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:48649
   Ham kimlik alanları: MAL ID=300048649 (dahili Kitsu kimliği, MAL değil: Kitsu #48649), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/24, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Kusuriya no Hitorigoto 2nd Season
   Tür/yıl: Anime / 2025
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:58514, Anime:shikimori:58514
   Ham kimlik alanları: MAL ID=58514 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/24, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: 薬屋のひとりごと 第2期
   Japonca başlık: 薬屋のひとりごと 第2期
   Tür/yıl: Anime / 2025
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:486347
   Ham kimlik alanları: MAL ID=500486347 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/24, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 108 · HATA · AniList

- Rapor satırları: `7715–7792`
- Zaman: `2026-10-24 16:21:56.865 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `update_error` / `identity_unverified`
- Tüm olay no: `2679`

```text
108. [2026-10-24 16:21:56.865 GMT+03:00] [HATA] [AniList] [AniList] ! Güncellenemedi: セフレのセンパイ THE ANIMATION
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Hata: java.lang.IllegalStateException: AniList liste kaydının bu medya ile eşleştiği doğrulanamadı: セフレのセンパイ THE ANIMATION
     at com.kitsugi.animelist.data.auth.AniListSyncManager.updateAniListEntry(?:718)
     at com.kitsugi.animelist.data.auth.AniListSyncManager.updateAniListEntry$default(?:40)
     at c7.r1.invokeSuspend(?:26941)
     at kotlin.coroutines.jvm.internal.BaseContinuationImpl.resumeWith(?:11)
     at kotlinx.coroutines.UndispatchedCoroutine.afterResume(?:30)
     at kotlinx.coroutines.AbstractCoroutine.resumeWith(?:13)
   
   Kaynak platform kayıtları (5):
   Kayıt 1:
   Başlık: Sefure no Senpai THE ANIMATION
   Japonca başlık: セフレのセンパイ THE ANIMATION
   Tür/yıl: Anime / 2024
   Kaynak: anilist
   Harici kimlikler: Anime:mal:58564
   Ham kimlik alanları: MAL ID=58564 (MAL), AniList kayıt ID=495061222, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=2/2, cilt=0, puan=7
   Tarihler: başlangıç=2025-04-20, bitiş=yok; favori=false
   
   Kayıt 2:
   Başlık: Sexfriend no Senpai The Animation
   Japonca başlık: セフレのセンパイ THE ANIMATION
   Tür/yıl: Anime / 2024
   Kaynak: mal
   Harici kimlikler: Anime:mal:58564
   Ham kimlik alanları: MAL ID=58564 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=2/2, cilt=0, puan=7
   Tarihler: başlangıç=2025-04-20, bitiş=yok; favori=false
   
   Kayıt 3:
   Başlık: Sexfriend no Senpai The Animation
   Japonca başlık: セフレのセンパイ THE ANIMATION
   Tür/yıl: Anime / 2024
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:48721
   Ham kimlik alanları: MAL ID=300048721 (dahili Kitsu kimliği, MAL değil: Kitsu #48721), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=2/2, cilt=0, puan=7
   Tarihler: başlangıç=2025-04-20, bitiş=2026-10-07; favori=false
   
   Kayıt 4:
   Başlık: Sexfriend no Senpai The Animation
   Tür/yıl: Anime / 2024
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:58564, Anime:shikimori:58564
   Ham kimlik alanları: MAL ID=58564 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=2/2, cilt=0, puan=7
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 5:
   Başlık: セフレのセンパイ THE ANIMATION
   Japonca başlık: セフレのセンパイ THE ANIMATION
   Tür/yıl: Anime / 2024
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:486704
   Ham kimlik alanları: MAL ID=500486704 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=2/2, cilt=0, puan=7
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Eşitleme için birleştirilen değerler:
   Başlık: セフレのセンパイ THE ANIMATION
   Japonca başlık: セフレのセンパイ THE ANIMATION
   Tür/yıl: Anime / 2024
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:58564
   Ham kimlik alanları: MAL ID=58564 (MAL), AniList kayıt ID=495061222, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=2/2, cilt=0, puan=7
   Tarihler: başlangıç=2025-04-20, bitiş=2026-10-07; favori=false
   
   Kimlik güvencesi: Güvenilir (MAL/Shikimori kaydının kendi kimliği)
```

## Sorun 109 · UYARI · Eşleştirme

- Rapor satırları: `7794–7843`
- Zaman: `2026-10-24 16:21:57.480 GMT+03:00`
- Kod: `—`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `2681`

```text
109. [2026-10-24 16:21:57.480 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Ore dake Level Up na Ken: Season 2 - Arise from the Shadow
   Başlık: Ore dake Level Up na Ken: Season 2 - Arise from the Shadow
   İngilizce başlık: Solo Leveling Season 2 -Arise from the Shadow-
   Japonca başlık: 俺だけレベルアップな件 Season 2 -Arise from the Shadow-
   Tür/yıl: Anime / 2025
   Kaynak: anilist
   Harici kimlikler: Anime:mal:58567
   Ham kimlik alanları: MAL ID=58567 (MAL), AniList kayıt ID=495061164, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=13/13, cilt=0, puan=10
   Tarihler: başlangıç=2025-05-09, bitiş=2025-05-09; favori=false
   
   
   Başlık: Ore dake Level Up na Ken Season 2: Arise from the Shadow
   İngilizce başlık: Solo Leveling Season 2: Arise from the Shadow
   Japonca başlık: 俺だけレベルアップな件 Season 2 -Arise from the Shadow-
   Tür/yıl: Anime / 2025
   Kaynak: mal
   Harici kimlikler: Anime:mal:58567
   Ham kimlik alanları: MAL ID=58567 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=13/13, cilt=0, puan=10
   Tarihler: başlangıç=2025-05-09, bitiş=2025-05-09; favori=false
   
   
   Başlık: Ore dake Level Up na Ken: Arise from the Shadow
   Tür/yıl: Anime / 2025
   Kaynak: simkl
   Harici kimlikler: Anime:mal:58567, Anime:simkl:2419656
   Ham kimlik alanları: MAL ID=58567 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=2419656, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=13/13, cilt=0, puan=10
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Ore dake Level Up na Ken: Season 2 - Arise from the Shadow
   İngilizce başlık: Solo Leveling Season 2 -Arise from the Shadow-
   Japonca başlık: 俺だけレベルアップな件 Season 2 -Arise from the Shadow-
   Tür/yıl: Anime / 2025
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:48671
   Ham kimlik alanları: MAL ID=300048671 (dahili Kitsu kimliği, MAL değil: Kitsu #48671), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=13/13, cilt=0, puan=10
   Tarihler: başlangıç=2025-06-06, bitiş=2026-07-20; favori=false
   
   
   Başlık: Ore dake Level Up na Ken Season 2: Arise from the Shadow
   Tür/yıl: Anime / 2025
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:58567, Anime:shikimori:58567
   Ham kimlik alanları: MAL ID=58567 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=13/13, cilt=0, puan=10
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 110 · UYARI · Eşleştirme

- Rapor satırları: `7845–7912`
- Zaman: `2026-10-24 16:21:59.190 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `2696`

```text
110. [2026-10-24 16:21:59.190 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Tensei Shitara Dai Nana Ouji Datta node, Kimamani Majutsu wo Kiwamemasu 2nd Season
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: Tensei Shitara Dai Nana Ouji Datta node, Kimamani Majutsu wo Kiwamemasu 2nd Season
   İngilizce başlık: I Was Reincarnated as the 7th Prince so I Can Take My Time Perfecting My Magical Ability Season 2
   Japonca başlık: 転生したら第七王子だったので、気ままに魔術を極めます 第2期
   Tür/yıl: Anime / 2025
   Kaynak: anilist
   Harici kimlikler: Anime:mal:59095
   Ham kimlik alanları: MAL ID=59095 (MAL), AniList kayıt ID=600509557, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: İzleniyor, bölüm=4/12, cilt=0, puan=yok
   Tarihler: başlangıç=2025-05-19, bitiş=yok; favori=false
   
   
   Başlık: Tensei shitara Dainana Ouji Datta node, Kimama ni Majutsu wo Kiwamemasu 2nd Season
   İngilizce başlık: I Was Reincarnated as the 7th Prince so I Can Take My Time Perfecting My Magical Ability Season 2
   Japonca başlık: 転生したら第七王子だったので、気ままに魔術を極めます 第2期
   Tür/yıl: Anime / 2025
   Kaynak: mal
   Harici kimlikler: Anime:mal:59095
   Ham kimlik alanları: MAL ID=59095 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: İzleniyor, bölüm=4/12, cilt=0, puan=yok
   Tarihler: başlangıç=2025-05-19, bitiş=yok; favori=false
   
   
   Başlık: Tensei Shitara Dai Nana Ouji Datta no de, Kimama ni Majutsu o Kiwamemasu Dai 2 Ki
   Tür/yıl: Anime / 2025
   Kaynak: simkl
   Harici kimlikler: Anime:mal:59095, Anime:simkl:2494340
   Ham kimlik alanları: MAL ID=59095 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=2494340, TMDB ID=yok
   Durum/ilerleme: İzleniyor, bölüm=4/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Tensei Shitara Dai Nana Ouji Dattanode, Kimamani Majutsu wo Kiwamemasu 2nd Season
   İngilizce başlık: I Was Reincarnated as the 7th Prince So I Can Take My Time Perfecting My Magical Ability Season 2
   Japonca başlık: 転生したら第七王子だったので、気ままに魔術を極めます 第2期
   Tür/yıl: Anime / 2025
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:48968
   Ham kimlik alanları: MAL ID=300048968 (dahili Kitsu kimliği, MAL değil: Kitsu #48968), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: İzleniyor, bölüm=4/12, cilt=0, puan=yok
   Tarihler: başlangıç=2025-05-19, bitiş=yok; favori=false
   
   
   Başlık: Tensei shitara Dainana Ouji Datta node, Kimama ni Majutsu wo Kiwamemasu 2nd Season
   Tür/yıl: Anime / 2025
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:59095, Anime:shikimori:59095
   Ham kimlik alanları: MAL ID=59095 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: İzleniyor, bölüm=4/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: 転生したら第七王子だったので、気ままに魔術を極めます 第2期
   Japonca başlık: 転生したら第七王子だったので、気ままに魔術を極めます 第2期
   Tür/yıl: Anime / 2025
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:499656
   Ham kimlik alanları: MAL ID=500499656 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: İzleniyor, bölüm=4/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 111 · UYARI · Eşleştirme

- Rapor satırları: `7914–7981`
- Zaman: `2026-10-24 16:21:59.199 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `2705`

```text
111. [2026-10-24 16:21:59.199 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Kaijuu 8-gou 2nd Season
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: Kaijuu 8-gou 2nd Season
   İngilizce başlık: Kaiju No. 8 Season 2
   Japonca başlık: 怪獣８号 第２期
   Tür/yıl: Anime / 2025
   Kaynak: anilist
   Harici kimlikler: Anime:mal:59177
   Ham kimlik alanları: MAL ID=59177 (MAL), AniList kayıt ID=605691604, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: İzleniyor, bölüm=1/11, cilt=0, puan=yok
   Tarihler: başlangıç=2026-10-24, bitiş=yok; favori=false
   
   
   Başlık: Kaijuu 8-gou 2nd Season
   İngilizce başlık: Kaiju No. 8 Season 2
   Japonca başlık: 怪獣8号 第2期
   Tür/yıl: Anime / 2025
   Kaynak: mal
   Harici kimlikler: Anime:mal:59177
   Ham kimlik alanları: MAL ID=59177 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: İzleniyor, bölüm=1/11, cilt=0, puan=yok
   Tarihler: başlangıç=2026-10-24, bitiş=yok; favori=false
   
   
   Başlık: Kaijuu 8 Gou
   Tür/yıl: Anime / 2025
   Kaynak: simkl
   Harici kimlikler: Anime:mal:59177, Anime:simkl:2532478
   Ham kimlik alanları: MAL ID=59177 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=2532478, TMDB ID=yok
   Durum/ilerleme: İzleniyor, bölüm=1/11, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Kaijuu 8-gou 2nd Season
   İngilizce başlık: Kaiju No.8 Season 2
   Japonca başlık: 怪獣８号 第２期
   Tür/yıl: Anime / 2025
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:48994
   Ham kimlik alanları: MAL ID=300048994 (dahili Kitsu kimliği, MAL değil: Kitsu #48994), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: İzleniyor, bölüm=1/11, cilt=0, puan=yok
   Tarihler: başlangıç=2026-10-24, bitiş=yok; favori=false
   
   
   Başlık: Kaijuu 8-gou 2nd Season
   Tür/yıl: Anime / 2025
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:59177, Anime:shikimori:59177
   Ham kimlik alanları: MAL ID=59177 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: İzleniyor, bölüm=1/11, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Kaiju No. 8 Season 2
   Japonca başlık: 怪獣8号 第2期
   Tür/yıl: Anime / 2025
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:501844
   Ham kimlik alanları: MAL ID=500501844 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: İzleniyor, bölüm=1/11, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 112 · UYARI · Eşleştirme

- Rapor satırları: `7983–8050`
- Zaman: `2026-10-24 16:21:59.200 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `2706`

```text
112. [2026-10-24 16:21:59.200 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Kimetsu no Yaiba: Mugenjou-hen Movie 1 - Akaza Sairai
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: Kimetsu no Yaiba: Mugenjou-hen Movie 1 - Akaza Sairai
   İngilizce başlık: Demon Slayer: Kimetsu no Yaiba Infinity Castle
   Japonca başlık: 劇場版「鬼滅の刃」無限城編 第一章 猗窩座再来
   Tür/yıl: Anime / 2025
   Kaynak: anilist
   Harici kimlikler: Anime:mal:59192
   Ham kimlik alanları: MAL ID=59192 (MAL), AniList kayıt ID=604892448, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=yok
   Tarihler: başlangıç=2026-10-20, bitiş=2026-10-20; favori=false
   
   
   Başlık: Kimetsu no Yaiba Movie 1: Mugenjou-hen - Akaza Sairai
   İngilizce başlık: Demon Slayer: Kimetsu no Yaiba Infinity Castle I
   Japonca başlık: 劇場版 鬼滅の刃 無限城編 第一章 猗窩座再来
   Tür/yıl: Anime / 2025
   Kaynak: mal
   Harici kimlikler: Anime:mal:59192
   Ham kimlik alanları: MAL ID=59192 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=yok
   Tarihler: başlangıç=2026-10-20, bitiş=2026-10-20; favori=false
   
   
   Başlık: Gekijouban Kimetsu no Yaiba: Mugen-jou Hen
   Tür/yıl: Anime / 2025
   Kaynak: simkl
   Harici kimlikler: Anime:mal:59192, Anime:simkl:2498112, Anime:tmdb:1311031
   Ham kimlik alanları: MAL ID=59192 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=2498112, TMDB ID=1311031
   Durum/ilerleme: İzleniyor, bölüm=1/3, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Kimetsu no Yaiba: Mugenjou-hen Movie 1 - Akaza Sairai
   İngilizce başlık: Demon Slayer: Kimetsu no Yaiba - Infinity Castle - Part 1: Akaza Returns
   Japonca başlık: 劇場版「鬼滅の刃」無限城編 第一章 猗窩座再来
   Tür/yıl: Anime / 2025
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:49001
   Ham kimlik alanları: MAL ID=300049001 (dahili Kitsu kimliği, MAL değil: Kitsu #49001), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=yok
   Tarihler: başlangıç=2026-10-20, bitiş=2026-10-20; favori=false
   
   
   Başlık: Kimetsu no Yaiba Movie 1: Mugenjou-hen - Akaza Sairai
   Tür/yıl: Anime / 2025
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:59192, Anime:shikimori:59192
   Ham kimlik alanları: MAL ID=59192 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: 劇場版 鬼滅の刃 無限城編 第一章 猗窩座再来
   Japonca başlık: 劇場版 鬼滅の刃 無限城編 第一章 猗窩座再来
   Tür/yıl: Anime / 2025
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:501958
   Ham kimlik alanları: MAL ID=500501958 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=1/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 113 · UYARI · Eşleştirme

- Rapor satırları: `8052–8119`
- Zaman: `2026-10-24 16:21:59.205 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `2713`

```text
113. [2026-10-24 16:21:59.205 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Kanojo, Okarishimasu 4th Season
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: Kanojo, Okarishimasu 4th Season
   İngilizce başlık: Rent-a-Girlfriend Season 4
   Japonca başlık: 彼女、お借りします 第4期
   Tür/yıl: Anime / 2025
   Kaynak: anilist
   Harici kimlikler: Anime:mal:59277
   Ham kimlik alanları: MAL ID=59277 (MAL), AniList kayıt ID=536965248, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Kanojo, Okarishimasu 4th Season
   İngilizce başlık: Rent-a-Girlfriend Season 4
   Japonca başlık: 彼女、お借りします 第4期
   Tür/yıl: Anime / 2025
   Kaynak: mal
   Harici kimlikler: Anime:mal:59277
   Ham kimlik alanları: MAL ID=59277 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Kanojo, Okarishimasu
   Tür/yıl: Anime / 2025
   Kaynak: simkl
   Harici kimlikler: Anime:mal:59277, Anime:simkl:2513586
   Ham kimlik alanları: MAL ID=59277 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=2513586, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Kanojo, Okarishimasu 4th Season
   İngilizce başlık: Rent-a-Girlfriend Season 4
   Japonca başlık: 彼女、お借りします 第4期
   Tür/yıl: Anime / 2025
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:49033
   Ham kimlik alanları: MAL ID=300049033 (dahili Kitsu kimliği, MAL değil: Kitsu #49033), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Kanojo, Okarishimasu 4th Season
   Tür/yıl: Anime / 2025
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:59277, Anime:shikimori:59277
   Ham kimlik alanları: MAL ID=59277 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: 彼女、お借りします 第4期
   Japonca başlık: 彼女、お借りします 第4期
   Tür/yıl: Anime / 2025
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:503450
   Ham kimlik alanları: MAL ID=500503450 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 114 · UYARI · Eşleştirme

- Rapor satırları: `8121–8179`
- Zaman: `2026-10-24 16:22:01.240 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `2729`

```text
114. [2026-10-24 16:22:01.240 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Silent Witch: Chinmoku no Majo no Kakushigoto
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: Silent Witch: Chinmoku no Majo no Kakushigoto
   İngilizce başlık: Secrets of the Silent Witch
   Japonca başlık: サイレント・ウィッチ 沈黙の魔女の隠しごと
   Tür/yıl: Anime / 2025
   Kaynak: anilist
   Harici kimlikler: Anime:mal:59459
   Ham kimlik alanları: MAL ID=59459 (MAL), AniList kayıt ID=495061242, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=13/13, cilt=0, puan=4
   Tarihler: başlangıç=2025-10-23, bitiş=2025-10-24; favori=false
   
   
   Başlık: Silent Witch: Chinmoku no Majo no Kakushigoto
   İngilizce başlık: Secrets of the Silent Witch
   Japonca başlık: サイレント・ウィッチ 沈黙の魔女の隠しごと
   Tür/yıl: Anime / 2025
   Kaynak: mal
   Harici kimlikler: Anime:mal:59459
   Ham kimlik alanları: MAL ID=59459 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=13/13, cilt=0, puan=4
   Tarihler: başlangıç=2025-10-23, bitiş=2025-10-24; favori=false
   
   
   Başlık: Silent Witch: Chinmoku no Majo no Kakushigoto
   İngilizce başlık: Secrets of the Silent Witch
   Japonca başlık: サイレント・ウィッチ 沈黙の魔女の隠しごと
   Tür/yıl: Anime / 2025
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:49097
   Ham kimlik alanları: MAL ID=300049097 (dahili Kitsu kimliği, MAL değil: Kitsu #49097), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=13/13, cilt=0, puan=4
   Tarihler: başlangıç=2026-10-04, bitiş=2026-10-04; favori=false
   
   
   Başlık: Silent Witch: Chinmoku no Majo no Kakushigoto
   Tür/yıl: Anime / 2025
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:59459, Anime:shikimori:59459
   Ham kimlik alanları: MAL ID=59459 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=13/13, cilt=0, puan=4
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: サイレント・ウィッチ 沈黙の魔女の隠しごと
   Japonca başlık: サイレント・ウィッチ 沈黙の魔女の隠しごと
   Tür/yıl: Anime / 2025
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:506677
   Ham kimlik alanları: MAL ID=500506677 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=13/13, cilt=0, puan=4
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 115 · UYARI · Eşleştirme

- Rapor satırları: `8181–8248`
- Zaman: `2026-10-24 16:22:01.247 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `2736`

```text
115. [2026-10-24 16:22:01.247 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Youkoso Jitsuryoku Shijou Shugi no Kyoushitsu e 4th Season 2-nensei-hen Ichi Gakki
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: Youkoso Jitsuryoku Shijou Shugi no Kyoushitsu e 4th Season 2-nensei-hen Ichi Gakki
   İngilizce başlık: Classroom of the Elite 4th Season: Second Year, First Semester
   Japonca başlık: ようこそ実力至上主義の教室へ 4th Season 2年生編1学期
   Tür/yıl: Anime / 2026
   Kaynak: anilist
   Harici kimlikler: Anime:mal:59708
   Ham kimlik alanları: MAL ID=59708 (MAL), AniList kayıt ID=551018016, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/16, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Youkoso Jitsuryoku Shijou Shugi no Kyoushitsu e 4th Season: 2-nensei-hen 1 Gakki
   İngilizce başlık: Classroom of the Elite 4th Season: Second Year, First Semester
   Japonca başlık: ようこそ実力至上主義の教室へ 4th Season 2年生編1学期
   Tür/yıl: Anime / 2026
   Kaynak: mal
   Harici kimlikler: Anime:mal:59708
   Ham kimlik alanları: MAL ID=59708 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/16, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Youkoso Jitsuryoku Shijou Shugi no Kyoushitsu e 4th Season 2 Nensei Hen 1 Gakki
   Tür/yıl: Anime / 2026
   Kaynak: simkl
   Harici kimlikler: Anime:mal:59708, Anime:simkl:2561864
   Ham kimlik alanları: MAL ID=59708 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=2561864, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/16, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Youkoso Jitsuryoku Shijou Shugi no Kyoushitsu e 4th Season: 2-nensei-hen 1 Gakki
   İngilizce başlık: Classroom of the Elite 4th Season: Second Year, First Semester
   Japonca başlık: ようこそ実力至上主義の教室へ 4th Season 2年生編1学期
   Tür/yıl: Anime / 2026
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:49194
   Ham kimlik alanları: MAL ID=300049194 (dahili Kitsu kimliği, MAL değil: Kitsu #49194), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/16, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Youkoso Jitsuryoku Shijou Shugi no Kyoushitsu e 4th Season: 2-nensei-hen 1 Gakki
   Tür/yıl: Anime / 2026
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:59708, Anime:shikimori:59708
   Ham kimlik alanları: MAL ID=59708 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/16, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: ようこそ実力至上主義の教室へ 4th Season
   Japonca başlık: ようこそ実力至上主義の教室へ 4th Season
   Tür/yıl: Anime / 2026
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:510710
   Ham kimlik alanları: MAL ID=500510710 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/16, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 116 · UYARI · Eşleştirme

- Rapor satırları: `8250–8317`
- Zaman: `2026-10-24 16:22:01.253 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `2745`

```text
116. [2026-10-24 16:22:01.253 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: [Oshi no Ko] 3rd Season
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: [Oshi no Ko] 3rd Season
   İngilizce başlık: OSHI NO KO Season 3
   Japonca başlık: 【推しの子】第3期
   Tür/yıl: Anime / 2026
   Kaynak: anilist
   Harici kimlikler: Anime:mal:60058
   Ham kimlik alanları: MAL ID=60058 (MAL), AniList kayıt ID=537659813, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/11, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: [Oshi no Ko] 3rd Season
   İngilizce başlık: [Oshi No Ko] Season 3
   Japonca başlık: 【推しの子】 第3期
   Tür/yıl: Anime / 2026
   Kaynak: mal
   Harici kimlikler: Anime:mal:60058
   Ham kimlik alanları: MAL ID=60058 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/11, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: "Oshi no Ko"
   Tür/yıl: Anime / 2026
   Kaynak: simkl
   Harici kimlikler: Anime:mal:60058, Anime:simkl:2601794
   Ham kimlik alanları: MAL ID=60058 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=2601794, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/11, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: [Oshi no Ko] 3rd Season
   İngilizce başlık: Oshi no Ko Season 3
   Japonca başlık: 【推しの子】第3期
   Tür/yıl: Anime / 2026
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:49264
   Ham kimlik alanları: MAL ID=300049264 (dahili Kitsu kimliği, MAL değil: Kitsu #49264), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/11, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: [Oshi no Ko] 3rd Season
   Tür/yıl: Anime / 2026
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:60058, Anime:shikimori:60058
   Ham kimlik alanları: MAL ID=60058 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/11, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: 【推しの子】 第3期
   Japonca başlık: 【推しの子】 第3期
   Tür/yıl: Anime / 2026
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:517057
   Ham kimlik alanları: MAL ID=500517057 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/11, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 117 · UYARI · Eşleştirme

- Rapor satırları: `8319–8386`
- Zaman: `2026-10-24 16:22:02.800 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `2760`

```text
117. [2026-10-24 16:22:02.800 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Dandadan 2nd Season
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: Dandadan 2nd Season
   İngilizce başlık: DAN DA DAN Season 2
   Japonca başlık: ダンダダン 第2期
   Tür/yıl: Anime / 2025
   Kaynak: anilist
   Harici kimlikler: Anime:mal:60543
   Ham kimlik alanları: MAL ID=60543 (MAL), AniList kayıt ID=495060883, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=8
   Tarihler: başlangıç=2026-10-04, bitiş=2026-10-04; favori=false
   
   
   Başlık: Dandadan 2nd Season
   İngilizce başlık: Dan Da Dan Season 2
   Japonca başlık: ダンダダン 第2期
   Tür/yıl: Anime / 2025
   Kaynak: mal
   Harici kimlikler: Anime:mal:60543
   Ham kimlik alanları: MAL ID=60543 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=8
   Tarihler: başlangıç=2026-10-04, bitiş=2026-10-04; favori=false
   
   
   Başlık: Dan Da Dan
   Tür/yıl: Anime / 2025
   Kaynak: simkl
   Harici kimlikler: Anime:mal:60543, Anime:simkl:2665178
   Ham kimlik alanları: MAL ID=60543 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=2665178, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=8
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Dandadan 2nd Season
   İngilizce başlık: DAN DA DAN Season 2
   Japonca başlık: ダンダダン 第2期
   Tür/yıl: Anime / 2025
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:49425
   Ham kimlik alanları: MAL ID=300049425 (dahili Kitsu kimliği, MAL değil: Kitsu #49425), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=8
   Tarihler: başlangıç=2025-10-05, bitiş=2025-10-06; favori=false
   
   
   Başlık: Dandadan 2nd Season
   Tür/yıl: Anime / 2025
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:60543, Anime:shikimori:60543
   Ham kimlik alanları: MAL ID=60543 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=8
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: ダンダダン 第2期
   Japonca başlık: ダンダダン 第2期
   Tür/yıl: Anime / 2025
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:529431
   Ham kimlik alanları: MAL ID=500529431 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=8
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 118 · UYARI · Eşleştirme

- Rapor satırları: `8388–8445`
- Zaman: `2026-10-24 16:22:02.804 GMT+03:00`
- Kod: `KTS-ANL-2004`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `2765`

```text
118. [2026-10-24 16:22:02.804 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Re:Zero kara Hajimeru Isekai Seikatsu 4th Season
   Kod: KTS-ANL-2004
   | KTS-ANL-2004 · ERROR · ANL
   | TR — AniList oturumu geçersiz
   | Neden: Erişim anahtarının süresi doldu ve yenileme reddedildi; istekler yetkisiz kaldı.
   | Çözüm: Ayarlar > Platformlar > AniList üzerinden yeniden giriş yapın.
   | EN — AniList session invalid
   | Why: The access token expired and the refresh was rejected, leaving requests unauthorised.
   | Fix: Sign in again via Settings > Platforms > AniList.
   Başlık: Re:Zero kara Hajimeru Isekai Seikatsu 4th Season
   İngilizce başlık: Re:ZERO -Starting Life in Another World- Season 4
   Japonca başlık: Re:ゼロから始める異世界生活 4th season
   Tür/yıl: Anime / 2026
   Kaynak: anilist
   Harici kimlikler: Anime:mal:61316
   Ham kimlik alanları: MAL ID=61316 (MAL), AniList kayıt ID=601604012, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=19/19, cilt=0, puan=8
   Tarihler: başlangıç=2026-10-18, bitiş=2026-10-19; favori=true
   
   
   Başlık: Re:Zero kara Hajimeru Isekai Seikatsu 4th Season
   İngilizce başlık: Re:ZERO -Starting Life in Another World- Season 4
   Japonca başlık: Re:ゼロから始める異世界生活 4th season
   Tür/yıl: Anime / 2026
   Kaynak: mal
   Harici kimlikler: Anime:mal:61316
   Ham kimlik alanları: MAL ID=61316 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=19/19, cilt=0, puan=8
   Tarihler: başlangıç=2026-10-18, bitiş=2026-10-19; favori=false
   
   
   Başlık: Re:Zero kara Hajimeru Isekai Seikatsu
   Tür/yıl: Anime / 2026
   Kaynak: simkl
   Harici kimlikler: Anime:mal:61316, Anime:simkl:2743422
   Ham kimlik alanları: MAL ID=61316 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=2743422, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=19/19, cilt=0, puan=8
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Re:Zero kara Hajimeru Isekai Seikatsu 4th Season
   İngilizce başlık: Re:ZERO -Starting Life in Another World- Season 4
   Japonca başlık: Re:ゼロから始める異世界生活 4th season
   Tür/yıl: Anime / 2026
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:49746
   Ham kimlik alanları: MAL ID=300049746 (dahili Kitsu kimliği, MAL değil: Kitsu #49746), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=19/19, cilt=0, puan=8
   Tarihler: başlangıç=2026-10-18, bitiş=2026-10-19; favori=false
   
   
   Başlık: Re:Zero kara Hajimeru Isekai Seikatsu 4th Season
   Tür/yıl: Anime / 2026
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:61316, Anime:shikimori:61316
   Ham kimlik alanları: MAL ID=61316 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=19/19, cilt=0, puan=8
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 119 · UYARI · Eşleştirme

- Rapor satırları: `8447–8514`
- Zaman: `2026-10-24 16:22:03.161 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `2781`

```text
119. [2026-10-24 16:22:03.161 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Kanojo, Okarishimasu 5th Season
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: Kanojo, Okarishimasu 5th Season
   İngilizce başlık: Rent-a-Girlfriend Season 5
   Japonca başlık: 彼女、お借りします 第5期
   Tür/yıl: Anime / 2026
   Kaynak: anilist
   Harici kimlikler: Anime:mal:62485
   Ham kimlik alanları: MAL ID=62485 (MAL), AniList kayıt ID=536965256, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Kanojo, Okarishimasu 5th Season
   İngilizce başlık: Rent-a-Girlfriend Season 5
   Japonca başlık: 彼女、お借りします 第5期
   Tür/yıl: Anime / 2026
   Kaynak: mal
   Harici kimlikler: Anime:mal:62485
   Ham kimlik alanları: MAL ID=62485 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Kanojo, Okarishimasu
   Tür/yıl: Anime / 2026
   Kaynak: simkl
   Harici kimlikler: Anime:mal:62485, Anime:simkl:2885502
   Ham kimlik alanları: MAL ID=62485 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=2885502, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Kanojo, Okarishimasu 5th Season
   İngilizce başlık: Rent-a-Girlfriend Season 5
   Japonca başlık: 彼女、お借りします 第5期
   Tür/yıl: Anime / 2026
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:50182
   Ham kimlik alanları: MAL ID=300050182 (dahili Kitsu kimliği, MAL değil: Kitsu #50182), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Kanojo, Okarishimasu 5th Season
   Tür/yıl: Anime / 2026
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:62485, Anime:shikimori:62485
   Ham kimlik alanları: MAL ID=62485 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: 彼女、お借りします 第5期
   Japonca başlık: 彼女、お借りします 第5期
   Tür/yıl: Anime / 2026
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:533027
   Ham kimlik alanları: MAL ID=500533027 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 120 · HATA · Bangumi

- Rapor satırları: `8516–8587`
- Zaman: `2026-10-24 16:22:04.820 GMT+03:00`
- Kod: `KTS-BGM-6001`
- İşlem / neden: `update_error` / `http_400_rejected`
- Tüm olay no: `2801`

```text
120. [2026-10-24 16:22:04.820 GMT+03:00] [HATA] [Bangumi] [Bangumi] ! Güncellenemedi: 五等分の花嫁【春夏秋冬】 (Bangumi bölüm ilerlemesi yazılamadı (五等分の花嫁【春夏秋冬】): Bangumi isteği reddetti (400): Accepted — /subject/646470/update/watched_eps?watched_eps=2— sunucu: Accepted — /subject/646470/update/watched_eps?watched_eps=2)
   Kod: KTS-BGM-6001
   | KTS-BGM-6001 · ERROR · BGM
   | TR — Bangumi parametre hatası (400)
   | Neden: Bangumi API'si `nsfw` filtresinin metin ("include") olarak gönderilmesini kabul etmez; JSON `null`/`true` bekler. Metin gönderilirse arama HTTP 400 ile tamamen boş döner.
   | Çözüm: Uygulama doğru JSON biçimini kullanır; hata sürüyorsa raporu paylaşın.
   | EN — Bangumi parameter error (400)
   | Why: The Bangumi API rejects the `nsfw` filter sent as a string ("include") and expects JSON `null`/`true`. Sending text makes the search return HTTP 400 and an empty result.
   | Fix: The app uses the correct JSON form; share the report if the error persists.
   Kaynak platform kayıtları (5):
   Kayıt 1:
   Başlık: Go-toubun no Hanayome: Shunkashuutou
   Japonca başlık: 五等分の花嫁【春夏秋冬】
   Tür/yıl: Anime / yok
   Kaynak: anilist
   Harici kimlikler: Anime:mal:64104
   Ham kimlik alanları: MAL ID=64104 (MAL), AniList kayıt ID=601324275, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=2/?, cilt=0, puan=6
   Tarihler: başlangıç=2026-10-06, bitiş=2026-10-06; favori=false
   
   Kayıt 2:
   Başlık: 5-toubun no Hanayome: [Shunkashuutou]
   Japonca başlık: 五等分の花嫁【春夏秋冬】
   Tür/yıl: Anime / yok
   Kaynak: mal
   Harici kimlikler: Anime:mal:64104
   Ham kimlik alanları: MAL ID=64104 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=2/?, cilt=0, puan=yok
   Tarihler: başlangıç=2026-10-06, bitiş=2026-10-06; favori=false
   
   Kayıt 3:
   Başlık: Go-toubun no Hanayome: Shunkashuutou
   Japonca başlık: 五等分の花嫁【春夏秋冬】
   Tür/yıl: Anime / yok
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:50699
   Ham kimlik alanları: MAL ID=300050699 (dahili Kitsu kimliği, MAL değil: Kitsu #50699), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=2/?, cilt=0, puan=6
   Tarihler: başlangıç=2026-10-06, bitiş=2026-10-06; favori=false
   
   Kayıt 4:
   Başlık: 5-toubun no Hanayome: [Shunkashuutou]
   Tür/yıl: Anime / yok
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:64104, Anime:shikimori:64104
   Ham kimlik alanları: MAL ID=64104 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=2/?, cilt=0, puan=6
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Kayıt 5:
   Başlık: 五等分の花嫁【春夏秋冬】
   Japonca başlık: 五等分の花嫁【春夏秋冬】
   Tür/yıl: Anime / yok
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:646470
   Ham kimlik alanları: MAL ID=500646470 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=0/?, cilt=0, puan=6
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   Eşitleme için birleştirilen değerler:
   Başlık: 五等分の花嫁【春夏秋冬】
   Japonca başlık: 五等分の花嫁【春夏秋冬】
   Tür/yıl: Anime / yok
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:64104
   Ham kimlik alanları: MAL ID=64104 (MAL), AniList kayıt ID=601324275, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=2/?, cilt=0, puan=6
   Tarihler: başlangıç=2026-10-06, bitiş=2026-10-06; favori=false
   
   Kimlik güvencesi: Güvenilir (MAL/Shikimori kaydının kendi kimliği)
   
   Bangumi bölüm ilerlemesi yazılamadı (五等分の花嫁【春夏秋冬】): Bangumi isteği reddetti (400): Accepted — /subject/646470/update/watched_eps?watched_eps=2— sunucu: Accepted — /subject/646470/update/watched_eps?watched_eps=2
```

## Sorun 121 · UYARI · Eşleştirme

- Rapor satırları: `8588–8654`
- Zaman: `2026-10-24 16:22:04.822 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `2802`

```text
121. [2026-10-24 16:22:04.822 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Mushoku Tensei III: Isekai Ittara Honki Dasu Part 2
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: Mushoku Tensei III: Isekai Ittara Honki Dasu Part 2
   Japonca başlık: 無職転生Ⅲ ～異世界行ったら本気だす～ 第2クール
   Tür/yıl: Anime / 2027
   Kaynak: anilist
   Harici kimlikler: Anime:mal:65077
   Ham kimlik alanları: MAL ID=65077 (MAL), AniList kayıt ID=598488253, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/?, cilt=0, puan=8
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Mushoku Tensei III: Isekai Ittara Honki Dasu Part 2
   İngilizce başlık: Mushoku Tensei: Jobless Reincarnation Season 3 Part 2
   Japonca başlık: 無職転生 III ～異世界行ったら本気だす～第2クール
   Tür/yıl: Anime / 2027
   Kaynak: mal
   Harici kimlikler: Anime:mal:65077
   Ham kimlik alanları: MAL ID=65077 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/?, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Mushoku Tensei III: Isekai Ittara Honki Dasu
   Tür/yıl: Anime / yok
   Kaynak: simkl
   Harici kimlikler: Anime:mal:65077, Anime:simkl:3265400
   Ham kimlik alanları: MAL ID=65077 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=3265400, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/?, cilt=0, puan=8
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Mushoku Tensei III: Isekai Ittara Honki Dasu Part 2
   İngilizce başlık: Mushoku Tensei: Jobless Reincarnation Season 3 Part 2
   Japonca başlık: 無職転生Ⅲ ～異世界行ったら本気だす～ 第2クール
   Tür/yıl: Anime / 2027
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:51093
   Ham kimlik alanları: MAL ID=300051093 (dahili Kitsu kimliği, MAL değil: Kitsu #51093), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/?, cilt=0, puan=8
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Mushoku Tensei III: Isekai Ittara Honki Dasu Part 2
   Tür/yıl: Anime / 2027
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:65077, Anime:shikimori:65077
   Ham kimlik alanları: MAL ID=65077 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/?, cilt=0, puan=8
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: 無職転生Ⅲ ～異世界行ったら本気だす～ 第2クール
   Japonca başlık: 無職転生Ⅲ ～異世界行ったら本気だす～ 第2クール
   Tür/yıl: Anime / yok
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:708197
   Ham kimlik alanları: MAL ID=500708197 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/?, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 122 · UYARI · Eşleştirme

- Rapor satırları: `8656–8691`
- Zaman: `2026-10-24 16:22:05.020 GMT+03:00`
- Kod: `KTS-ANL-2002`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `2806`

```text
122. [2026-10-24 16:22:05.020 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Aishen Qiaokeli-ing: Wanjie Jinian
   Kod: KTS-ANL-2002
   | KTS-ANL-2002 · WARNING · ANL
   | TR — AniList çok fazla istek (GraphQL 429)
   | Neden: GraphQL yanıtı "Too Many Requests" döndü. AniList'in dakikalık limitinin yanında kısa aralıklı patlamaları engelleyen ayrı bir burst limiter'ı da var.
   | Çözüm: Bir dakika bekleyin; Retry-After başlığı kadar bekleme otomatik uygulanır.
   | EN — AniList rate limited (GraphQL 429)
   | Why: The GraphQL response returned "Too Many Requests". Besides the per-minute limit, AniList runs a separate burst limiter against short request spikes.
   | Fix: Wait a minute; the Retry-After delay is applied automatically.
   Başlık: Aishen Qiaokeli-ing: Wanjie Jinian
   Japonca başlık: 爱神巧克力 完结纪念
   Tür/yıl: Anime / 2016
   Kaynak: mal
   Harici kimlikler: Anime:mal:40835
   Ham kimlik alanları: MAL ID=40835 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Cupid's Chocolates Recap
   İngilizce başlık: Cupid's Chocolates Recap
   Tür/yıl: Anime / 2016
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:42955
   Ham kimlik alanları: MAL ID=300042955 (dahili Kitsu kimliği, MAL değil: Kitsu #42955), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Aishen Qiaokeli-ing: Wanjie Jinian
   Tür/yıl: Anime / 2016
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:40835, Anime:shikimori:40835
   Ham kimlik alanları: MAL ID=40835 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 123 · UYARI · Eşleştirme

- Rapor satırları: `8693–8736`
- Zaman: `2026-10-24 16:22:32.666 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `2842`

```text
123. [2026-10-24 16:22:32.666 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Tensei shitara Slime Datta Ken Movie: Guren no Kizuna-hen Specials
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: Tensei shitara Slime Datta Ken Movie: Guren no Kizuna-hen Specials
   Tür/yıl: Anime / 2023
   Kaynak: mal
   Harici kimlikler: Anime:mal:57434
   Ham kimlik alanları: MAL ID=57434 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/2, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Gekijouban Tensei Shitara Slime Datta Ken: Guren no Kizuna Hen
   Tür/yıl: Anime / 2022
   Kaynak: simkl
   Harici kimlikler: Anime:mal:57434, Anime:simkl:1735833, Anime:tmdb:876792
   Ham kimlik alanları: MAL ID=57434 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=1735833, TMDB ID=876792
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Tensei shitara Slime Datta Ken Movie: Guren no Kizuna-hen Specials
   Tür/yıl: Anime / 2023
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:57434, Anime:shikimori:57434
   Ham kimlik alanları: MAL ID=57434 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/2, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: 転生したらスライムだった件 コリウスの夢
   Japonca başlık: 転生したらスライムだった件 コリウスの夢
   Tür/yıl: Anime / 2023
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:421174
   Ham kimlik alanları: MAL ID=500421174 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/3, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 124 · UYARI · Eşleştirme

- Rapor satırları: `8738–8785`
- Zaman: `2026-10-24 16:22:32.668 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_unverified`
- Tüm olay no: `2843`

```text
124. [2026-10-24 16:22:32.668 GMT+03:00] [UYARI] [Eşleştirme] Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Tensei shitara Slime Datta Ken: Kanwa - Veldora Nikki
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   Başlık: Tensei shitara Slime Datta Ken: Kanwa - Veldora Nikki
   İngilizce başlık: That Time I Got Reincarnated as a Slime: Tales - Veldora's Journal
   Japonca başlık: 転生したらスライムだった件 閑話: ヴェルドラ日記
   Tür/yıl: Anime / 2019
   Kaynak: mal
   Harici kimlikler: Anime:mal:39607
   Ham kimlik alanları: MAL ID=39607 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Tensei shitara Slime Datta Ken - Kanwa: Verudora Nikki
   İngilizce başlık: That Time I Got Reincarnated as a Slime - Veldora's Journal
   Japonca başlık: 転生したらスライムだった件 閑話: ヴェルドラ日記
   Tür/yıl: Anime / 2019
   Kaynak: kitsu
   Harici kimlikler: Anime:kitsu:42212
   Ham kimlik alanları: MAL ID=300042212 (dahili Kitsu kimliği, MAL değil: Kitsu #42212), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: Tensei shitara Slime Datta Ken: Kanwa - Veldora Nikki
   Tür/yıl: Anime / 2019
   Kaynak: shikimori
   Harici kimlikler: Anime:mal:39607, Anime:shikimori:39607
   Ham kimlik alanları: MAL ID=39607 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/1, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
   
   
   Başlık: 転生したらスライムだった件 OAD
   Japonca başlık: 転生したらスライムだった件 OAD
   Tür/yıl: Anime / 2019
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:268726
   Ham kimlik alanları: MAL ID=500268726 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/5, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 125 · UYARI · Eşleştirme

- Rapor satırları: `8787–8798`
- Zaman: `2026-10-24 16:22:46.324 GMT+03:00`
- Kod: `—`
- İşlem / neden: `skipped` / `identity_mismatch_blocked`
- Tüm olay no: `2865`

```text
125. [2026-10-24 16:22:46.324 GMT+03:00] [UYARI] [Eşleştirme] Şüpheli kimlik, ekleme engellendi: Kanchigai no Atelier Meister: Eiyuu Party no Moto Zatsuyou-gakari ga, Jitsu wa Sentou Igai ga SSS Rank Datta to Iu Yoku Aru Hanashi → MAL #61411
   REDDEDİLDİ (MAL #61411 = Kanchigai no Atelier Meister Mini Anime, 2025; yerel başlık Kanchigai no Atelier Meister: Eiyuu Party no Moto Zatsuyou-gakari ga, Jitsu wa Sentou Igai ga SSS Rank Datta to Iu Yoku Aru Hanashi ile akraba değil)
   Bu grubun MAL kimliği tek bir sağlayıcı eşlemesinden/çıkarımdan geliyor ve MAL kataloğundaki içerikle uyuşmuyor.
   Hiçbir platforma yeni kayıt eklenmeyecek; mevcut kayıtların güncellenmesi etkilenmez.
   Kaynak platform kayıtları (1):
   Başlık: Kanchigai no Atelier Meister: Eiyuu Party no Moto Zatsuyou-gakari ga, Jitsu wa Sentou Igai ga SSS Rank Datta to Iu Yoku Aru Hanashi
   Tür/yıl: Anime / 2025
   Kaynak: simkl
   Harici kimlikler: Anime:mal:61411, Anime:simkl:2612238, Anime:tmdb:277881
   Ham kimlik alanları: MAL ID=61411 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=2612238, TMDB ID=277881
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 126 · UYARI · Eşleştirme

- Rapor satırları: `8801–8821`
- Zaman: `2026-10-24 16:22:59.656 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_mismatch_blocked`
- Tüm olay no: `2882`

```text
126. [2026-10-24 16:22:59.656 GMT+03:00] [UYARI] [Eşleştirme] Şüpheli kimlik, ekleme engellendi: はたらく魔王さま！！ 2nd Season → MAL #53200
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   REDDEDİLDİ (MAL #53200 = Hataraku Maou-sama!! 2nd Season, 2023; yerel başlık はたらく魔王さま！！ 2nd Season ile akraba değil)
   Bu grubun MAL kimliği tek bir sağlayıcı eşlemesinden/çıkarımdan geliyor ve MAL kataloğundaki içerikle uyuşmuyor.
   Hiçbir platforma yeni kayıt eklenmeyecek; mevcut kayıtların güncellenmesi etkilenmez.
   Kaynak platform kayıtları (1):
   Başlık: はたらく魔王さま！！ 2nd Season
   Japonca başlık: はたらく魔王さま！！ 2nd Season
   Tür/yıl: Anime / 2023
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:403225
   Ham kimlik alanları: MAL ID=500403225 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/12, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 127 · UYARI · Eşleştirme

- Rapor satırları: `8824–8844`
- Zaman: `2026-10-24 16:23:50.028 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_mismatch_blocked`
- Tüm olay no: `2931`

```text
127. [2026-10-24 16:23:50.028 GMT+03:00] [UYARI] [Eşleştirme] Şüpheli kimlik, ekleme engellendi: 恋するシロクマ → MAL #36742
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   REDDEDİLDİ (MAL #36742 = Koisuru Shirokuma Tokubetsu-ban, 2017; yerel başlık 恋するシロクマ ile akraba değil)
   Bu grubun MAL kimliği tek bir sağlayıcı eşlemesinden/çıkarımdan geliyor ve MAL kataloğundaki içerikle uyuşmuyor.
   Hiçbir platforma yeni kayıt eklenmeyecek; mevcut kayıtların güncellenmesi etkilenmez.
   Kaynak platform kayıtları (1):
   Başlık: 恋するシロクマ
   Japonca başlık: 恋するシロクマ
   Tür/yıl: Anime / 2017
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:202156
   Ham kimlik alanları: MAL ID=500202156 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Planlandı, bölüm=0/7, cilt=0, puan=yok
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 128 · UYARI · Eşleştirme

- Rapor satırları: `8847–8867`
- Zaman: `2026-10-24 16:23:57.220 GMT+03:00`
- Kod: `KTS-ANL-2003`
- İşlem / neden: `skipped` / `identity_mismatch_blocked`
- Tüm olay no: `2938`

```text
128. [2026-10-24 16:23:57.220 GMT+03:00] [UYARI] [Eşleştirme] Şüpheli kimlik, ekleme engellendi: kiss×sis → MAL #7593
   Kod: KTS-ANL-2003
   | KTS-ANL-2003 · ERROR · ANL
   | TR — AniList sunucu hatası (500)
   | Neden: AniList GraphQL katmanı isteği işleyemedi. Servis tarafında geçici bir bozulma olduğunda görülür.
   | Çözüm: Birkaç dakika sonra tekrar deneyin.
   | EN — AniList server error (500)
   | Why: The AniList GraphQL layer could not process the request, which happens during brief service-side degradation.
   | Fix: Try again in a few minutes.
   REDDEDİLDİ (MAL #7593 = Kiss x Sis (TV), 2010; yerel başlık kiss×sis ile akraba değil)
   Bu grubun MAL kimliği tek bir sağlayıcı eşlemesinden/çıkarımdan geliyor ve MAL kataloğundaki içerikle uyuşmuyor.
   Hiçbir platforma yeni kayıt eklenmeyecek; mevcut kayıtların güncellenmesi etkilenmez.
   Kaynak platform kayıtları (1):
   Başlık: kiss×sis
   Japonca başlık: kiss×sis
   Tür/yıl: Anime / 2010
   Kaynak: bangumi
   Harici kimlikler: Anime:bangumi:4284
   Ham kimlik alanları: MAL ID=500004284 (MAL), AniList kayıt ID=yok, MAL liste ID=yok, Simkl ID=yok, TMDB ID=yok
   Durum/ilerleme: Tamamlandı, bölüm=12/12, cilt=0, puan=6
   Tarihler: başlangıç=yok, bitiş=yok; favori=false
```

## Sorun 129 · UYARI · Simkl

- Rapor satırları: `8870–9010`
- Zaman: `2026-10-24 16:25:14.826 GMT+03:00`
- Kod: `KTS-SMK-8004`
- İşlem / neden: `skipped` / `remote_identity_unresolved`
- Tüm olay no: `2984`

```text
129. [2026-10-24 16:25:14.826 GMT+03:00] [UYARI] [Simkl] [Simkl] 130 kayıt Simkl kataloğunda bulunamadı (atlandı)
   Kod: KTS-SMK-8004
   | KTS-SMK-8004 · WARNING · SMK
   | TR — Simkl hız sınırı
   | Neden: Simkl saniyede 1 istek kabul ediyor; daha hızlı gönderilen istekler 429 ile döner.
   | Çözüm: Bekleyin, istekler otomatik olarak 1 sn aralıkla seyreltilir.
   | EN — Simkl rate limit
   | Why: Simkl accepts one request per second; faster bursts return 429.
   | Fix: Wait — requests are automatically paced to 1 second apart.
   Simkl bu kayıtları `not_found` olarak geri gönderdi; kimlik eşlemesi (MAL/TMDB/AniList) Simkl tarafında yok veya başlık eşleşmedi. Kayıtlar diğer hesaplarda eşitlenmeye devam eder.
   
   • 15 Bishoujo Hyouryuuki (2009) [mal=5762]
   • Demon Father (2009) [mal=6893]
   • Kanojo x Kanojo x Kanojo (2009) [mal=7411]
   • Aki Sora (2010) [mal=8577]
   • HHH: Triple Ecchi - Bonus Episode (2010) [mal=9322]
   • Menkui! (2011) [mal=10419]
   • Bloods: Inraku no Ketsuzoku 2 (2011) [mal=10694]
   • Eroge! Sex and Gamedev (2011) [mal=10779]
   • Nee SUMMER! (2011) [mal=11321]
   • Swing Out Sisters (2011) [mal=12143]
   • With Maki-chan (2012) [mal=12375]
   • Kyonyuu Fantasy (2012) [mal=13221]
   • Koutetsu no Majo Annerose (2012) [mal=14543]
   • Tropical Kiss (2012) [mal=15097]
   • Those Science Freaks (2013) [mal=15391]
   • Tsun Tsun Maid wa Ero Ero desu (2013) [mal=15841]
   • Koiito Kinenbi: THE ANIMATION (2012) [mal=15843]
   • Kotowari: Kimi no Kokoro no Koboreta Kakera (2013) [mal=17541]
   • High School Girls' Waists (2013) [mal=18691]
   • Oni Chichi: Rebuild (2013) [mal=21097]
   • Bombastic Sisters (2014) [mal=24641]
   • Swing Out Sisters 完全版 (2014) [mal=22069]
   • Vampire Vixen (2014) [mal=22429]
   • Gakuen de Jikan yo Tomare (2015) [mal=30243]
   • Genkaku Cool na Sensei ga Aheboteochi! (2015) [mal=29261]
   • Namaiki: Kissuisou e Youkoso! - THE ANIMATION (2015) [mal=29808]
   • Sexy Daze, Naughty Knights (2014) [mal=28157]
   • Chichiiro Toiki (2014) [mal=21925]
   • Manga Café Mishaps (2015) [mal=29575]
   • Ane Yome Quartet (2015) [mal=30614]
   • Anoko to Iikoto (2015) [mal=31117]
   • Urban Legends Series (2016) [mal=32355]
   • A-Sized Classmate (2016) [mal=32484]
   • Marshmallow, Imouto, Succubus (2016) [mal=32405]
   • Fukubiki! Triangle: Futaba wa Atafuta (2015) [mal=29573]
   • Shoujo Ramune (2016) [mal=32587]
   • 300円のおつきあい Anime Edition (2016) [mal=33993]
   • Ecchi na Shintai Sokutei Anime Edition (2016) [mal=34311]
   • Tamashii: Insert (2017) [mal=34795]
   • Honoo no Haramase Oppai ★ Ero Appli Gakuen THE ANIMATION (2017) [mal=35512]
   • Lusty Ladies of Mayohiga (2017) [mal=35727]
   • Kimekoi! - Love Decision! The Reason Why I'm Going after a Girl Out of My League and My Childhood Friend (2017) [mal=35931]
   • Only My Oppai Soul (2017) [mal=36121]
   • Will you... make love? (2018) [mal=36895]
   • Oyasumi Sex (2018) [mal=36889]
   • Tsun M!: Gyutto Shibatte Shidoushite THE ANIMATION (2018) [mal=37222]
   • Fate/Grand Order CMs (2014) [mal=36064]
   • Beloved Mother (2018) [mal=37699]
   • Dumb Girls In Puberty!!! (2018) [mal=38030]
   • Kimi Omou Koi (2018) [mal=38330]
   • Saimin Seishidou (2019) [mal=38470]
   • Rune's Pharmacy ~Tiara's Pharmacist (2018) [mal=38775]
   • Shishunki Sex (2019) [mal=35926]
   • Seikatsu Shuukan THE ANIMATION (2019) [mal=38866]
   • Welcome to Hinagiku Virgin Lost Club (2019) [mal=38995]
   • Making A Cumback to Early Days! (2019) [mal=39042]
   • Aikagi The Animation (2019) [mal=39085]
   • Backwasher! -Her and I, in the Women's Bath!?- (2019) [mal=39337]
   • Shoujo Kyouiku RE (2019) [mal=39299]
   • Princess Love Life! (2019) [mal=39471]
   • Jyoshi Luck！ (2019) [mal=39800]
   • Lovely Aina-chan (2019) [mal=40023]
   • Kutsujoku (2019) [mal=40048]
   • Aibeya THE ANIMATION (2019) [mal=40337]
   • Boku to Joi no Shinsatsu Nisshi The Animation (2019) [mal=40472]
   • Assisted Mating (2020) [mal=40658]
   • Roto Spread (2016) [mal=38960]
   • Chiisana Tsubomi no Sono Oku ni... (2020) [mal=41236]
   • 義姉はヤンママ授乳中 (2020) [mal=41261]
   • Hajimete no Orusuban (2020) [mal=41793]
   • Kutsujoku 2 The Animation (2020) [mal=41512]
   • Otherworld Harem Story (2020) [mal=41848]
   • Shikiyoku INFINITE (2020) [mal=42224]
   • MAN WITH A MISSION THE ANIMATION (2020) [mal=41477]
   • Ijirare: Fukushuu Sai○ (2021) [mal=43465]
   • Simple yet Sexy (2021) [mal=44044]
   • Real Eroge Situation! 2 The Animation (2021) [mal=48449]
   • My Younger Brother is Really Big, Wanna Come See? (2021) [mal=48468]
   • Mako-chan Kaihatsu Nikki (2021) [mal=48698]
   • Imaizumi's house seems to be a gathering place for gals (2021) [mal=48755]
   • Sex Studies (2021) [mal=49944]
   • Love Me: Kaede and Suzu THE ANIMATION (2022) [mal=50634]
   • Serving the Little Succubus (2022) [mal=52104]
   • Ona Hole Class Room The Animation (2021) [mal=49524]
   • Show Time! (2021) [mal=49637]
   • Anehame: Ore no Hatsukoi ga Jisshi na wake ga nai (2021) [mal=50161]
   • Holy Maid Academy 2 (2022) [mal=50435]
   • Ero doctor (2022) [mal=50434]
   • オタクに優しいギャルとか、巨乳の幼なじみとか。 (2022) [mal=50436]
   • Garden -The Two Flowers of the Takamine Family- THE ANIMATION (2022) [mal=50488]
   • けものっ娘通信〜The Animation〜 (2021) [mal=50622]
   • メイド教育。－没落貴族 瑠璃川椿－ THE ANIMATION (2023) [mal=54629]
   • I Summoned a Succubus and My Mom Appeared!? (2022) [mal=52617]
   • Harem Camp! (2022) [mal=52717]
   • Mesudachi The Animation (2022) [mal=52904]
   • Rent-a-Girlfriend Season 2: Date Movie (2022) [mal=52289]
   • I'm Quitting Heroing Mini Anime (2022) [mal=52977]
   • In The End, The Witch And Her Customer... The Animation (2023) [mal=53724]
   • I'm the Only Guy in the Class!? (2023) [mal=53725]
   • 1LDK＋J系 いきなり同居？密着！？初エッチ！！？ (2023) [mal=55003]
   • スケベエルフ探訪記 (2023) [mal=54912]
   • so_low (2023) [mal=55548]
   • Notice my Love! THE ANIMATION (2023) [mal=55547]
   • I Shouldn't Have Gone To The Doujinshi Convention Without Telling My Wife (2023) [mal=55850]
   • 初恋時間。 (2023) [mal=56511]
   • 旬花蒐陶 (2023) [mal=56852]
   • Fleur The Animation (2024) [mal=57044]
   • Adam's Sweet Agony (2024) [mal=57470]
   • 満たされて目覚める朝に、地味な朝食を The Animation (2024) [mal=57283]
   • 69〜偽りの微笑〜 (2024) [mal=57860]
   • 終末ホスピタル (2024) [mal=58642]
   • セフレのセンパイ THE ANIMATION (2024) [mal=58564]
   • いま♡りあ (2024) [mal=59119]
   • 少年が大人になった夏 (2024) [mal=59120]
   • Drop-in Gyaru Lets Me Use Her Pussy (2024) [mal=59407]
   • Nani Warotonnen (2024) [mal=60167]
   • Solo Leveling -ReAwakening- (2024) [mal=59841]
   • 元カレとはできなかったセックスしてもいいですか？ (2025) [mal=60993]
   • レイカは華麗な僕の女王 THE ANIMATION (2025) [mal=62315]
   • PetitCure: Precure Fairies Season 3 (2026) [mal=63773]
   • 五等分の花嫁【春夏秋冬】 [mal=64104]
   • Fleur [mal=56985]
   • ハイスクールD×D OAD
   • 「Fate/Grand Order」配信4周年記念映像
   • Mameshiba the DVD Green Pea-shiba no Kutsujoku (2009) [mal=33705]
   • NieR:Automata Ver1.1a (Cour 2): Investigation Report (2024) [mal=59562]
   • Norimono Atsumare: Hit Song-shuu (1994) [mal=32904]
   • Re:Zero Starting Life in Another World - Director's Cut (2020) [kitsu=42903]
   • Sherlock (Series 1) (2010)
   • Sherlock Holmes: A Game of Shadows (2011)
```

## Sorun 130 · UYARI · Simkl

- Rapor satırları: `9011–9015`
- Zaman: `2026-10-24 16:25:14.827 GMT+03:00`
- Kod: `—`
- İşlem / neden: `skipped` / `episode_progress_not_transferred`
- Tüm olay no: `2985`

```text
130. [2026-10-24 16:25:14.827 GMT+03:00] [UYARI] [Simkl] [Simkl] 2 dizinin bölüm ilerlemesi aktarılmadı (liste durumu yazıldı)
   Simkl, diziler için toplam bölüm sayısı yerine sezon/bölüm bazlı izleme geçmişi ister; bu eşleme henüz desteklenmiyor. Liste durumu ve puan aktarıldı.
   
   • 心动的信号
   • Sherlock Holmes: A Game of Shadows
```

## Sorun 131 · UYARI · Simkl

- Rapor satırları: `9016–9037`
- Zaman: `2026-10-24 16:25:14.827 GMT+03:00`
- Kod: `KTS-SMK-8004`
- İşlem / neden: `other_info` / `rate_limit`
- Tüm olay no: `2986`

```text
131. [2026-10-24 16:25:14.827 GMT+03:00] [UYARI] [Simkl] [Simkl] 13 kısmi işlem uyarısı (izleme geçmişi/puan)
   Kod: KTS-SMK-8004
   | KTS-SMK-8004 · WARNING · SMK
   | TR — Simkl hız sınırı
   | Neden: Simkl saniyede 1 istek kabul ediyor; daha hızlı gönderilen istekler 429 ile döner.
   | Çözüm: Bekleyin, istekler otomatik olarak 1 sn aralıkla seyreltilir.
   | EN — Simkl rate limit
   | Why: Simkl accepts one request per second; faster bursts return 429.
   | Fix: Wait — requests are automatically paced to 1 second apart.
   • 20 kaydın bölüm ilerlemesi Simkl'de eşleşmedi: 15 Bishoujo Hyouryuuki (2009) [mal=5762], Demon Father (2009) [mal=6893], Kanojo x Kanojo x Kanojo (2009) [mal=7411], Aki Sora (2010) [mal=8577], HHH: Triple Ecchi - Bonus Episode (2010) [mal=9322]
   • 18 kaydın puanı Simkl'de eşleşmedi: Demon Father (2009) [mal=6893], Kanojo x Kanojo x Kanojo (2009) [mal=7411], Aki Sora (2010) [mal=8577], HHH: Triple Ecchi - Bonus Episode (2010) [mal=9322], Menkui! (2011) [mal=10419]
   • 20 kaydın bölüm ilerlemesi Simkl'de eşleşmedi: Vampire Vixen (2014) [mal=22429], Genkaku Cool na Sensei ga Aheboteochi! (2015) [mal=29261], Namaiki: Kissuisou e Youkoso! - THE ANIMATION (2015) [mal=29808], Sexy Daze, Naughty Knights (2014) [mal=28157], Chichiiro Toiki (2014) [mal=21925]
   • 20 kaydın puanı Simkl'de eşleşmedi: Vampire Vixen (2014) [mal=22429], Gakuen de Jikan yo Tomare (2015) [mal=30243], Genkaku Cool na Sensei ga Aheboteochi! (2015) [mal=29261], Namaiki: Kissuisou e Youkoso! - THE ANIMATION (2015) [mal=29808], Sexy Daze, Naughty Knights (2014) [mal=28157]
   • 23 kaydın bölüm ilerlemesi Simkl'de eşleşmedi: Oyasumi Sex (2018) [mal=36889], Tsun M!: Gyutto Shibatte Shidoushite THE ANIMATION (2018) [mal=37222], Fate/Grand Order CMs (2014) [mal=36064], Beloved Mother (2018) [mal=37699], Dumb Girls In Puberty!!! (2018) [mal=38030]
   • 23 kaydın puanı Simkl'de eşleşmedi: Oyasumi Sex (2018) [mal=36889], Tsun M!: Gyutto Shibatte Shidoushite THE ANIMATION (2018) [mal=37222], Fate/Grand Order CMs (2014) [mal=36064], Beloved Mother (2018) [mal=37699], Dumb Girls In Puberty!!! (2018) [mal=38030]
   • 23 kaydın bölüm ilerlemesi Simkl'de eşleşmedi: Kutsujoku 2 The Animation (2020) [mal=41512], Shikiyoku INFINITE (2020) [mal=42224], MAN WITH A MISSION THE ANIMATION (2020) [mal=41477], Simple yet Sexy (2021) [mal=44044], Real Eroge Situation! 2 The Animation (2021) [mal=48449]
   • 23 kaydın puanı Simkl'de eşleşmedi: Kutsujoku 2 The Animation (2020) [mal=41512], Shikiyoku INFINITE (2020) [mal=42224], MAN WITH A MISSION THE ANIMATION (2020) [mal=41477], Simple yet Sexy (2021) [mal=44044], Real Eroge Situation! 2 The Animation (2021) [mal=48449]
   • 23 kaydın bölüm ilerlemesi Simkl'de eşleşmedi: Rent-a-Girlfriend Season 2: Date Movie (2022) [mal=52289], In The End, The Witch And Her Customer... The Animation (2023) [mal=53724], I'm the Only Guy in the Class!? (2023) [mal=53725], スケベエルフ探訪記 (2023) [mal=54912], so_low (2023) [mal=55548]
   • 21 kaydın puanı Simkl'de eşleşmedi: Rent-a-Girlfriend Season 2: Date Movie (2022) [mal=52289], In The End, The Witch And Her Customer... The Animation (2023) [mal=53724], I'm the Only Guy in the Class!? (2023) [mal=53725], スケベエルフ探訪記 (2023) [mal=54912], so_low (2023) [mal=55548]
   • 2 anime, güvenli Simkl/MAL kimliği olmadığı için gönderilmedi. Yanlış eşleşmeyi önlemek için başlıkla arama yapılmadı: ハイスクールD×D OAD, 「Fate/Grand Order」配信4周年記念映像
   • 4 kaydın bölüm ilerlemesi Simkl'de eşleşmedi: Mameshiba the DVD Green Pea-shiba no Kutsujoku (2009) [mal=33705], Norimono Atsumare: Hit Song-shuu (1994) [mal=32904], Re:Zero Starting Life in Another World - Director's Cut (2020) [kitsu=42903], Nisekoi OAD (2014) [mal=24227]
   • 3 kaydın puanı Simkl'de eşleşmedi: Mameshiba the DVD Green Pea-shiba no Kutsujoku (2009) [mal=33705], Norimono Atsumare: Hit Song-shuu (1994) [mal=32904], Re:Zero Starting Life in Another World - Director's Cut (2020) [kitsu=42903]
```

## Sorun 132 · UYARI · Bangumi

- Rapor satırları: `9038–9072`
- Zaman: `2026-10-24 16:25:16.328 GMT+03:00`
- Kod: `—`
- İşlem / neden: `skipped` / `remote_identity_unresolved`
- Tüm olay no: `2987`

```text
132. [2026-10-24 16:25:16.328 GMT+03:00] [UYARI] [Bangumi] [Bangumi] 34 kayıt atlandı: Bangumi eşleşmesi bulunamadı
   Atlanan kayıtlar (34): • Rurouni Kenshin: Meiji Kenkaku Romantan
   • Toradora!: SOS!
   • Toaru Kagaku no Railgun: Motto Marutto Railgun
   • Memory (ONA)
   • Sekaiichi Hatsukoi
   • Utakata Hanabi
   • To LOVE-Ru Darkness OVA
   • Chuunibyou demo Koi ga Shitai!: Kirameki no… Slapstick Noel
   • Shinmai Maou no Testament: Loli Ero Succubus Maria no Characommentary Tsuki Hizou Eizou
   • Lovely Movie: Itoshi no Muco
   • To LOVE-Ru: Multiplication - Mae kara Ushiro kara
   • Fate/Grand Order CMs
   • White Album 2 Picture Drama
   • Trinity Seven Movie - Tenkuu Toshokan to Shinku no Maou
   • Holiday Love: Fuufukan Renai
   • Bokutachi wa Benkyou ga Dekinai
   • Bokutachi wa Benkyou ga Dekinai!
   • Roto Spread
   • MAN WITH A MISSION THE ANIMATION
   • Re:Zero kara Hajimeru Kyuukei Jikan (Break Time) 2nd Season
   • Kobayashi-san Chi no Maidragon S: Nippon no Omotenashi (Attend wa Dragon desu)
   • Nani Warotonnen
   • PetitCure: Precure Fairies Season 3
   • Aesop Douwa
   • Mameshiba the DVD Green Pea-shiba no Kutsujoku
   • Norimono Atsumare: Hit Song-shuu
   • Re:Zero kara Hajimeru Isekai Seikatsu - Memory Snow - Manner Movie
   • Tensei Shitara Slime Datta Ken 2nd Season Recap
   • Coraline
   • Digger
   • Rick and Morty
   • Aki-Sora: In a Dream
   • Tales of A Harem in Another World
   • Re:Zero kara Hajimeru Isekai Seikatsu: Shin Henshuu-ban
```

## Sorun 133 · UYARI · AniList

- Rapor satırları: `9073–9103`
- Zaman: `2026-10-24 16:25:16.328 GMT+03:00`
- Kod: `—`
- İşlem / neden: `skipped` / `remote_identity_unresolved`
- Tüm olay no: `2988`

```text
133. [2026-10-24 16:25:16.328 GMT+03:00] [UYARI] [AniList] [AniList] 30 kayıt atlandı: AniList medya kimliği çözülemedi (MAL ID veya ARM eşlemesi yok)
   Atlanan kayıtlar (30): • Aesop Douwa
   • Beatless: Final Stage
   • Fleur
   • Hataraku Maou-sama!! Recap
   • Mameshiba the DVD Green Pea-shiba no Kutsujoku
   • NieR:Automata Ver1.1a Part 2: Chapter. 13-18 Chousa Report
   • Norimono Atsumare: Hit Song-shuu
   • Ore dake Level Up na Ken: How to Get Stronger
   • Re:ゼロから始める異世界生活 氷結の絆
   • Re:Zero kara Hajimeru Isekai Seikatsu - Memory Snow - Manner Movie
   • Saenai Heroine no Sodatekata ♭: Koi to Junjou no Service-kai
   • Silent Witch: Chinmoku no Majo no Kakushigoto
   • Tensei Shitara Slime Datta Ken 2nd Season Recap
   • Uma Musume: Pretty Derby PV
   • Re:Zero kara Hajimeru Isekai Seikatsu: Shin Henshuu-ban
   • 劇場版 Fate/stay night [Heaven's Feel] III.spring song
   • ダンジョンに出会いを求めるのは間違っているだろうかⅢ
   • ウマ娘 プリティーダービー
   • ダンジョンに出会いを求めるのは間違っているだろうかⅡ
   • 君に届け 2ND SEASON
   • なんでここに先生が!?
   • 新妹魔王の契約者 BURST
   • NieR:Automata Ver1.1a 第2クール
   • 魔装学園H×H
   • ハイスクールD×D OAD
   • Fate/Grand Order -終局特異点 冠位時間神殿ソロモン-
   • デート・ア・ライブII
   • 「Fate/Grand Order」配信4周年記念映像
   • Bullying Grandmother
   • Nisekoi OAD
```

## Sorun 134 · UYARI · AniList

- Rapor satırları: `9104–9105`
- Zaman: `2026-10-24 16:25:16.329 GMT+03:00`
- Kod: `—`
- İşlem / neden: `skipped` / `identity_mismatch_blocked`
- Tüm olay no: `2989`

```text
134. [2026-10-24 16:25:16.329 GMT+03:00] [UYARI] [AniList] [AniList] 1 kayıt atlandı: Kimlik doğrulanamadı (MAL #61411 yerel başlık/yıl ile uyuşmuyor; yanlış içerik eklenmesin diye atlandı)
   Atlanan kayıtlar (1): • Kanchigai no Atelier Meister: Eiyuu Party no Moto Zatsuyou-gakari ga, Jitsu wa Sentou Igai ga SSS Rank Datta to Iu Yoku Aru Hanashi
```

## Sorun 135 · UYARI · MyAnimeList

- Rapor satırları: `9106–9107`
- Zaman: `2026-10-24 16:25:16.329 GMT+03:00`
- Kod: `—`
- İşlem / neden: `skipped` / `identity_mismatch_blocked`
- Tüm olay no: `2990`

```text
135. [2026-10-24 16:25:16.329 GMT+03:00] [UYARI] [MyAnimeList] [MyAnimeList] 1 kayıt atlandı: Kimlik doğrulanamadı (MAL #61411 yerel başlık/yıl ile uyuşmuyor; yanlış içerik eklenmesin diye atlandı)
   Atlanan kayıtlar (1): • Kanchigai no Atelier Meister: Eiyuu Party no Moto Zatsuyou-gakari ga, Jitsu wa Sentou Igai ga SSS Rank Datta to Iu Yoku Aru Hanashi
```

## Sorun 136 · UYARI · Kitsu

- Rapor satırları: `9108–9109`
- Zaman: `2026-10-24 16:25:16.329 GMT+03:00`
- Kod: `—`
- İşlem / neden: `skipped` / `identity_mismatch_blocked`
- Tüm olay no: `2991`

```text
136. [2026-10-24 16:25:16.329 GMT+03:00] [UYARI] [Kitsu] [Kitsu] 1 kayıt atlandı: Kimlik doğrulanamadı (MAL #61411 yerel başlık/yıl ile uyuşmuyor; yanlış içerik eklenmesin diye atlandı)
   Atlanan kayıtlar (1): • Kanchigai no Atelier Meister: Eiyuu Party no Moto Zatsuyou-gakari ga, Jitsu wa Sentou Igai ga SSS Rank Datta to Iu Yoku Aru Hanashi
```

## Sorun 137 · UYARI · Shikimori

- Rapor satırları: `9110–9111`
- Zaman: `2026-10-24 16:25:16.329 GMT+03:00`
- Kod: `—`
- İşlem / neden: `skipped` / `identity_mismatch_blocked`
- Tüm olay no: `2992`

```text
137. [2026-10-24 16:25:16.329 GMT+03:00] [UYARI] [Shikimori] [Shikimori] 1 kayıt atlandı: Kimlik doğrulanamadı (MAL #61411 yerel başlık/yıl ile uyuşmuyor; yanlış içerik eklenmesin diye atlandı)
   Atlanan kayıtlar (1): • Kanchigai no Atelier Meister: Eiyuu Party no Moto Zatsuyou-gakari ga, Jitsu wa Sentou Igai ga SSS Rank Datta to Iu Yoku Aru Hanashi
```

## Sorun 138 · UYARI · Bangumi

- Rapor satırları: `9112–9113`
- Zaman: `2026-10-24 16:25:16.329 GMT+03:00`
- Kod: `—`
- İşlem / neden: `skipped` / `identity_mismatch_blocked`
- Tüm olay no: `2993`

```text
138. [2026-10-24 16:25:16.329 GMT+03:00] [UYARI] [Bangumi] [Bangumi] 1 kayıt atlandı: Kimlik doğrulanamadı (MAL #61411 yerel başlık/yıl ile uyuşmuyor; yanlış içerik eklenmesin diye atlandı)
   Atlanan kayıtlar (1): • Kanchigai no Atelier Meister: Eiyuu Party no Moto Zatsuyou-gakari ga, Jitsu wa Sentou Igai ga SSS Rank Datta to Iu Yoku Aru Hanashi
```

## Sorun 139 · UYARI · MyAnimeList

- Rapor satırları: `9114–9117`
- Zaman: `2026-10-24 16:25:16.329 GMT+03:00`
- Kod: `—`
- İşlem / neden: `skipped` / `verified_mal_id_missing`
- Tüm olay no: `2994`

```text
139. [2026-10-24 16:25:16.329 GMT+03:00] [UYARI] [MyAnimeList] [MyAnimeList] 3 kayıt atlandı: Doğrulanmış MAL ID yok (AniList/Kitsu/Simkl kaydı MAL ile eşlenemedi)
   Atlanan kayıtlar (3): • Re:Zero kara Hajimeru Isekai Seikatsu: Shin Henshuu-ban
   • ハイスクールD×D OAD
   • 「Fate/Grand Order」配信4周年記念映像
```

## Sorun 140 · UYARI · Shikimori

- Rapor satırları: `9118–9121`
- Zaman: `2026-10-24 16:25:16.330 GMT+03:00`
- Kod: `—`
- İşlem / neden: `skipped` / `verified_mal_id_missing`
- Tüm olay no: `2995`

```text
140. [2026-10-24 16:25:16.330 GMT+03:00] [UYARI] [Shikimori] [Shikimori] 3 kayıt atlandı: Doğrulanmış MAL ID yok (Shikimori kimlikleri MAL ID ile aynıdır)
   Atlanan kayıtlar (3): • Re:Zero kara Hajimeru Isekai Seikatsu: Shin Henshuu-ban
   • ハイスクールD×D OAD
   • 「Fate/Grand Order」配信4周年記念映像
```

## Sorun 141 · UYARI · AniList

- Rapor satırları: `9122–9123`
- Zaman: `2026-10-24 16:25:16.330 GMT+03:00`
- Kod: `—`
- İşlem / neden: `skipped` / `identity_mismatch_blocked`
- Tüm olay no: `2996`

```text
141. [2026-10-24 16:25:16.330 GMT+03:00] [UYARI] [AniList] [AniList] 1 kayıt atlandı: Kimlik doğrulanamadı (MAL #53200 yerel başlık/yıl ile uyuşmuyor; yanlış içerik eklenmesin diye atlandı)
   Atlanan kayıtlar (1): • はたらく魔王さま！！ 2nd Season
```

## Sorun 142 · UYARI · MyAnimeList

- Rapor satırları: `9124–9125`
- Zaman: `2026-10-24 16:25:16.330 GMT+03:00`
- Kod: `—`
- İşlem / neden: `skipped` / `identity_mismatch_blocked`
- Tüm olay no: `2997`

```text
142. [2026-10-24 16:25:16.330 GMT+03:00] [UYARI] [MyAnimeList] [MyAnimeList] 1 kayıt atlandı: Kimlik doğrulanamadı (MAL #53200 yerel başlık/yıl ile uyuşmuyor; yanlış içerik eklenmesin diye atlandı)
   Atlanan kayıtlar (1): • はたらく魔王さま！！ 2nd Season
```

## Sorun 143 · UYARI · Simkl

- Rapor satırları: `9126–9127`
- Zaman: `2026-10-24 16:25:16.330 GMT+03:00`
- Kod: `—`
- İşlem / neden: `skipped` / `identity_mismatch_blocked`
- Tüm olay no: `2998`

```text
143. [2026-10-24 16:25:16.330 GMT+03:00] [UYARI] [Simkl] [Simkl] 1 kayıt atlandı: Kimlik doğrulanamadı (MAL #53200 yerel başlık/yıl ile uyuşmuyor; yanlış içerik eklenmesin diye atlandı)
   Atlanan kayıtlar (1): • はたらく魔王さま！！ 2nd Season
```

## Sorun 144 · UYARI · Kitsu

- Rapor satırları: `9128–9129`
- Zaman: `2026-10-24 16:25:16.330 GMT+03:00`
- Kod: `—`
- İşlem / neden: `skipped` / `identity_mismatch_blocked`
- Tüm olay no: `2999`

```text
144. [2026-10-24 16:25:16.330 GMT+03:00] [UYARI] [Kitsu] [Kitsu] 1 kayıt atlandı: Kimlik doğrulanamadı (MAL #53200 yerel başlık/yıl ile uyuşmuyor; yanlış içerik eklenmesin diye atlandı)
   Atlanan kayıtlar (1): • はたらく魔王さま！！ 2nd Season
```

## Sorun 145 · UYARI · Shikimori

- Rapor satırları: `9130–9131`
- Zaman: `2026-10-24 16:25:16.331 GMT+03:00`
- Kod: `—`
- İşlem / neden: `skipped` / `identity_mismatch_blocked`
- Tüm olay no: `3000`

```text
145. [2026-10-24 16:25:16.331 GMT+03:00] [UYARI] [Shikimori] [Shikimori] 1 kayıt atlandı: Kimlik doğrulanamadı (MAL #53200 yerel başlık/yıl ile uyuşmuyor; yanlış içerik eklenmesin diye atlandı)
   Atlanan kayıtlar (1): • はたらく魔王さま！！ 2nd Season
```

## Sorun 146 · UYARI · AniList

- Rapor satırları: `9132–9133`
- Zaman: `2026-10-24 16:25:16.331 GMT+03:00`
- Kod: `—`
- İşlem / neden: `skipped` / `identity_mismatch_blocked`
- Tüm olay no: `3001`

```text
146. [2026-10-24 16:25:16.331 GMT+03:00] [UYARI] [AniList] [AniList] 1 kayıt atlandı: Kimlik doğrulanamadı (MAL #36742 yerel başlık/yıl ile uyuşmuyor; yanlış içerik eklenmesin diye atlandı)
   Atlanan kayıtlar (1): • 恋するシロクマ
```

## Sorun 147 · UYARI · MyAnimeList

- Rapor satırları: `9134–9135`
- Zaman: `2026-10-24 16:25:16.331 GMT+03:00`
- Kod: `—`
- İşlem / neden: `skipped` / `identity_mismatch_blocked`
- Tüm olay no: `3002`

```text
147. [2026-10-24 16:25:16.331 GMT+03:00] [UYARI] [MyAnimeList] [MyAnimeList] 1 kayıt atlandı: Kimlik doğrulanamadı (MAL #36742 yerel başlık/yıl ile uyuşmuyor; yanlış içerik eklenmesin diye atlandı)
   Atlanan kayıtlar (1): • 恋するシロクマ
```

## Sorun 148 · UYARI · Simkl

- Rapor satırları: `9136–9137`
- Zaman: `2026-10-24 16:25:16.331 GMT+03:00`
- Kod: `—`
- İşlem / neden: `skipped` / `identity_mismatch_blocked`
- Tüm olay no: `3003`

```text
148. [2026-10-24 16:25:16.331 GMT+03:00] [UYARI] [Simkl] [Simkl] 1 kayıt atlandı: Kimlik doğrulanamadı (MAL #36742 yerel başlık/yıl ile uyuşmuyor; yanlış içerik eklenmesin diye atlandı)
   Atlanan kayıtlar (1): • 恋するシロクマ
```

## Sorun 149 · UYARI · Kitsu

- Rapor satırları: `9138–9139`
- Zaman: `2026-10-24 16:25:16.331 GMT+03:00`
- Kod: `—`
- İşlem / neden: `skipped` / `identity_mismatch_blocked`
- Tüm olay no: `3004`

```text
149. [2026-10-24 16:25:16.331 GMT+03:00] [UYARI] [Kitsu] [Kitsu] 1 kayıt atlandı: Kimlik doğrulanamadı (MAL #36742 yerel başlık/yıl ile uyuşmuyor; yanlış içerik eklenmesin diye atlandı)
   Atlanan kayıtlar (1): • 恋するシロクマ
```

## Sorun 150 · UYARI · Shikimori

- Rapor satırları: `9140–9141`
- Zaman: `2026-10-24 16:25:16.331 GMT+03:00`
- Kod: `—`
- İşlem / neden: `skipped` / `identity_mismatch_blocked`
- Tüm olay no: `3005`

```text
150. [2026-10-24 16:25:16.331 GMT+03:00] [UYARI] [Shikimori] [Shikimori] 1 kayıt atlandı: Kimlik doğrulanamadı (MAL #36742 yerel başlık/yıl ile uyuşmuyor; yanlış içerik eklenmesin diye atlandı)
   Atlanan kayıtlar (1): • 恋するシロクマ
```

## Sorun 151 · UYARI · AniList

- Rapor satırları: `9142–9143`
- Zaman: `2026-10-24 16:25:16.331 GMT+03:00`
- Kod: `—`
- İşlem / neden: `skipped` / `identity_mismatch_blocked`
- Tüm olay no: `3006`

```text
151. [2026-10-24 16:25:16.331 GMT+03:00] [UYARI] [AniList] [AniList] 1 kayıt atlandı: Kimlik doğrulanamadı (MAL #7593 yerel başlık/yıl ile uyuşmuyor; yanlış içerik eklenmesin diye atlandı)
   Atlanan kayıtlar (1): • kiss×sis
```

## Sorun 152 · UYARI · MyAnimeList

- Rapor satırları: `9144–9145`
- Zaman: `2026-10-24 16:25:16.331 GMT+03:00`
- Kod: `—`
- İşlem / neden: `skipped` / `identity_mismatch_blocked`
- Tüm olay no: `3007`

```text
152. [2026-10-24 16:25:16.331 GMT+03:00] [UYARI] [MyAnimeList] [MyAnimeList] 1 kayıt atlandı: Kimlik doğrulanamadı (MAL #7593 yerel başlık/yıl ile uyuşmuyor; yanlış içerik eklenmesin diye atlandı)
   Atlanan kayıtlar (1): • kiss×sis
```

## Sorun 153 · UYARI · Simkl

- Rapor satırları: `9146–9147`
- Zaman: `2026-10-24 16:25:16.331 GMT+03:00`
- Kod: `—`
- İşlem / neden: `skipped` / `identity_mismatch_blocked`
- Tüm olay no: `3008`

```text
153. [2026-10-24 16:25:16.331 GMT+03:00] [UYARI] [Simkl] [Simkl] 1 kayıt atlandı: Kimlik doğrulanamadı (MAL #7593 yerel başlık/yıl ile uyuşmuyor; yanlış içerik eklenmesin diye atlandı)
   Atlanan kayıtlar (1): • kiss×sis
```

## Sorun 154 · UYARI · Kitsu

- Rapor satırları: `9148–9149`
- Zaman: `2026-10-24 16:25:16.332 GMT+03:00`
- Kod: `—`
- İşlem / neden: `skipped` / `identity_mismatch_blocked`
- Tüm olay no: `3009`

```text
154. [2026-10-24 16:25:16.332 GMT+03:00] [UYARI] [Kitsu] [Kitsu] 1 kayıt atlandı: Kimlik doğrulanamadı (MAL #7593 yerel başlık/yıl ile uyuşmuyor; yanlış içerik eklenmesin diye atlandı)
   Atlanan kayıtlar (1): • kiss×sis
```

## Sorun 155 · UYARI · Shikimori

- Rapor satırları: `9150–9151`
- Zaman: `2026-10-24 16:25:16.332 GMT+03:00`
- Kod: `—`
- İşlem / neden: `skipped` / `identity_mismatch_blocked`
- Tüm olay no: `3010`

```text
155. [2026-10-24 16:25:16.332 GMT+03:00] [UYARI] [Shikimori] [Shikimori] 1 kayıt atlandı: Kimlik doğrulanamadı (MAL #7593 yerel başlık/yıl ile uyuşmuyor; yanlış içerik eklenmesin diye atlandı)
   Atlanan kayıtlar (1): • kiss×sis
```

