# KÖK NEDENLER, KOD DEĞİŞİKLİKLERİ VE DOĞRULAMA SINIRLARI

**Hedef taban:** `f26901964-eng/Kitsugi-Beta@a8d7aaf6a7e450edc6095c5dcd5aaf913f7a4b03`  
**Rapor:** `2.4.359-beta.29880340`, 167.294 satır, 3.011 olay, 155 sorun  
**Patch:** `12_KITSUGI_BETA_V359_FIX.patch`  
**Önemli durum notu:** Bu dosyadaki “uygulandı” ifadeleri kaynak patch’inin hazır olduğunu belirtir. CI ve cihaz doğrulaması ayrı tutulur; çalıştırılmamış test başarılı sayılmaz.

## 1. Bütün hataların kaynak bazlı kapanış tablosu

| Kaynak | Rapor kanıtı | Kök neden / karar | Kaynak değişikliği |
|---|---|---|---|
| AniList | 31 HATA; 30 ek eşleşmeme; 37 atlama | Birleşik satır `source=bangumi` olduğunda gerçek MAL ID `MediaIdentity.realMalId` ile görünmüyor; Auth katmanı zaten doğruladığı `realMalId` değerini AniList çağrısına geçirmiyor. Liste-kayıt ID’si ile medya ID’si de favori yolunda karışıyor. | `knownMalId` ekleme/güncelleme yollarına taşındı; favori medya kimliği ayrıldı; API/ağ hatalarının sessiz `null/false` olması engellendi. |
| MyAnimeList | 0 HATA; 13 ekleme, 40 güncelleme; 7 atlama | Dört reddedilen kimlik ve üç doğrulanmış MAL ID bulunmaması güvenlik davranışı. Yeni MAL-özel servis hatası kanıtlanmadı. | Yalnız ortak kimlik/güvenli çekirdek ve dar alias iyileştirmelerinden yararlanır; MAL yazım sözleşmesi genişletilmedi. |
| Simkl | 0 HATA; 73 ekleme; 130 `not_found`; 147 atlama | `not_found` sunucu makbuzudur, HTTP 429 değildir. Çıplak sayı taraması yanlış `KTS-SMK-8004` üretiyordu. İki dizi için aggregate bölüm sayısını sezon/bölüme tahminle çevirmek güvenli değildir. | Yapılandırılmış HTTP kodu çıkarımı düzeltildi. Katalogda bulunmayan kayıtlar ve desteklenmeyen aggregate-TV progress için güvenli atlama korundu. |
| Kitsu | 3 HATA; 1 HTTP 422 + 2 transient ağ; 5 atlama | MAL `40658` → Kitsu `42919`, toplam `8`; progress `10`. R18 medya uzunluğu anonim GET ile `404` döndüğü için cap öğrenilemiyor. `42919` ayrıca sahte HTTP 429 sınıflandırmasına yol açıyor. | Uzunluk okuması Bearer token ile yapılır; ilerleme toplamı aşıyorsa bir kez `8`e indirilip yazım yeniden denenir. Çıplak `42919` artık 429 sayılmaz. |
| Shikimori | 0 HATA; 13 ekleme, 41 güncelleme; 7 atlama | MAL ile aynı kimlik-atlama örüntüsü; bağımsız Shikimori yazım hatası yok. | Yalnız ortak kimlik/güvenli çekirdek iyileştirmeleri; `user_rates` sözleşmesi değiştirilmedi. |
| Bangumi | 4 HATA; 2 sözde 400 + 2 timeout; 34 eşleşmeme; 52 atlama | Legacy başarı gövdesi `code:202,error:"Accepted"`; eski parser `error` alanını görüp başarıyı hata yapıyor. Stable `500_000_000+subject` kimlikleri sahte HTTP 500 üretiyor. Eşleşmemelerin tek bir nedeni yok. | Embedded 2xx önce kabul edilir; gerçek transport 400/500 maskelenmez. `knownMalId` ve doğrulanmış Bangumi↔MAL adayları eklendi; legacy/raw/stable namespace ayrımı korundu. |

**38/38 HATA açıklaması:** AniList 31 + Kitsu 3 + Bangumi 4. MAL, Simkl ve Shikimori’de raporlanmış HATA yoktur.  
**Silme:** Raporun tamamında silme olayı yoktur; `syncPlatforms` kullanıcı kaydını silen bir çağrı yapmaz. Bu çalışma silme davranışı eklemedi.

## 2. Ortak motor ve kimlik güvenliği

### 2.1 Sahte HTTP kodlarının kök nedeni

`PlatformErrorCatalog` eski sürümde mesaj ve ayrıntıların tamamında çıplak `429`, `500` vb. sayıları arıyordu. Bu nedenle:

- `kitsu=42919` gerçek 422’yi rate-limit gibi etiketliyordu;
- Bangumi stable ID `500012426` kimlik incelemesini AniList 500 gibi etiketliyordu;
- Simkl `not_found` ve sayısal sağlayıcı kimlikleri sahte 429 üretiyordu.

**Uygulanan değişiklik:** HTTP/status bağlamı düzenli ifadelerle ayrıştırılır; sağlayıcı ID’si, episode sayısı veya stable-ID aralığındaki çıplak sayı HTTP kodu kabul edilmez. Açık `HTTP 429`, `status=500`, `isteği reddetti (400)` gibi gerçek bağlamlar korunur.

### 2.2 86 identity-review grubu

Bu grupların tamamını otomatik açmak güvenli değildir. Raporda somut yanlış-medya örnekleri vardır: `DEVIL SURVIVOR 2`, `Fate/Zero Remix`, `Chuunibyou Lite` gibi ilgisiz Bangumi satırları başka kümelerle aynı kimliği paylaşmıştır.

**Uygulanan değişiklik:**

- Küme, `identityReviewEntryIds` ile yalnız şüpheli gelen satırları işaretler.
- Doğrulanabilir güvenli çekirdek birleştirme ve yazım için kullanılabilir.
- Şüpheli satır sonraki kayıtlara kimlik/başlık köprüsü olamaz.
- Şüpheli satır veya reddedilmiş MAL adayı MAL→Bangumi yerel eşleme önbelleğine kanıt olarak yazılamaz.
- AniList, MAL, Simkl, Kitsu, Shikimori ve Bangumi’nin altısında da mevcut şüpheli hedef satırı hedef bazında atlanır.
- Güvenli çekirdek yoksa eski koruyucu davranış sürer: grup yazılmaz.
- Uyarı ve ayrıntı kaydı korunur; sorun gizlenmez.

### 2.3 Dar alias normalizasyonu

Yalnız kanıtlı yazım çeşitleri eklendi: `× → x`, `& → and`, sondaki `(TV)/(OVA)/(Movie)` niteleyicisi, `Kyuu/Q` ve `eiga`. Sezon numarası denetimleri gevşetilmedi; ilgisiz başlıklar için genel “benzerse kabul et” kuralı eklenmedi.

**Beklenen dar etki:** `kiss×sis` ↔ `Kiss x Sis (TV)` gibi resmî yazım farkları doğrulanabilir. Diğer üç reddedilen aday (`61411`, `53200`, `36742`) otomatik olarak güvenli ilan edilmez.

## 3. AniList düzeltmeleri

### Kod kanıtı

Raporun 31 AniList hatasının tümünde birleşik kaynak `bangumi` ve gerçek MAL kimliği vardır. `AuthViewModel.resolveRealMalId` bu kimliği bulsa bile AniList güncelleme çağrısına `knownMalId` verilmez; `AniListSyncManager` yalnız kopyanın `source` alanından MAL kimliği çıkarmaya çalışır ve null döner.

### Uygulanan değişiklikler

- Auth ekleme ve güncelleme yollarına `knownMalId = realMalId` taşındı.
- Çözülen MAL kimliği hedef kopyada doğru namespace ile kullanılır.
- Favori çağrılarında `aniListEntryId` artık `Media.id` yerine kullanılmaz; favori medya kimliği ayrı tutulur.
- Medya doğrulama/favori API çağrılarında transport veya GraphQL hatası `getOrNull/getOrDefault(false)` ile kimlik uyuşmazlığına çevrilmez; çağırana gerçek hata taşınır.
- Geçerli yanıttaki gerçek null/farklı medya kimliği yine güvenli doğrulama hatası olarak kalır.

**Resmî karşılaştırma:** AniList dokümanında `MediaList.id` liste kaydıdır; `Media.id` medya kimliği, `Media.idMal` ise MAL çapraz referansıdır:  
https://docs.anilist.co/guide/graphql/queries/media-list  
https://docs.anilist.co/reference/object/media

## 4. Bangumi düzeltmeleri

### 4.1 Legacy `202 Accepted`

Başarılı legacy yanıtı transport HTTP 200 gövdesinde `{"code":202,"error":"Accepted"}` taşıyabilir. Parser artık embedded 2xx kodunu `error` metninden önce değerlendirir. Transport HTTP 400/500 veya embedded gerçek hata kodu başarı sayılmaz.

Açık kaynak örnek: https://github.com/arition/Bangumi-Api/blob/master/doc/Api.md  
Geniş `watched_eps` endpoint semantiği yeniden yazılmadı; yalnız yanıt sınıflandırması düzeltildi.

### 4.2 `knownMalId` ve namespace

- Bangumi Auth add/update çağrıları artık doğrulanmış `knownMalId` taşır.
- `knownMalId` varken `source=bangumi` birleşik satırındaki gerçek MAL ID, eski ham Bangumi subject ID’si sanılmaz.
- Legacy `source=bangumi`, `knownMalId=null`, `1..99_999_999` satırların sıkı subject doğrulaması korunur.
- Stable Bangumi ID’leri `500_000_000` uzayında kalır; MAL veya HTTP 500 olarak yorumlanmaz.
- Gerekirse resmî MAL/AniList özgün başlığı Bangumi aramasına kanıt olarak eklenir.

### 4.3 Doğrulanmış Bangumi↔MAL aday crosswalk’u

Açık kaynak veri tek başına kimlik kanıtı kabul edilmedi:

- MAL→Bangumi adayı, Bangumi subject’in alias/tür/yıl doğrulamasından geçmeden kullanılmaz.
- Bangumi stable ID→MAL adayı, MAL kataloğunda `CrossSyncIdentityGuard.verifyMalId` ile doğrulanır.
- Yıl-tek-başına fallback yoktur.
- Bilinen conflict kayıtlarının iki tarafı da dışlanır.
- Belirsiz veya doğrulanamayan aday güvenli `unresolved` olarak kalır.

Veri: `LinkPass888/bangumi-mal`, commit `b2c0f44c8aeb9b443700627005dce06534af71e1`, 23.527 satır, 13.270 çift, 77 conflict; CC BY 4.0 atıf ve hash’ler `docs/bangumi/BANGUMI_MAL_CROSSWALK_SOURCES.md` içindedir.  
https://github.com/LinkPass888/bangumi-mal

**Replay kapsamı:** 34 Bangumi-unresolved grubun 9’una ve stable-Bangumi-only iki AniList-unresolved grubun 1’ine aday çıkar. Bu, 34 kaydın tamamının düzeltildiği anlamına gelmez; kalanlar güvenli biçimde çözümlenmemiş kalır.

### 4.4 Timeout

İki timeout gerçek transport/ağ hatasıdır ve başarıya çevrilmez. Sunucunun yazıyı uygulayıp uygulamadığı bilinmeden kör POST tekrarı yapılmaz; bir sonraki eşitlemenin mevcut durumu okuyup alan bazlı karar vermesi gerekir. Cihaz/ağ doğrulaması açık iş olarak kalır.

## 5. Kitsu düzeltmeleri

- `fetchMediaLength` kimlik doğrulamalı medya GET kullanır; R18/NSFW katalog kaydının token ile okunabilmesi sağlanır.
- Yazım `422 progress > length` döndürür ve gerçek toplam biliniyorsa progress toplamla sınırlanır; yazım bir kez yeniden denenir.
- Örnek regresyon: MAL `40658`, Kitsu `42919`, `10 → 422 → 8 → success`.
- Yetkisiz/anonim `404` artık sıfır/unknown toplamla kör yazıma dönüşmez.
- İki transient network hatası başarı olarak işaretlenmez; kullanıcı hesabına kör duplicate-create yapılmaz.

Kitsu dokümanı: https://kitsu.docs.apiary.io/  
Canlı salt-okunur mapping kanıtı: MAL `40658` → anime `42919`, `episodeCount=8`, `ageRating=R18`, `nsfw=true`; anonim medya GET `404`.

## 6. Simkl triage sonucu

- 130 kayıt Simkl’in açık `not_found` makbuzudur. Liste; yetişkin içerikler, özel bölümler ve bazı live-action kayıtlarını içerir. Sahte MAL/TMDB/Simkl kimliği üretilmez.
- 13 kısmi uyarı özeti altı history-unmatched, altı rating-unmatched ve bir unsafe-identity grubudur; bunlar 13 ayrı HTTP 429 değildir.
- İki aggregate-TV progress kaydında liste durumu/puan yazılabilir; toplam bölüm sayısı sezon/bölüm geçmişine tahminle dönüştürülmez.
- Mevcut alan sırası korunur: history/ratings durumu değiştirebildiği için intended watchlist status en son yazılır.

Resmî sözleşme: HTTP 201 kısmi olabilir; `added` ve `not_found` birlikte okunur:  
https://api.simkl.org/api-reference/simkl/add-to-list

## 7. MyAnimeList ve Shikimori sözleşme notları

MAL tarafında anime/manga `my_list_status` PUT/PATCH yazımı status, score ve episode/chapter alanlarını destekler; raporda servis yazım hatası görülmediği için ek endpoint davranışı eklenmedi:  
https://myanimelist.net/apiconfig/references/api/v2#operation/anime_anime_id_my_list_status_put

Shikimori `POST /api/user_rates` create ve `PATCH /api/user_rates/:id` update alanlarını belgeler; mevcut find-or-create/update akışı değiştirilmedi:  
https://shikimori.io/api/doc/1.0/user_rates

Her iki kaynakta da `7` atlama, dört şüpheli kimlik reddi ve üç doğrulanmış MAL ID bulunmamasıyla açıklanır. Bunlar silme veya API başarısızlığı değildir.

## 8. Test ve teslim durumu

Eklenen/genişletilen odak testler:

- `BangumiLegacyWriteContractTest` (mevcut `BangumiApiClientWriteTest` de CI regresyon kapsamında)
- `BangumiKnownMalIdentityTest`
- `BangumiIdNamespaceTest`
- `BangumiMalCrosswalkTest`
- `KitsuProgressLengthGuardTest`
- `PlatformErrorCatalogStructuredHttpTest`
- `CrossSyncIdentityGuardTest`
- `CrossSyncClusterEngineTest`
- mevcut `CrossSyncMergePolicyTest`, `CrossSyncWriteGateTest`, `SimklSyncContractTest` ve ilgili auth/platform/model testleri regresyon kapsamı

### Doğrulama kapıları

- [x] Patch temiz v359 kopyasına `git apply --check` ile uygulanabilir.
- [x] İki XML ve iki JSON kaynağı ayrıştırıldı.
- [x] `git diff --check` whitespace hatası vermedi.
- [x] JDK 17 + Android SDK 36 üzerinde derleme ve hedefli testler: run `40103786098`, `BUILD SUCCESSFUL`, 38 suite / 299 test / 0 failure / 0 error / 0 skipped.
- [ ] Kullanıcı hesaplarına yazmadan cihazda salt-okunur/tek kontrollü kayıt doğrulaması.
- [ ] Yeni tam CrossSync raporuyla 155 sorun ve 255 atlama dağılımının yeniden karşılaştırılması.

## 9. Bilinçli olarak yapılmayanlar

- Kimlik guard’ı kaldırılmadı veya bütün 86 grup için bypass edilmedi.
- 130 Simkl `not_found` kaydına başlık benzerliğiyle zorla kimlik verilmedi.
- Aggregate TV bölümleri tahmin edilmedi.
- Timeout sonrası kör create/post tekrarıyla mükerrer kayıt riski alınmadı.
- Bangumi stable ID’leri MAL ID’sine çevrilmedi.
- Kullanıcı hesaplarında canlı yazma, silme veya toplu test yapılmadı.
- v355 tarihsel kaynağına veya eklenti modüllerine uygulama fix’i karıştırılmadı.
