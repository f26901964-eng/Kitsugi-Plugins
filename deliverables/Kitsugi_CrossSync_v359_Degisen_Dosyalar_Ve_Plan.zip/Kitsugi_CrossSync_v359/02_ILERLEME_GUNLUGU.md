# İLERLEME GÜNLÜĞÜ — en yeni kayıt en üstte

## 2026-10-24 · Geçiş 03 — v359 kaynak patch’i ve CI doğrulaması

### Tamamlanan kaynak çalışması
- [x] AniList add/update yollarına doğrulanmış `knownMalId` taşındı; liste-kayıt ID’si ile medya ID’si ayrıldı; favori/medya lookup API hatalarının `null/false` olarak yutulması kaldırıldı.
- [x] Bangumi Legacy transport 200 + embedded `202 Accepted` başarı olarak ayrıştırılıyor; transport 400/500 ve embedded gerçek hata maskelenmiyor.
- [x] Kitsu R18 medya uzunluğu için Bearer token kullanılıyor; `10 → 422 → 8 → retry` yardımcı sözleşmesi ve testleri eklendi.
- [x] HTTP kodu çıkarımı yapılandırılmış bağlama taşındı; `kitsu=42919`, Bangumi `500…` stable ID ve Simkl `not_found` çıplak sayı taramasıyla sahte HTTP kodu üretmiyor.
- [x] Altı platform için scoped identity-review tamamlandı: şüpheli satır hedef bazında atlanır, güvenli çekirdek çalışabilir, şüpheli satır birleştirme/köprü/önbellek kanıtı olamaz; güvenli çekirdek yoksa grup kilitli kalır. Türkçe/İngilizce kaynak string’leri eklendi.
- [x] Dar alias normalizasyonu (`×`, `&`, TV/OVA/Movie qualifier, `Kyuu/Q`, `eiga`) ve olumlu/olumsuz testler eklendi; sezon kuralları gevşetilmedi.
- [x] CC BY 4.0 Bangumi↔MAL veri crosswalk’u paketlendi: 23.527 satır, 13.270 çift, 77 conflict; iki tarafı conflict’li adaylar dışlanır. MAL→Bangumi için Bangumi alias/tür/yıl, ters yönde MAL guard doğrulaması zorunludur.
- [x] Bangumi `knownMalId` legacy-ID ayrımı, resmî native-title kanıtı ve Auth add/update/reverse-resolution bağlantıları tamamlandı. Gerçek MAL ID artık birleşik `source=bangumi` satırında legacy subject olarak okunmaz.
- [x] Simkl triage kapatıldı: 130 `not_found` gerçek kısmi sunucu makbuzu; iki aggregate-TV progress güvenli unsupported; yalnız yanlış 429 sınıflandırması düzeltildi.
- [x] MAL ve Shikimori resmî yazım sözleşmeleri karşılaştırıldı; raporda yeni kaynak-özel servis hatası olmadığından ek endpoint değişikliği yapılmadı.
- [x] `06_KOK_NEDEN_VE_DUZELTMELER.md` oluşturuldu; 38/38 hata ve bütün kaynak kararları olay kanıtlarına bağlandı.

### Paket ve statik kanıt
- [x] Birleşik patch üretildi: `12_KITSUGI_BETA_V359_FIX.patch`; 25 dosya, nihai boyut `492.279` bayt, SHA-256 `1c477d1a16e9b3e7628188d621a68a9b92a2f3ca9e4f04e6efddcbad85aec1dc`.
- [x] Patch temiz v359 `a8d7aaf6a7e450edc6095c5dcd5aaf913f7a4b03` üzerinde `git apply --check` ile doğrulandı.
- [x] `git diff --check` temiz; `values`/`values-en` XML ve iki raw JSON başarıyla parse edildi.
- [x] Crosswalk upstream commit `b2c0f44c8aeb9b443700627005dce06534af71e1`, veri hash’leri ve attribution kaydedildi.

### Gerçek CI sonucu ve kalan doğrulama
- [x] İlk iki run Android runner altyapısında durdu; uygulama kodu/testi çalışmadı. `setup-android@v4` + Ubuntu 24.04 ile çalıştırıcı düzeltildi.
- [x] Run `40103170627` AAPT’de kaçışsız İngilizce apostrofu yakaladı; `cluster\'s` düzeltildi. Run `40103454252` nullable `source` tip hatasını yakaladı; non-null imza düzeltildi.
- [x] **Run `40103786098` başarılı:** temiz v359 + patch, JDK 17/Android SDK 36, `BUILD SUCCESSFUL in 7m 30s`; 38 suite, **299 test, 0 failure, 0 error, 0 skipped**. Gerçek Gradle logu ve JUnit XML arşivi `testler/` altında.
- [x] Son tam-rapor parser çalıştırması değişmedi: `167.294/167.294` satır, `155` sorun, `3.011` olay, `0` sınıflandırılmayan satır, `0` silme satırı.
- [x] Nihai değişen-dosya aynası ve manifest üretildi: 25 dosya (16 modified + 9 added); patch SHA-256 `1c477d1a16e9b3e7628188d621a68a9b92a2f3ca9e4f04e6efddcbad85aec1dc`.
- [ ] Drive ZIP yüklemesi ve dosya bağlantısının kaydı.
- [ ] Cihazda kontrollü yeniden eşitleme. 34 Bangumi-unresolved grubun yalnız 9’u crosswalk adayı kapsamında; kalan güvenli unresolved davranış ve iki transient timeout açık doğrulama işidir. CI, canlı hesap/API yazma testi değildir.

### CI altyapı notu
- Yeni `workflow_dispatch` dosyası varsayılan branch dışında GitHub tarafından listelenmedi ve ilk dispatch `404` verdi; kod/test hatası değildir. Aynı workflow yalnız `.ci/crosssync-v359.patch` ve kendi dosyası değişince çalışan dar `push` tetikleyicisiyle run `40102213187` olarak başlatıldı. Geçici CI taşıyıcıları teslim öncesi branch’ten kaldırılacak.

---

## 2026-10-24 · Geçiş 02 — Tam mutabakat, kanıtlı kök nedenler ve düzeltme kapsamı

### Tamamlanan
- [x] Raporun tamamı güvenli aktarım sonrası yeniden doğrulandı: `167.294` satır, `8.280.517` bayt, MD5 `635fa5171b70877fdda5f86c426471f6`, SHA-256 `c4cfa4d9af0ba0792e6290f2b4b4c67a7a96db6af86518008df5db93fb7196be`.
- [x] Gerçek kod tabanı düzeltildi: rapor `2.4.359-beta.29880340`; birincil kaynak `Kitsugi-Beta@a8d7aaf6a7e450edc6095c5dcd5aaf913f7a4b03`. v355 `77ae046…` yalnız tarihsel karşılaştırmadır.
- [x] Standart-kütüphane ayrıştırıcı çalıştırıldı: `167.294/167.294` satır, `155/155` sorun eşleşmesi, `3.011` tüm-olay kaydı, sınıflandırılmayan satır `0`.
- [x] `03`, `04`, `05`, `07`, `08`, `09`, `10`, `11` envanter/denetim çıktıları üretildi; her küme ham olay/satır numaralarına geri bağlanabilir.
- [x] Özet mutabakatı: `834/834` içerik, `38 HATA`, `117 UYARI`, `38` eksik yazım, `255` atlama, `3.338` saniye. Silmeyle ilgili fiziksel satır `0`; `syncPlatforms` içinde kayıt silme çağrısı yok.
- [x] İki ekran görüntüsü de raporla karşılaştırıldı; görünen ara/final sayaçları ve AniList/Kitsu/Bangumi hata örnekleri raporla uyumlu.
- [x] Bütün `255` atlama açıklandı: AniList `37`, MAL `7`, Simkl `147`, Kitsu `5`, Shikimori `7`, Bangumi `52`. Kimlik incelemesi toplam `35` özete yansıyan atlama üretir.
- [x] Bütün `86` kimlik-inceleme kaydı ve dört reddedilen şüpheli kimlik ayrı dosyalara çıkarılıp incelendi.
- [x] Yerel Gradle önkoşulu denetlendi: `java: command not found`; hiçbir test çalıştırılmış gibi gösterilmedi.

### Kanıtlanmış kök nedenler
- [x] **AniList 31/31:** hata kayıtlarının tümünde birleştirilen kaynak `bangumi` ve gerçek MAL ID bulunur. `AuthViewModel`, `updateAniListEntry` çağrısına `knownMalId = realMalId` vermez; `MediaIdentity.realMalId(mergedEntry)` bu kaynakta null kalır. Aynı eksik aktarım en az 13 ekleme atlamasını da açıklar.
- [x] **AniList favori/ID:** favori çağrıları `aniListEntryId` değerini `knownAniListMediaId` diye verir; resmî AniList sözleşmesinde liste-kayıt `id` ile `Media.id` farklıdır. Favori sonucu ayrıca sessizce yutulur.
- [x] **AniList doğrulama:** API/ağ sonucu `getOrNull/getOrDefault(false)` ile kimlik uyuşmazlığına çöker; gerçek servis hatası yanlış “doğrulanamadı” istisnasına dönüşebilir.
- [x] **Bangumi iki sözde HTTP 400:** Legacy başarı gövdesi `{"code":202,"error":"Accepted"}` taşır; `parseLegacyWriteError` `error` metnini görüp başarıyı hata yapar. Önce embedded 2xx kabul edilmelidir.
- [x] **Kitsu 422:** resmî mapping MAL `40658 → Kitsu 42919`; `episodeCount=8`, R18/NSFW. Birleştirilen progress `10`, mevcut guard cap için okuma yapar ama `fetchMediaLength` Authorization göndermez; anonim R18 okuma `404` olduğundan cap öğrenilemez.
- [x] **Hata kodu sınıflandırıcı:** mesaj+ayrıntıda çıplak `429`/`500` aranır. Bu yüzden `kitsu=42919` gerçek 422’yi rate-limit yapar; Bangumi `500…` stable ID’leri sahte AniList 500 üretir; Simkl `not_found` özetleri sahte 429 kodu alır.
- [x] **Simkl:** `130` kayıt sunucunun döndürdüğü `not_found` makbuzudur, HTTP 429 değildir. `73` added ayrıdır. 13 kısmi uyarı = 6 history-unmatched + 6 rating-unmatched + 1 güvenlik; iki aggregate-TV progress güvenli biçimde desteklenmez.

### Kimlik incelemesi kararı
- [x] `86` grup topluca “false positive” ilan edilmedi. Örnek gerçek çelişkiler: `Hataraku Maou-sama!` kümesinde Bangumi `DEVIL SURVIVOR 2`; `Fate/Zero 2nd Season` kümesinde Bangumi `Fate/Zero Remix`; `Chuunibyou…DEPTH OF FIELD` kümesinde Bangumi `Lite`.
- [x] Aynı kayıtlarda `K-ON!`, `Evangelion` gibi yalnız resmî başlık çeşitlerinden oluşan yanlış-pozitif örüntüler de var. Güvenlik kilidini kaldırmak yerine şüpheli satır hedef bazında izole edilecek; doğrulanabilir çekirdek diğer platformlarda çalışmaya devam edecek.
- [x] `kiss×sis` ↔ `Kiss x Sis (TV)` için dar alias normalizasyonu adayı belirlendi; sezon numarası ve ilgisiz-başlık testleri korunacak.

### Önemli düzeltme / elenen aday
- Bangumi 34 eşleşmeme için ilk bakışta akla gelen “`resolverStoredId` gerçek MAL yedeğini hiç okumuyor” iddiası kodun tamamı okunarak elendi: `MediaIdentity.realMalId(entry) ?: stored` yedeği vardır. Bu 34 kayıt AniList’teki tek satırlık `knownMalId` kök nedeniyle açıklanamaz; aynı-yıl/aynı-normalize-başlık belirsizliği ve güvenli açık kaynak mapping ayrı incelenir.

### Devam eden / sonraki iş
- [ ] AniList, Bangumi Legacy, yapılandırılmış HTTP durum çıkarımı ve kimlik doğrulamalı Kitsu uzunluk yamaları + regresyon testleri.
- [ ] Kimlik-inceleme kapsamını tüm gruptan şüpheli hedefe indir; zehirli/ilgisiz kimlik ve farklı sezon testlerini koru.
- [ ] 34 Bangumi eşleşmeme ve reddedilen dört adayın kalan güvenli mapping/alias analizi.
- [ ] Gerçek JDK/Android test çalıştırıcısı; birleşik v359 patch; Drive’a tüm paketin yüklenmesi.

### Araştırma kanıtları
- AniList resmî dokümanları: `MediaList.id` liste kaydı, `Media.id` medya; `Media.idMal` resmî çapraz referans.
- Bangumi Legacy açık kaynak API örneği: başarı `code:202`, `error:"Accepted"`; geniş `watched_eps` semantiği yeniden yazılmayacak, yalnız sonuç ayrıştırması düzeltilecek.
- Kitsu resmî API/docs: R18 katalog anonim/mature-content kapalı hesaplarda gizli; mapping sorgusu yukarıdaki `42919/8` kanıtını verdi.
- Simkl resmî Add to Watchlist: HTTP 201 kısmi yazım olabilir; `added` ve `not_found` birlikte denetlenmelidir.

---

## 2026-10-24 · Geçiş 01 — Rapor ve doğru kod tabanı sabitlendi

### Tamamlanan
- [x] Drive raporu bulundu: `Kitsugi_CrossSync_Report_20261024_162739_722.txt`.
- [x] Raporun `8.280.517` bayt boyutu ve MD5 `635fa5171b70877fdda5f86c426471f6` değeri Drive metadata'sından alındı.
- [x] Drive çalışma klasörü oluşturuldu: `1LI2sH_Mb_fSP_cm1VTx3setrWWykTgcq`.
- [x] Önceki CrossSync devir notları (`E96–E106`) okundu.
- [x] GitHub `main` sürümünün eski (`2.4.340`) olduğu, rapor öncesi güncel eşitleme kodunun `arena/d832ebb9-kitsugi-beta` hattında ve `77ae046…` commit'inde olduğu belirlendi.
- [x] `77ae046…` kaynak anlık görüntüsü analiz için alındı.
- [x] Tikli plan ve devir dosyaları oluşturuldu.

### Önemli not / tuzak
- Arayüzden okunan büyük metinler ortadan kırpılıyor; analiz bu kırpılmış metne dayandırılmadı.
- Raporun ilk kayıtlarında `KTS-ANL-2003` açıklaması “AniList 500” derken gerçek ayrıntı `IllegalStateException: liste kaydının bu medya ile eşleştiği doğrulanamadı`. Geçiş 02’de yanlış kod sınıflandırması ve eksik `knownMalId` kod düzeyinde kanıtlandı.
- Bangumi `500_000_000 + subject_id` değerleri gerçek MAL kimliği veya HTTP 500 değildir; ID namespace ayrımı korunur.
