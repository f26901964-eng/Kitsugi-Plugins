# CROSSSYNC RAPORU — DOĞRULANMIŞ TAM ÖZET

## Bütünlük

- Dosya: `report.txt`
- Boyut: **8,280,517 bayt**
- Fiziksel satır: **167,294**
- MD5: `635fa5171b70877fdda5f86c426471f6`
- SHA-256: `c4cfa4d9af0ba0792e6290f2b4b4c67a7a96db6af86518008df5db93fb7196be`
- Satır kapsama: **167294/167294 (%100)**; sınıflandırılmayan boş olmayan satır: **0**
- Uygulama: **2.4.359-beta.29880340 (29880340) [release]**; cihaz: **Xiaomi 23043RP34C (pipa)**; Android: **13 (API 33)**

## Rapor başlığı

```text
Kitsugi — Çapraz Platform Eşitleme Raporu
Rapor oluşturma zamanı: 2026-10-24 16:27:39.723 GMT+03:00
Eşitleme başlangıcı: 2026-10-24 15:30:38.720 GMT+03:00
Eşitleme bitişi: 2026-10-24 16:26:17.589 GMT+03:00
Sonuç: Kısmen tamamlandı; hata var
Son adım: Eşitleme kısmen tamamlandı
Ayrıntı: Eşitleme kısmen tamamlandı: 38 işlem yazılamadı, 255 kayıt atlandı. Ayrıntılar için hata ve uyarı kayıtlarını inceleyin.
Geçen süre: 3338 sn
İlerleme: 834 / 834 İçerik
Oluşturulan işlem kaydı: 3011
Hata/uyarı sayısı: 155
```

## Mutabakat

- Sorun bölümü: **155** = **38 hata + 117 uyarı**.
- Tüm olaylar bölümü: **3011** = **BİLGİ=2856**, **HATA=38**, **UYARI=117**.
- Sorunların tüm olaylar bölümünde bulunan karşılığı: **155/155**.
- Platform hata toplamı / gerçek HATA olayı: **38/38**.
- Platform atlanan toplamı: **255**.
- Silme/delete/remove ilişkili satır: **0**.

## Platformlar

| Platform | Başlangıç | Eklenen | Güncellenen | Atlanan | Hata | Tüm olay | Uyarı |
|---|---:|---:|---:|---:|---:|---:|---:|
| AniList | 785 | 0 | 671 | 37 | 31 | 742 | 5 |
| MyAnimeList | 802 | 13 | 40 | 7 | 0 | 66 | 5 |
| Simkl | 632 | 73 | 0 | 147 | 0 | 16 | 6 |
| Kitsu | 799 | 17 | 46 | 5 | 3 | 75 | 4 |
| Shikimori | 803 | 13 | 41 | 7 | 0 | 67 | 5 |
| Bangumi | 719 | 62 | 18 | 52 | 4 | 122 | 2 |

## Hata kodları (3.011 olay içindeki tekrarlar dahil)

- `KTS-ANL-2002`: **4** olay
- `KTS-ANL-2003`: **101** olay
- `KTS-ANL-2004`: **1** olay
- `KTS-BGM-6001`: **2** olay
- `KTS-COM-1002`: **1** olay
- `KTS-COM-1003`: **3** olay
- `KTS-KIT-4002`: **1** olay
- `KTS-SMK-8004`: **2** olay

## Bölümler ve satır aralıkları

- `13–20`: **PLATFORM ÖZETİ**
- `21–9152`: **SORUNLAR / UYARILAR (155)**
- `9153–167212`: **TÜM İŞLEM VE EŞLEŞTİRME KAYITLARI (3011)**
- `167213–167288`: **HATA KODLARI (8)**
- `167289–167294`: **ORTAM BİLGİSİ**

## Tam listeler

- 155 sorun ve bütün ayrıntıları: `04_SORUNLAR_TAM_LISTE.md`
- 3.011 olay: `05_TUM_OLAYLAR.csv`
- Kaynak bazlı bütün sorunlar: `10_KAYNAK_BAZLI_OZET.md`
- Bütün olay grupları ve referansları: `11_OLAY_GRUPLARI.csv`
- Her fiziksel satır: `08_SATIR_DENETIMI.jsonl.gz`
