# TEST VE BUILD KANITLARI

Bu dizin yalnız gerçekten çalıştırılan komutların kanıtını içerir. “Test yazıldı” ile “test geçti” aynı durum değildir.

## Ortam

- Yerel analiz ortamı: `java: command not found`; yerel Gradle testi çalıştırılmadı.
- Uzak çalıştırıcı: GitHub Actions `ubuntu-24.04`, Temurin JDK 17, Android SDK 36 / Build Tools 36.0.0.
- Temiz uygulama tabanı: `f26901964-eng/Kitsugi-Beta@a8d7aaf6a7e450edc6095c5dcd5aaf913f7a4b03`.
- Test varyantı/komutu: `:app:testFossDebugUnitTest`.

## Çalıştırılan Gradle komutu

```bash
./gradlew --no-daemon :app:testFossDebugUnitTest \
  --tests 'com.kitsugi.animelist.data.auth.*' \
  --tests 'com.kitsugi.animelist.data.platform.*' \
  --tests 'com.kitsugi.animelist.data.remote.BangumiIdNamespaceTest' \
  --tests 'com.kitsugi.animelist.data.remote.BangumiMalCrosswalkTest' \
  --tests 'com.kitsugi.animelist.data.remote.SimklSyncContractTest' \
  --tests 'com.kitsugi.animelist.model.*' \
  --stacktrace --console=plain
```

Her run önce temiz v359 checkout’unda şu doğrulamaları yapar:

```bash
git apply --check ../patch-carrier/.ci/crosssync-v359.patch
git apply ../patch-carrier/.ci/crosssync-v359.patch
git diff --check
```

## Run geçmişi

| Run | Sonuç | Kapsam / not |
|---|---|---|
| `40102213187` | Altyapı hatası | `sdkmanager` PATH’te yok (`exit 127`); patch/test adımları çalışmadı. |
| `40102454967` | Altyapı hatası | `setup-android@v3` güncel runner ile uyumsuz; patch/test adımları çalışmadı. |
| `40102601068` | Build/test adımı başarısız | SDK ve patch uygulama başarılı; imzalı log indirme EOF nedeniyle ayrıntı sonraki run ile alındı. |
| `40103170627` | AAPT hatası | Okunabilir Gradle logu alındı. `values-en` içindeki yeni `cluster's` apostrofu kaçışsız olduğu için `mergeFossDebugResources` durdu; Kotlin/test çalışmadı. `cluster\\'s` olarak düzeltildi. |
| `40103454252` | Kotlin derleme hatası | AAPT geçti. `BangumiSyncManager.kt:49` içinde nullable `source`, non-null `canonicalMediaSourceId(String)` parametresine uymadı; testler çalışmadı. Yardımcı imza non-null yapıldı. |
| `40103786098` | **BAŞARILI** | Temiz v359 + nihai patch; `BUILD SUCCESSFUL in 7m 30s`. 38 suite, **299 test, 0 failure, 0 error, 0 skipped**. |

## Başarılı sonuç

- Run: https://github.com/f26901964-eng/Kitsugi-Plugins/actions/runs/40103786098
- Sonuç: `BUILD SUCCESSFUL in 7m 30s`; 72 actionable task (68 executed, 4 from cache).
- JUnit: 38 suite, 299 test; failures=0, errors=0, skipped=0.
- Patch SHA-256: `1c477d1a16e9b3e7628188d621a68a9b92a2f3ca9e4f04e6efddcbad85aec1dc`.
- Kapsam sınırı: seçili testlerdir; bütün uygulama testleri veya canlı cihaz/API yazma testi olduğu iddia edilmez.

## Dosyalar

- `kaynak/`: değiştirilen sekiz test kaynağının tam hâli.
- `ci-run-40103170627-gradle.txt`: AAPT hatasını kanıtlayan gerçek Gradle logu.
- `ci-run-40103454252-gradle.txt`: nullable/non-null Kotlin derleme hatasının gerçek logu.
- `ci-run-40103786098-gradle.txt`: başarılı nihai Gradle logu.
- `test-results-40103786098.tar.gz`: gerçek JUnit XML sonuçları.
- `CI_40103786098_SONUC.json`: suite/test sayıları ve kapsam notu.
- `son-rapor-mutabakat.json`: son tam-rapor parser çalıştırmasının özeti (167.294 satır, 155 sorun, 3.011 olay).

## Hâlâ ayrı olan cihaz doğrulaması

CI, canlı kullanıcı hesabına yazma yapmaz. Bangumi timeout’ları, Kitsu R18 hesap görünürlüğü ve yeni eşitleme sayaçları için kontrollü cihaz/API doğrulaması ayrıca gereklidir.
