# PLAN VE TASK — CrossSync Tam Rapor İncelemesi ve Kaynak Bazlı Düzeltmeler

**Durum:** v359 patch'i ve 299 hedefli CI testi başarılı; ZIP/Drive teslimi yapılıyor  
**Rapor derlemesi:** `2.4.359-beta.29880340`  
**Kod tabanı:** `Kitsugi-Beta@a8d7aaf6a7e450edc6095c5dcd5aaf913f7a4b03` (yerel kopya `.analysis/crosssync/source-v359`)  
**Tarihsel karşılaştırma:** `77ae046aab00e19d555ed2fede8c07fc2cb0dafe` (v355; düzeltme tabanı değildir)  
**Kural:** Bir görev ancak kanıt dosyası/test sonucu varsa `[x]` olur. Çalıştırılmamış test “başarılı” sayılmaz.

## A. Rapor bütünlüğü ve eksiksiz envanter
- [x] **T00 — Raporu bul ve kimliğini sabitle.** Drive ID `1DdqkHOQUZVeFzQ3wH5D18y61Pjj08udX`; `8.280.517` bayt ve MD5 `635fa5171b70877fdda5f86c426471f6` doğrulandı.
- [x] **T01 — Doğru kod tabanını belirle.** Rapor sürümü/commit damgası v359 `a8d7aaf…` ile eşleştirildi; v355 yalnız regresyon karşılaştırması olarak tutuldu.
- [x] **T02 — Raporun tamamını analiz ortamına aktar ve doğrula.** MD5 ve bayt eşleşti; `167.294` fiziksel satır, SHA-256 `c4cfa4d9af0ba0792e6290f2b4b4c67a7a96db6af86518008df5db93fb7196be`.
- [x] **T03 — Bütün fiziksel satırları sınıflandır.** `08_SATIR_DENETIMI.jsonl.gz` ve `07_SATIR_KAPSAMA.json`: `167.294/167.294`, sınıflandırılmayan satır `0`.
- [x] **T04 — 155 sorunun tamamını ayrıntılarıyla listele.** `04_SORUNLAR_TAM_LISTE.md`: `38 HATA + 117 UYARI`, bütün ayrıntı satırları ve rapor satır aralıkları korundu.
- [x] **T05 — 3.011 olayın tamamını envanterle.** `05_TUM_OLAYLAR.csv`, `09_OLAYLAR_TAM.jsonl.gz`, `10_KAYNAK_BAZLI_OZET.md`, `11_OLAY_GRUPLARI.csv` üretildi.
- [x] **T06 — Rapor içi mutabakat yap.** `155/155` sorun birebir tüm-olaylar bölümünde bulundu; `834/834` içerik, `3.011` olay, `255` atlama ve platform sayaçları uzlaştırıldı. Silme olayı `0`.

## B. Kök neden ve araştırma
- [x] **T07 — Mesaj/kod/kaynak kümelerini çıkar.** Her küme olay numaralarına bağlı; tekrarlar ham kayıtların yerine geçirilmedi.
- [x] **T08 — Ortak motor denetimi.** `realMalId`, birleştirme, kimlik kümeleme, hedef yazımı, kod sınıflandırıcı ve sayaçlar incelendi. 86 inceleme grubu için şüpheli satır hedef bazında izole edildi; güvenli çekirdek korunur, güvenli çekirdek yoksa tam güvenlik kilidi sürer. Regresyon testleri eklendi; çalıştırma kanıtı T18’dedir.
- [x] **T09 — Resmî doküman ve açık kaynak karşılaştırması.** AniList `MediaList.id ≠ Media.id`/`idMal`, Bangumi Legacy `code:202 Accepted`, Kitsu R18 kimlik doğrulaması, Simkl `added/not_found`, MAL `my_list_status` ve Shikimori `user_rates` sözleşmeleri kanıtlandı. Bangumi–MAL crosswalk yalnız çift doğrulamalı aday olarak kullanılır; conflict’ler dışlanır ve CC BY 4.0 atfı eklendi.

## C. Kaynak bazlı teşhis ve düzeltme
- [x] **T10 — AniList.** **Kanıt:** 31 hatanın tamamında birleşik kaynak `bangumi` ve gerçek MAL ID var; `AuthViewModel` bunu `knownMalId` olarak geçirmiyor. **Uygulandı:** ekleme/güncelleme kimliği geçirildi; liste-kayıt ID’si medya ID’sinden ayrıldı; favori/API doğrulama hatalarının yutulması kaldırıldı; olumlu/olumsuz testler eklendi. Çalıştırma kanıtı T18’dedir.
- [x] **T11 — MyAnimeList.** Bütün olaylar denetlendi: `13` ekleme, `40` güncelleme, `0` hata; `7=4 reddedilen kimlik+3 doğrulanmış MAL ID yok`. Yeni kaynak-özel kod hatası kanıtlanmadı.
- [x] **T12 — Simkl.** **Kanıt:** `73` added, `130` sunucu `not_found` makbuzu; HTTP 429 değil. 13 kısmi uyarı = 6 geçmiş + 6 puan + 1 güvenlik; iki aggregate-TV ilerlemesi güvenli biçimde aktarılmıyor. **Uygulandı:** sahte 429 sınıflandırması kaldırıldı ve test eklendi; sahte kimlik/bölüm tahmini yapılmadı, resmî kısmi makbuz davranışı korundu.
- [x] **T13 — Kitsu.** **Kanıt:** MAL `40658` resmî mapping ile Kitsu `42919`, `episodeCount=8`; yazılan progress `10`. R18 kaynak anonim GET’te `404`. **Uygulandı:** uzunluk okumasına Bearer token eklendi, `10→422→8→retry` ve yetkisiz okuma testleri yazıldı; iki transient ağ hatası kör duplicate-create yapılmadan belgelendi. Çalıştırma kanıtı T18’dedir.
- [x] **T14 — Shikimori.** Bütün olaylar denetlendi: `13` ekleme, `41` güncelleme, `0` hata; `7=4 reddedilen kimlik+3 doğrulanmış MAL ID yok`. Yeni kaynak-özel kod hatası kanıtlanmadı.
- [x] **T15 — Bangumi.** **Kanıt:** iki `400 Accepted` gövdesi aslında `code:202`; iki timeout; `52=34 eşleşme yok+17 inceleme+1 reddedilen`. **Uygulandı:** embedded 2xx önce kabul edilir; stable `500_000_000` ID’leri HTTP 500 sayılmaz; `knownMalId`/legacy ayrımı ve çift doğrulamalı crosswalk eklendi. Replay 34 grubun 9’una aday bulur; kalanlar güvenli unresolved kalır. İki timeout başarı sayılmaz ve cihaz/ağ doğrulaması bekler.
- [x] **T16 — Silme güvenliği.** Tam raporda silme isteği/olayı/başarısı/hatası `0`; CrossSync akışı ekleme/güncelleme/atlama üretir, kullanıcı kaydını silmek için çağrı yapılmaz.

## D. Doğrulama ve teslim
- [x] **T17 — Regresyon testleri ekle.** Her düzeltilen kök neden için olumlu/olumsuz örnekler eklendi; zehirli kimlik, sezon çakışması, R18, legacy Bangumi ID ve sahte 429/500 korumaları test kapsamında. Bu tik testlerin yazıldığını gösterir; başarı sonucu T18’dir.
- [x] **T18 — Statik ve gerçek testleri çalıştır.** XML/JSON parse, `git apply --check` ve `git diff --check` başarılı. GitHub Actions run `40103786098` JDK 17 + Android SDK 36 ile `BUILD SUCCESSFUL`; 38 suite, **299 test, 0 failure, 0 error, 0 skipped**. Komut/log/JUnit özeti `testler/` altında. Kapsam seçili auth/platform/remote/model testleridir; canlı cihaz/API yazma testi değildir.
- [x] **T19 — Değişen dosyalar + birleşik patch üret.** 25 dosya (16 modified + 9 added, 0 deleted) `degisen-dosyalar/` altında; birleşik patch temiz v359’a uygulanabilir. SHA-256 manifest `13_DEGISEN_DOSYALAR_MANIFEST.json`; patch SHA-256 `1c477d1a16e9b3e7628188d621a68a9b92a2f3ca9e4f04e6efddcbad85aec1dc`.
- [ ] **T20 — Son rapor ve devir paketini Drive'a yükle.** Drive klasörü `1LI2sH_Mb_fSP_cm1VTx3setrWWykTgcq` oluşturuldu. Plan, günlük, 25 değişen dosya, patch, manifest ve test kanıtları tek ZIP’te hazırlanıp yükleniyor; dosya ID/bağlantısı sonrasında kaydedilecek.
- [ ] **T21 — Kullanıcıya dürüst kapanış.** Düzeltilenler, gerçekten çalıştırılan testler ve cihazda yeniden eşitlemeyle doğrulanması gerekenler ayrı bildirilecek.

## Sonraki somut iş sırası
1. ZIP bütünlüğünü ve içindeki 25 değişen dosya + plan/task varlığını doğrula; Drive dosya ID’sini ve indirme bağlantısını kaydet.
2. Geçici CI taşıyıcılarını çalışma branch’inden kaldır; kalıcı kanıtları ZIP/Drive paketinde bırak.
3. Cihazda kontrollü yeniden eşitleme yap; canlı kullanıcı verisine yazma doğrulamasını CI’dan ayrı raporla.
4. Yeni raporda özellikle 31 AniList hatası, iki Bangumi sözde 400’ü, Kitsu 422’si, scoped-review atlama sayıları ve kalan Bangumi/Simkl unresolved kayıtları karşılaştır. Kalan unresolved kayıtlara zorla kimlik verme.
