# KAYNAK BAZLI TAM SORUN ENVANTERİ

Her tablo ilgili kaynağın **bütün** hata/uyarı başlıklarını içerir; olayın tam ayrıntısı `04_SORUNLAR_TAM_LISTE.md` içindedir. Bilgi kayıtlarının tamamı `05_TUM_OLAYLAR.csv` içindedir.

## Analiz

Olay: **1**; sorun/uyarı: **0**; seviyeler: `{'BİLGİ': 1}`.

### İşlem ve neden dağılımı (bilgi kayıtları dahil)

- `lifecycle` / `unspecified`: **1**

### Bütün hata ve uyarılar

Bu kaynağa ait hata/uyarı kaydı yok.

## AniList

Rapor özeti: başlangıç **785**, eklenen **0**, güncellenen **671**, atlanan **37**, hata **31**.

Olay: **742**; sorun/uyarı: **36**; seviyeler: `{'BİLGİ': 706, 'HATA': 31, 'UYARI': 5}`.

### İşlem ve neden dağılımı (bilgi kayıtları dahil)

- `update_success` / `unspecified`: **671**
- `skipped` / `remote_identity_unresolved`: **31**
- `update_error` / `identity_unverified`: **31**
- `skipped` / `identity_mismatch_blocked`: **8**
- `other_info` / `unspecified`: **1**

### Bütün hata ve uyarılar

| Sorun | Tüm olay | Seviye | Kod | Neden | Mesaj |
|---:|---:|---|---|---|---|
| 2 | 1147 | HATA | KTS-ANL-2003 | `identity_unverified` | [AniList] ! Güncellenemedi: CLANNAD 〜AFTER STORY〜 |
| 4 | 1232 | HATA | KTS-ANL-2003 | `identity_unverified` | [AniList] ! Güncellenemedi: SUPERNATURAL THE ANIMATION |
| 7 | 1309 | HATA | KTS-ANL-2003 | `identity_unverified` | [AniList] ! Güncellenemedi: 真希ちゃんとなう。 |
| 11 | 1426 | HATA | KTS-ANL-2003 | `identity_unverified` | [AniList] ! Güncellenemedi: ゴールデンタイム |
| 19 | 1675 | HATA | KTS-ANL-2003 | `identity_unverified` | [AniList] ! Güncellenemedi: Re:ゼロから始める異世界生活 |
| 23 | 1702 | HATA | KTS-ANL-2003 | `identity_unverified` | [AniList] ! Güncellenemedi: Aサイズ クラスメイト Anime Edition |
| 29 | 1758 | HATA | KTS-ANL-2003 | `identity_unverified` | [AniList] ! Güncellenemedi: 300円のおつきあい Anime Edition |
| 30 | 1782 | HATA | KTS-ANL-2003 | `identity_unverified` | [AniList] ! Güncellenemedi: はじめてのギャル |
| 31 | 1827 | HATA | KTS-ANL-2003 | `identity_unverified` | [AniList] ! Güncellenemedi: マヨヒガのお姉さん THE ANIMATION |
| 32 | 1842 | HATA | KTS-ANL-2003 | `identity_unverified` | [AniList] ! Güncellenemedi: 殺戮の天使 |
| 39 | 1910 | HATA | KTS-ANL-2003 | `identity_unverified` | [AniList] ! Güncellenemedi: 大好きな母 |
| 42 | 1943 | HATA | KTS-ANL-2003 | `identity_unverified` | [AniList] ! Güncellenemedi: 五等分の花嫁 |
| 48 | 2043 | HATA | KTS-ANL-2003 | `identity_unverified` | [AniList] ! Güncellenemedi: らぶりー♡ |
| 52 | 2108 | HATA | KTS-ANL-2002 | `identity_unverified` | [AniList] ! Güncellenemedi: へんたつ |
| 53 | 2119 | HATA | KTS-ANL-2003 | `identity_unverified` | [AniList] ! Güncellenemedi: 義姉はヤンママ授乳中 |
| 57 | 2192 | HATA | KTS-ANL-2003 | `identity_unverified` | [AniList] ! Güncellenemedi: アリス・ギア・アイギス ～ドキッ！アクトレスだらけのマーメイドグランプリ♡～ |
| 59 | 2226 | HATA | KTS-ANL-2003 | `identity_unverified` | [AniList] ! Güncellenemedi: 友達の妹が俺にだけウザい |
| 62 | 2275 | HATA | KTS-ANL-2003 | `identity_unverified` | [AniList] ! Güncellenemedi: らぶみー「楓と鈴」THE ANIMATION |
| 63 | 2296 | HATA | KTS-ANL-2003 | `identity_unverified` | [AniList] ! Güncellenemedi: 君を愛したひとりの僕へ |
| 65 | 2318 | HATA | KTS-ANL-2003 | `identity_unverified` | [AniList] ! Güncellenemedi: エロ医師 |
| 68 | 2337 | HATA | KTS-ANL-2003 | `identity_unverified` | [AniList] ! Güncellenemedi: Garden ～高嶺家の二輪花～ THE ANIMATION |
| 70 | 2348 | HATA | KTS-ANL-2003 | `identity_unverified` | [AniList] ! Güncellenemedi: けものっ娘通信〜The Animation〜 |
| 77 | 2438 | HATA | KTS-ANL-2003 | `identity_unverified` | [AniList] ! Güncellenemedi: サキュバス喚んだら義母が来た！？ |
| 78 | 2458 | HATA | KTS-ANL-2003 | `identity_unverified` | [AniList] ! Güncellenemedi: 婚約破棄された令嬢を拾った俺が、イケナイことを教え込む |
| 85 | 2498 | HATA | KTS-ANL-2003 | `identity_unverified` | [AniList] ! Güncellenemedi: クラスで男は僕一人！？ |
| 87 | 2513 | HATA | KTS-ANL-2003 | `identity_unverified` | [AniList] ! Güncellenemedi: ゾン100～ゾンビになるまでにしたい100のこと～ |
| 98 | 2591 | HATA | KTS-ANL-2003 | `identity_unverified` | [AniList] ! Güncellenemedi: 初恋時間。 |
| 102 | 2622 | HATA | KTS-ANL-2003 | `identity_unverified` | [AniList] ! Güncellenemedi: 悶えてよ、アダムくん |
| 103 | 2629 | HATA | KTS-ANL-2003 | `identity_unverified` | [AniList] ! Güncellenemedi: 69〜偽りの微笑〜 |
| 106 | 2669 | HATA | KTS-ANL-2003 | `identity_unverified` | [AniList] ! Güncellenemedi: しかのこのこのここしたんたん |
| 108 | 2679 | HATA | KTS-ANL-2003 | `identity_unverified` | [AniList] ! Güncellenemedi: セフレのセンパイ THE ANIMATION |
| 133 | 2988 | UYARI | — | `remote_identity_unresolved` | [AniList] 30 kayıt atlandı: AniList medya kimliği çözülemedi (MAL ID veya ARM eşlemesi yok) |
| 134 | 2989 | UYARI | — | `identity_mismatch_blocked` | [AniList] 1 kayıt atlandı: Kimlik doğrulanamadı (MAL #61411 yerel başlık/yıl ile uyuşmuyor; yanlış içerik eklenmesin diye atlandı) |
| 141 | 2996 | UYARI | — | `identity_mismatch_blocked` | [AniList] 1 kayıt atlandı: Kimlik doğrulanamadı (MAL #53200 yerel başlık/yıl ile uyuşmuyor; yanlış içerik eklenmesin diye atlandı) |
| 146 | 3001 | UYARI | — | `identity_mismatch_blocked` | [AniList] 1 kayıt atlandı: Kimlik doğrulanamadı (MAL #36742 yerel başlık/yıl ile uyuşmuyor; yanlış içerik eklenmesin diye atlandı) |
| 151 | 3006 | UYARI | — | `identity_mismatch_blocked` | [AniList] 1 kayıt atlandı: Kimlik doğrulanamadı (MAL #7593 yerel başlık/yıl ile uyuşmuyor; yanlış içerik eklenmesin diye atlandı) |

## Bangumi

Rapor özeti: başlangıç **719**, eklenen **62**, güncellenen **18**, atlanan **52**, hata **4**.

Olay: **122**; sorun/uyarı: **6**; seviyeler: `{'BİLGİ': 116, 'HATA': 4, 'UYARI': 2}`.

### İşlem ve neden dağılımı (bilgi kayıtları dahil)

- `add_success` / `unspecified`: **62**
- `skipped` / `remote_identity_unresolved`: **35**
- `update_success` / `unspecified`: **18**
- `skipped` / `identity_mismatch_blocked`: **2**
- `update_error` / `http_400_rejected`: **2**
- `update_error` / `timeout`: **2**
- `other_info` / `unspecified`: **1**

### Bütün hata ve uyarılar

| Sorun | Tüm olay | Seviye | Kod | Neden | Mesaj |
|---:|---:|---|---|---|---|
| 8 | 1343 | HATA | KTS-BGM-6001 | `http_400_rejected` | [Bangumi] ! Güncellenemedi: R²[rise R to the second power] (Bangumi bölüm ilerlemesi yazılamadı (R²[rise R to the second power]): Bangumi isteği reddetti (400): Accepted — /subject/324778/update/watched_eps?watched_eps=1— sunucu: Accepted — /subject/324778/update/watched_eps?watched_eps=1) |
| 74 | 2415 | HATA | KTS-COM-1003 | `timeout` | [Bangumi] ! Hata: Yuusha, Yamemasu: Kenshuu Ryokou wa Mokuteki wo Miushinau na (Bangumi güncellenemedi (Yuusha, Yamemasu: Kenshuu Ryokou wa Mokuteki wo Miushinau na): Bangumi'ye ulaşılamadı: timeout) |
| 76 | 2428 | HATA | KTS-COM-1003 | `timeout` | [Bangumi] ! Güncellenemedi: 俺だけレベルアップな件 (Bangumi bölüm ilerlemesi yazılamadı (俺だけレベルアップな件): Bangumi'ye ulaşılamadı: timeout) |
| 120 | 2801 | HATA | KTS-BGM-6001 | `http_400_rejected` | [Bangumi] ! Güncellenemedi: 五等分の花嫁【春夏秋冬】 (Bangumi bölüm ilerlemesi yazılamadı (五等分の花嫁【春夏秋冬】): Bangumi isteği reddetti (400): Accepted — /subject/646470/update/watched_eps?watched_eps=2— sunucu: Accepted — /subject/646470/update/watched_eps?watched_eps=2) |
| 132 | 2987 | UYARI | — | `remote_identity_unresolved` | [Bangumi] 34 kayıt atlandı: Bangumi eşleşmesi bulunamadı |
| 138 | 2993 | UYARI | — | `identity_mismatch_blocked` | [Bangumi] 1 kayıt atlandı: Kimlik doğrulanamadı (MAL #61411 yerel başlık/yıl ile uyuşmuyor; yanlış içerik eklenmesin diye atlandı) |

## Kitsu

Rapor özeti: başlangıç **799**, eklenen **17**, güncellenen **46**, atlanan **5**, hata **3**.

Olay: **75**; sorun/uyarı: **7**; seviyeler: `{'BİLGİ': 68, 'HATA': 3, 'UYARI': 4}`.

### İşlem ve neden dağılımı (bilgi kayıtları dahil)

- `update_success` / `unspecified`: **46**
- `add_success` / `unspecified`: **17**
- `skipped` / `identity_mismatch_blocked`: **8**
- `update_error` / `timeout`: **2**
- `add_error` / `progress_above_media_length`: **1**
- `other_info` / `unspecified`: **1**

### Bütün hata ve uyarılar

| Sorun | Tüm olay | Seviye | Kod | Neden | Mesaj |
|---:|---:|---|---|---|---|
| 50 | 2085 | HATA | KTS-KIT-4002 | `progress_above_media_length` | [Kitsu] ! Hata: ○○ Kouhai (Kitsu kütüphanesine eklenemedi (○○ Kouhai): HTTP 422: cannot exceed length of media: progress - cannot exceed length of media [kitsu=42919, önbellek (MAL→Kitsu)]) |
| 73 | 2376 | HATA | KTS-COM-1003 | `timeout` | [Kitsu] ! Güncellenemedi: 無職転生Ⅱ ～異世界行ったら本気だす～ (Hata: java.io.InterruptedIOException: timeout |
| 75 | 2418 | HATA | KTS-COM-1002 | `timeout` | [Kitsu] ! Güncellenemedi: デート・ア・ライブV (Hata: java.io.InterruptedIOException: timeout |
| 136 | 2991 | UYARI | — | `identity_mismatch_blocked` | [Kitsu] 1 kayıt atlandı: Kimlik doğrulanamadı (MAL #61411 yerel başlık/yıl ile uyuşmuyor; yanlış içerik eklenmesin diye atlandı) |
| 144 | 2999 | UYARI | — | `identity_mismatch_blocked` | [Kitsu] 1 kayıt atlandı: Kimlik doğrulanamadı (MAL #53200 yerel başlık/yıl ile uyuşmuyor; yanlış içerik eklenmesin diye atlandı) |
| 149 | 3004 | UYARI | — | `identity_mismatch_blocked` | [Kitsu] 1 kayıt atlandı: Kimlik doğrulanamadı (MAL #36742 yerel başlık/yıl ile uyuşmuyor; yanlış içerik eklenmesin diye atlandı) |
| 154 | 3009 | UYARI | — | `identity_mismatch_blocked` | [Kitsu] 1 kayıt atlandı: Kimlik doğrulanamadı (MAL #7593 yerel başlık/yıl ile uyuşmuyor; yanlış içerik eklenmesin diye atlandı) |

## MyAnimeList

Rapor özeti: başlangıç **802**, eklenen **13**, güncellenen **40**, atlanan **7**, hata **0**.

Olay: **66**; sorun/uyarı: **5**; seviyeler: `{'BİLGİ': 61, 'UYARI': 5}`.

### İşlem ve neden dağılımı (bilgi kayıtları dahil)

- `update_success` / `unspecified`: **40**
- `add_success` / `unspecified`: **13**
- `skipped` / `identity_mismatch_blocked`: **8**
- `skipped` / `verified_mal_id_missing`: **4**
- `other_info` / `unspecified`: **1**

### Bütün hata ve uyarılar

| Sorun | Tüm olay | Seviye | Kod | Neden | Mesaj |
|---:|---:|---|---|---|---|
| 135 | 2990 | UYARI | — | `identity_mismatch_blocked` | [MyAnimeList] 1 kayıt atlandı: Kimlik doğrulanamadı (MAL #61411 yerel başlık/yıl ile uyuşmuyor; yanlış içerik eklenmesin diye atlandı) |
| 139 | 2994 | UYARI | — | `verified_mal_id_missing` | [MyAnimeList] 3 kayıt atlandı: Doğrulanmış MAL ID yok (AniList/Kitsu/Simkl kaydı MAL ile eşlenemedi) |
| 142 | 2997 | UYARI | — | `identity_mismatch_blocked` | [MyAnimeList] 1 kayıt atlandı: Kimlik doğrulanamadı (MAL #53200 yerel başlık/yıl ile uyuşmuyor; yanlış içerik eklenmesin diye atlandı) |
| 147 | 3002 | UYARI | — | `identity_mismatch_blocked` | [MyAnimeList] 1 kayıt atlandı: Kimlik doğrulanamadı (MAL #36742 yerel başlık/yıl ile uyuşmuyor; yanlış içerik eklenmesin diye atlandı) |
| 152 | 3007 | UYARI | — | `identity_mismatch_blocked` | [MyAnimeList] 1 kayıt atlandı: Kimlik doğrulanamadı (MAL #7593 yerel başlık/yıl ile uyuşmuyor; yanlış içerik eklenmesin diye atlandı) |

## Shikimori

Rapor özeti: başlangıç **803**, eklenen **13**, güncellenen **41**, atlanan **7**, hata **0**.

Olay: **67**; sorun/uyarı: **5**; seviyeler: `{'BİLGİ': 62, 'UYARI': 5}`.

### İşlem ve neden dağılımı (bilgi kayıtları dahil)

- `update_success` / `unspecified`: **41**
- `add_success` / `unspecified`: **13**
- `skipped` / `identity_mismatch_blocked`: **8**
- `skipped` / `verified_mal_id_missing`: **4**
- `other_info` / `unspecified`: **1**

### Bütün hata ve uyarılar

| Sorun | Tüm olay | Seviye | Kod | Neden | Mesaj |
|---:|---:|---|---|---|---|
| 137 | 2992 | UYARI | — | `identity_mismatch_blocked` | [Shikimori] 1 kayıt atlandı: Kimlik doğrulanamadı (MAL #61411 yerel başlık/yıl ile uyuşmuyor; yanlış içerik eklenmesin diye atlandı) |
| 140 | 2995 | UYARI | — | `verified_mal_id_missing` | [Shikimori] 3 kayıt atlandı: Doğrulanmış MAL ID yok (Shikimori kimlikleri MAL ID ile aynıdır) |
| 145 | 3000 | UYARI | — | `identity_mismatch_blocked` | [Shikimori] 1 kayıt atlandı: Kimlik doğrulanamadı (MAL #53200 yerel başlık/yıl ile uyuşmuyor; yanlış içerik eklenmesin diye atlandı) |
| 150 | 3005 | UYARI | — | `identity_mismatch_blocked` | [Shikimori] 1 kayıt atlandı: Kimlik doğrulanamadı (MAL #36742 yerel başlık/yıl ile uyuşmuyor; yanlış içerik eklenmesin diye atlandı) |
| 155 | 3010 | UYARI | — | `identity_mismatch_blocked` | [Shikimori] 1 kayıt atlandı: Kimlik doğrulanamadı (MAL #7593 yerel başlık/yıl ile uyuşmuyor; yanlış içerik eklenmesin diye atlandı) |

## Simkl

Rapor özeti: başlangıç **632**, eklenen **73**, güncellenen **0**, atlanan **147**, hata **0**.

Olay: **16**; sorun/uyarı: **6**; seviyeler: `{'BİLGİ': 10, 'UYARI': 6}`.

### İşlem ve neden dağılımı (bilgi kayıtları dahil)

- `add_success` / `unspecified`: **6**
- `skipped` / `identity_mismatch_blocked`: **6**
- `other_info` / `rate_limit`: **1**
- `other_info` / `unspecified`: **1**
- `skipped` / `episode_progress_not_transferred`: **1**
- `skipped` / `remote_identity_unresolved`: **1**

### Bütün hata ve uyarılar

| Sorun | Tüm olay | Seviye | Kod | Neden | Mesaj |
|---:|---:|---|---|---|---|
| 129 | 2984 | UYARI | KTS-SMK-8004 | `remote_identity_unresolved` | [Simkl] 130 kayıt Simkl kataloğunda bulunamadı (atlandı) |
| 130 | 2985 | UYARI | — | `episode_progress_not_transferred` | [Simkl] 2 dizinin bölüm ilerlemesi aktarılmadı (liste durumu yazıldı) |
| 131 | 2986 | UYARI | KTS-SMK-8004 | `rate_limit` | [Simkl] 13 kısmi işlem uyarısı (izleme geçmişi/puan) |
| 143 | 2998 | UYARI | — | `identity_mismatch_blocked` | [Simkl] 1 kayıt atlandı: Kimlik doğrulanamadı (MAL #53200 yerel başlık/yıl ile uyuşmuyor; yanlış içerik eklenmesin diye atlandı) |
| 148 | 3003 | UYARI | — | `identity_mismatch_blocked` | [Simkl] 1 kayıt atlandı: Kimlik doğrulanamadı (MAL #36742 yerel başlık/yıl ile uyuşmuyor; yanlış içerik eklenmesin diye atlandı) |
| 153 | 3008 | UYARI | — | `identity_mismatch_blocked` | [Simkl] 1 kayıt atlandı: Kimlik doğrulanamadı (MAL #7593 yerel başlık/yıl ile uyuşmuyor; yanlış içerik eklenmesin diye atlandı) |

## Tamamlandı

Olay: **1**; sorun/uyarı: **0**; seviyeler: `{'BİLGİ': 1}`.

### İşlem ve neden dağılımı (bilgi kayıtları dahil)

- `skipped` / `unspecified`: **1**

### Bütün hata ve uyarılar

Bu kaynağa ait hata/uyarı kaydı yok.

## Eşleştirme

Olay: **1921**; sorun/uyarı: **90**; seviyeler: `{'BİLGİ': 1831, 'UYARI': 90}`.

### İşlem ve neden dağılımı (bilgi kayıtları dahil)

- `match_merge` / `identity_or_mapping`: **1069**
- `other_info` / `unspecified`: **748**
- `skipped` / `identity_unverified`: **86**
- `identity` / `identity_or_mapping`: **14**
- `skipped` / `identity_mismatch_blocked`: **4**

### Bütün hata ve uyarılar

| Sorun | Tüm olay | Seviye | Kod | Neden | Mesaj |
|---:|---:|---|---|---|---|
| 1 | 1140 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Evangelion Shin Movie: Kyuu |
| 3 | 1176 | UYARI | — | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: WHITE ALBUM 2nd Season |
| 5 | 1246 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: K-ON! Movie |
| 6 | 1299 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Fate/Zero 2nd Season |
| 9 | 1379 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Hataraku Maou-sama! |
| 10 | 1384 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Chuunibyou demo Koi ga Shitai!: DEPTH OF FIELD - Ai to Nikushimi Gekijou |
| 12 | 1436 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Kakumeiki Valvrave 2 |
| 13 | 1540 | UYARI | — | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Date A Live II: Kurumi Star Festival |
| 14 | 1545 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Fate/stay night [Heaven's Feel] I. presage flower |
| 15 | 1546 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Fate/stay night: Unlimited Blade Works 2nd Season |
| 16 | 1575 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Dungeon ni Deai wo Motomeru no wa Machigatteiru Darou ka |
| 17 | 1608 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Grisaia no Meikyuu |
| 18 | 1664 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Phantasy Star Online 2: The Animation |
| 20 | 1683 | UYARI | — | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Masou Gakuen H×H |
| 21 | 1684 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Gakusen Toshi Asterisk 2 |
| 22 | 1692 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Kuusen Madoushi Kouhosei no Kyoukan: Lecty no, Ikimonogatari |
| 24 | 1710 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Dungeon ni Deai wo Motomeru no wa Machigatteiru Darou ka: Dungeon ni Onsen wo Motomeru no wa Machigatteiru Darou ka |
| 25 | 1731 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Owari no Seraph: Nagoya Kessen-hen - Owaranai Seraph Nagoya Kessen-hen |
| 26 | 1732 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Yahari Ore no Seishun Love Come wa Machigatteiru. Zoku: Kitto, Onnanoko wa Osatou to Spice to Suteki na Nanika de Dekiteiru |
| 27 | 1747 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: To LOVE-Ru Darkness 2nd OVA |
| 28 | 1752 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Trinity Seven Movie - Yuukyuu Toshokan to Renkinjutsu Shoujo |
| 33 | 1852 | UYARI | — | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Re:Zero kara Hajimeru Isekai Seikatsu OVAs |
| 34 | 1853 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: One Room: Second Season |
| 35 | 1880 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Aishen Qiaokeli-ING... II |
| 36 | 1886 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Muttsuri Dosukebe Russia Gibo Shimai no Honshitsu Minuite Sex Zanmai |
| 37 | 1887 | UYARI | — | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Dungeon ni Deai wo Motomeru no wa Machigatteiru Darou ka: Orion no Ya |
| 38 | 1888 | UYARI | — | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Dungeon ni Deai wo Motomeru no wa Machigatteiru Darou ka II |
| 40 | 1918 | UYARI | — | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Tokyo Ghoul:re 2 |
| 41 | 1941 | UYARI | — | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Fate/Grand Order: Shinsei Entaku Ryouiki Camelot - Paladin; Agateram |
| 43 | 1966 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Ore wo Suki nano wa Omae dake ka yo |
| 44 | 2003 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Koe no Katachi Specials |
| 45 | 2020 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Tensei Shitara Slime Datta Ken 2nd Season |
| 46 | 2021 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Re:Zero kara Hajimeru Isekai Seikatsu 2nd Season |
| 47 | 2034 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Bokutachi wa Benkyou ga Dekinai OVAs |
| 49 | 2061 | UYARI | — | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Dungeon ni Deai wo Motomeru no wa Machigatteiru Darou ka III |
| 51 | 2106 | UYARI | KTS-ANL-2002 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Sword Art Online: Alicization - War of Underworld Part 2 |
| 54 | 2143 | UYARI | — | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Tensei Shitara Slime Datta Ken 2nd Season Part 2 |
| 55 | 2162 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Re:Zero kara Hajimeru Isekai Seikatsu 2nd Season Part 2 |
| 56 | 2182 | UYARI | KTS-ANL-2002 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Kanojo, Okarishimasu 2nd Season |
| 58 | 2212 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Mushoku Tensei: Isekai Ittara Honki Dasu Part 2 |
| 60 | 2230 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Dungeon ni Deai wo Motomeru no wa Machigatteiru Darou ka IV: Shin Shou Meikyuu-hen |
| 61 | 2250 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Go-toubun no Hanayome Movie |
| 64 | 2308 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Yonde Yobarete |
| 66 | 2324 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Tonikaku Kawaii Season 2 |
| 67 | 2331 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Mushoku Tensei: Isekai Ittara Honki Dasu Part 2 - Eris no Goblin Toubatsu |
| 69 | 2346 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Komi-san wa, Komyushou desu. 2 |
| 71 | 2359 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Jujutsu Kaisen 2nd Season |
| 72 | 2366 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Uma Musume: Pretty Derby - 1st Anniversary Special Animation |
| 79 | 2469 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Kanojo, Okarishimasu 3rd Season |
| 80 | 2470 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Sono Bisque Doll wa Koi wo Suru Season 2 |
| 81 | 2477 | UYARI | — | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Hataraku Maou-sama!! 2nd Season |
| 82 | 2478 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Dungeon ni Deai wo Motomeru no wa Machigatteiru Darou ka IV: Shin Shou Yakusai-hen |
| 83 | 2489 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Tensei Shitara Dai Nana Ouji Datta node, Kimamani Majutsu wo Kiwamemasu |
| 84 | 2492 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Tensei Shitara Slime Datta Ken 3rd Season |
| 86 | 2506 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: SPY×FAMILY Season 2 |
| 88 | 2526 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Seishun Buta Yarou wa Randoseru Girl no Yume wo Minai |
| 89 | 2533 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Kimi no Koto ga Dai Dai Dai Dai Daisuki na 100-nin no Kanojo |
| 90 | 2540 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Sugar Apple Fairy Tale Part 2 |
| 91 | 2543 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Re:Zero kara Hajimeru Isekai Seikatsu 3rd Season |
| 92 | 2554 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Re:STARS: Mirai e Tsunagu 2-tsu no Kiraboshi |
| 93 | 2567 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Boku no Kokoro no Yabai Yatsu 2nd Season |
| 94 | 2574 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: [Oshi no Ko] 2nd Season |
| 95 | 2577 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Jigokuraku 2nd Season |
| 96 | 2580 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Mushoku Tensei II: Isekai Ittara Honki Dasu Part 2 |
| 97 | 2589 | UYARI | — | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: NieR:Automata Ver1.1a 2nd Season |
| 99 | 2595 | UYARI | — | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Kanojo, Okarishimasu × Temple Collab Mini Anime |
| 100 | 2600 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: SYNDUALITY Noir Part 2 |
| 101 | 2618 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Dungeon ni Deai wo Motomeru no wa Machigatteiru Darou ka V: Houjou no Megami-hen |
| 104 | 2642 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Kimi no Koto ga Dai Dai Dai Dai Daisuki na 100-nin no Kanojo 2nd Season |
| 105 | 2663 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Itsuwari no Kotowari |
| 107 | 2677 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Kusuriya no Hitorigoto 2nd Season |
| 109 | 2681 | UYARI | — | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Ore dake Level Up na Ken: Season 2 - Arise from the Shadow |
| 110 | 2696 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Tensei Shitara Dai Nana Ouji Datta node, Kimamani Majutsu wo Kiwamemasu 2nd Season |
| 111 | 2705 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Kaijuu 8-gou 2nd Season |
| 112 | 2706 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Kimetsu no Yaiba: Mugenjou-hen Movie 1 - Akaza Sairai |
| 113 | 2713 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Kanojo, Okarishimasu 4th Season |
| 114 | 2729 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Silent Witch: Chinmoku no Majo no Kakushigoto |
| 115 | 2736 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Youkoso Jitsuryoku Shijou Shugi no Kyoushitsu e 4th Season 2-nensei-hen Ichi Gakki |
| 116 | 2745 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: [Oshi no Ko] 3rd Season |
| 117 | 2760 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Dandadan 2nd Season |
| 118 | 2765 | UYARI | KTS-ANL-2004 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Re:Zero kara Hajimeru Isekai Seikatsu 4th Season |
| 119 | 2781 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Kanojo, Okarishimasu 5th Season |
| 121 | 2802 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Mushoku Tensei III: Isekai Ittara Honki Dasu Part 2 |
| 122 | 2806 | UYARI | KTS-ANL-2002 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Aishen Qiaokeli-ing: Wanjie Jinian |
| 123 | 2842 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Tensei shitara Slime Datta Ken Movie: Guren no Kizuna-hen Specials |
| 124 | 2843 | UYARI | KTS-ANL-2003 | `identity_unverified` | Kimlik doğrulaması gerektiği için dış hesaplara aktarılmadı: Tensei shitara Slime Datta Ken: Kanwa - Veldora Nikki |
| 125 | 2865 | UYARI | — | `identity_mismatch_blocked` | Şüpheli kimlik, ekleme engellendi: Kanchigai no Atelier Meister: Eiyuu Party no Moto Zatsuyou-gakari ga, Jitsu wa Sentou Igai ga SSS Rank Datta to Iu Yoku Aru Hanashi → MAL #61411 |
| 126 | 2882 | UYARI | KTS-ANL-2003 | `identity_mismatch_blocked` | Şüpheli kimlik, ekleme engellendi: はたらく魔王さま！！ 2nd Season → MAL #53200 |
| 127 | 2931 | UYARI | KTS-ANL-2003 | `identity_mismatch_blocked` | Şüpheli kimlik, ekleme engellendi: 恋するシロクマ → MAL #36742 |
| 128 | 2938 | UYARI | KTS-ANL-2003 | `identity_mismatch_blocked` | Şüpheli kimlik, ekleme engellendi: kiss×sis → MAL #7593 |

